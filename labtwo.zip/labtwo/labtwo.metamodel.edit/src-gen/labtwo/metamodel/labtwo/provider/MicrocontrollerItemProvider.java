/**
 */
package labtwo.metamodel.labtwo.provider;

import java.util.Collection;
import java.util.List;

import labtwo.metamodel.labtwo.LabtwoPackage;
import labtwo.metamodel.labtwo.Microcontroller;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link labtwo.metamodel.labtwo.Microcontroller} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class MicrocontrollerItemProvider extends DeviceComponentItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MicrocontrollerItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addCoresPropertyDescriptor(object);
			addClockSpeedPropertyDescriptor(object);
			addArcheticturePropertyDescriptor(object);
			addGPIOsPropertyDescriptor(object);
			addBatteryPropertyDescriptor(object);
			addControlledByPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Cores feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCoresPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Microcontroller_cores_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Microcontroller_cores_feature",
								"_UI_Microcontroller_type"),
						LabtwoPackage.Literals.MICROCONTROLLER__CORES, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Clock Speed feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addClockSpeedPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Microcontroller_clockSpeed_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Microcontroller_clockSpeed_feature",
								"_UI_Microcontroller_type"),
						LabtwoPackage.Literals.MICROCONTROLLER__CLOCK_SPEED, true, false, false,
						ItemPropertyDescriptor.REAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Archeticture feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addArcheticturePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Microcontroller_archeticture_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Microcontroller_archeticture_feature",
								"_UI_Microcontroller_type"),
						LabtwoPackage.Literals.MICROCONTROLLER__ARCHETICTURE, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the GPI Os feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addGPIOsPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Microcontroller_GPIOs_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Microcontroller_GPIOs_feature",
								"_UI_Microcontroller_type"),
						LabtwoPackage.Literals.MICROCONTROLLER__GPI_OS, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Battery feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addBatteryPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Microcontroller_battery_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Microcontroller_battery_feature",
								"_UI_Microcontroller_type"),
						LabtwoPackage.Literals.MICROCONTROLLER__BATTERY, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Controlled By feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addControlledByPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Microcontroller_controlledBy_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Microcontroller_controlledBy_feature",
								"_UI_Microcontroller_type"),
						LabtwoPackage.Literals.MICROCONTROLLER__CONTROLLED_BY, true, false, true, null, null, null));
	}

	/**
	 * This returns Microcontroller.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Microcontroller"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((Microcontroller) object).getSerialNumber();
		return label == null || label.length() == 0 ? getString("_UI_Microcontroller_type")
				: getString("_UI_Microcontroller_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Microcontroller.class)) {
		case LabtwoPackage.MICROCONTROLLER__CORES:
		case LabtwoPackage.MICROCONTROLLER__CLOCK_SPEED:
		case LabtwoPackage.MICROCONTROLLER__ARCHETICTURE:
		case LabtwoPackage.MICROCONTROLLER__GPI_OS:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

}
