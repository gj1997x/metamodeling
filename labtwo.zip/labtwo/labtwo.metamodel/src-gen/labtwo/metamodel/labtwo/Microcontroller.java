/**
 */
package labtwo.metamodel.labtwo;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Microcontroller</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link labtwo.metamodel.labtwo.Microcontroller#getCores <em>Cores</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Microcontroller#getClockSpeed <em>Clock Speed</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Microcontroller#getArcheticture <em>Archeticture</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Microcontroller#getGPIOs <em>GPI Os</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Microcontroller#getBattery <em>Battery</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Microcontroller#getControlledBy <em>Controlled By</em>}</li>
 * </ul>
 *
 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMicrocontroller()
 * @model
 * @generated
 */
public interface Microcontroller extends DeviceComponent {
	/**
	 * Returns the value of the '<em><b>Cores</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cores</em>' attribute.
	 * @see #setCores(int)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMicrocontroller_Cores()
	 * @model
	 * @generated
	 */
	int getCores();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Microcontroller#getCores <em>Cores</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cores</em>' attribute.
	 * @see #getCores()
	 * @generated
	 */
	void setCores(int value);

	/**
	 * Returns the value of the '<em><b>Clock Speed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Clock Speed</em>' attribute.
	 * @see #setClockSpeed(float)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMicrocontroller_ClockSpeed()
	 * @model
	 * @generated
	 */
	float getClockSpeed();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Microcontroller#getClockSpeed <em>Clock Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Clock Speed</em>' attribute.
	 * @see #getClockSpeed()
	 * @generated
	 */
	void setClockSpeed(float value);

	/**
	 * Returns the value of the '<em><b>Archeticture</b></em>' attribute.
	 * The literals are from the enumeration {@link labtwo.metamodel.labtwo.ArchitectureType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Archeticture</em>' attribute.
	 * @see labtwo.metamodel.labtwo.ArchitectureType
	 * @see #setArcheticture(ArchitectureType)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMicrocontroller_Archeticture()
	 * @model
	 * @generated
	 */
	ArchitectureType getArcheticture();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Microcontroller#getArcheticture <em>Archeticture</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Archeticture</em>' attribute.
	 * @see labtwo.metamodel.labtwo.ArchitectureType
	 * @see #getArcheticture()
	 * @generated
	 */
	void setArcheticture(ArchitectureType value);

	/**
	 * Returns the value of the '<em><b>GPI Os</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>GPI Os</em>' attribute.
	 * @see #setGPIOs(int)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMicrocontroller_GPIOs()
	 * @model
	 * @generated
	 */
	int getGPIOs();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Microcontroller#getGPIOs <em>GPI Os</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>GPI Os</em>' attribute.
	 * @see #getGPIOs()
	 * @generated
	 */
	void setGPIOs(int value);

	/**
	 * Returns the value of the '<em><b>Battery</b></em>' reference list.
	 * The list contents are of type {@link labtwo.metamodel.labtwo.Battery}.
	 * It is bidirectional and its opposite is '{@link labtwo.metamodel.labtwo.Battery#getRequires <em>Requires</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Battery</em>' reference list.
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMicrocontroller_Battery()
	 * @see labtwo.metamodel.labtwo.Battery#getRequires
	 * @model opposite="requires" required="true"
	 * @generated
	 */
	EList<Battery> getBattery();

	/**
	 * Returns the value of the '<em><b>Controlled By</b></em>' reference list.
	 * The list contents are of type {@link labtwo.metamodel.labtwo.Motor}.
	 * It is bidirectional and its opposite is '{@link labtwo.metamodel.labtwo.Motor#getControls <em>Controls</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Controlled By</em>' reference list.
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMicrocontroller_ControlledBy()
	 * @see labtwo.metamodel.labtwo.Motor#getControls
	 * @model opposite="controls"
	 * @generated
	 */
	EList<Motor> getControlledBy();

} // Microcontroller
