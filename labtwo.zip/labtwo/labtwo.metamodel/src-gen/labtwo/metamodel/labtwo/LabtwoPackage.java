/**
 */
package labtwo.metamodel.labtwo;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see labtwo.metamodel.labtwo.LabtwoFactory
 * @model kind="package"
 * @generated
 */
public interface LabtwoPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "labtwo";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.rm2pt.com/labtwo";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "labtwo";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	LabtwoPackage eINSTANCE = labtwo.metamodel.labtwo.impl.LabtwoPackageImpl.init();

	/**
	 * The meta object id for the '{@link labtwo.metamodel.labtwo.impl.EmbeddedSystemImpl <em>Embedded System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see labtwo.metamodel.labtwo.impl.EmbeddedSystemImpl
	 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getEmbeddedSystem()
	 * @generated
	 */
	int EMBEDDED_SYSTEM = 0;

	/**
	 * The feature id for the '<em><b>Model Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMBEDDED_SYSTEM__MODEL_NUMBER = 0;

	/**
	 * The feature id for the '<em><b>Release Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMBEDDED_SYSTEM__RELEASE_DATE = 1;

	/**
	 * The feature id for the '<em><b>Firmware Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMBEDDED_SYSTEM__FIRMWARE_VERSION = 2;

	/**
	 * The feature id for the '<em><b>Components</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMBEDDED_SYSTEM__COMPONENTS = 3;

	/**
	 * The feature id for the '<em><b>Implemented With</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMBEDDED_SYSTEM__IMPLEMENTED_WITH = 4;

	/**
	 * The number of structural features of the '<em>Embedded System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMBEDDED_SYSTEM_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Embedded System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMBEDDED_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link labtwo.metamodel.labtwo.impl.DeviceComponentImpl <em>Device Component</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see labtwo.metamodel.labtwo.impl.DeviceComponentImpl
	 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getDeviceComponent()
	 * @generated
	 */
	int DEVICE_COMPONENT = 1;

	/**
	 * The feature id for the '<em><b>Serial Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_COMPONENT__SERIAL_NUMBER = 0;

	/**
	 * The feature id for the '<em><b>Manufacturer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_COMPONENT__MANUFACTURER = 1;

	/**
	 * The feature id for the '<em><b>Includes</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_COMPONENT__INCLUDES = 2;

	/**
	 * The feature id for the '<em><b>Can Have</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_COMPONENT__CAN_HAVE = 3;

	/**
	 * The number of structural features of the '<em>Device Component</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_COMPONENT_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Device Component</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEVICE_COMPONENT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link labtwo.metamodel.labtwo.impl.ActuatorImpl <em>Actuator</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see labtwo.metamodel.labtwo.impl.ActuatorImpl
	 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getActuator()
	 * @generated
	 */
	int ACTUATOR = 2;

	/**
	 * The feature id for the '<em><b>Serial Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__SERIAL_NUMBER = DEVICE_COMPONENT__SERIAL_NUMBER;

	/**
	 * The feature id for the '<em><b>Manufacturer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__MANUFACTURER = DEVICE_COMPONENT__MANUFACTURER;

	/**
	 * The feature id for the '<em><b>Includes</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__INCLUDES = DEVICE_COMPONENT__INCLUDES;

	/**
	 * The feature id for the '<em><b>Can Have</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__CAN_HAVE = DEVICE_COMPONENT__CAN_HAVE;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__TYPE = DEVICE_COMPONENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Range</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__RANGE = DEVICE_COMPONENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Input Signal</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__INPUT_SIGNAL = DEVICE_COMPONENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Operates With</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__OPERATES_WITH = DEVICE_COMPONENT_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Actuator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR_FEATURE_COUNT = DEVICE_COMPONENT_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Actuator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR_OPERATION_COUNT = DEVICE_COMPONENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link labtwo.metamodel.labtwo.impl.MotorImpl <em>Motor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see labtwo.metamodel.labtwo.impl.MotorImpl
	 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getMotor()
	 * @generated
	 */
	int MOTOR = 3;

	/**
	 * The feature id for the '<em><b>Serial Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__SERIAL_NUMBER = DEVICE_COMPONENT__SERIAL_NUMBER;

	/**
	 * The feature id for the '<em><b>Manufacturer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__MANUFACTURER = DEVICE_COMPONENT__MANUFACTURER;

	/**
	 * The feature id for the '<em><b>Includes</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__INCLUDES = DEVICE_COMPONENT__INCLUDES;

	/**
	 * The feature id for the '<em><b>Can Have</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__CAN_HAVE = DEVICE_COMPONENT__CAN_HAVE;

	/**
	 * The feature id for the '<em><b>Power Rating</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__POWER_RATING = DEVICE_COMPONENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Speed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__SPEED = DEVICE_COMPONENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Torque</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__TORQUE = DEVICE_COMPONENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Motor Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__MOTOR_TYPE = DEVICE_COMPONENT_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Give Measurements To</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__GIVE_MEASUREMENTS_TO = DEVICE_COMPONENT_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Controls</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__CONTROLS = DEVICE_COMPONENT_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Included In</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__INCLUDED_IN = DEVICE_COMPONENT_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Command</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR__COMMAND = DEVICE_COMPONENT_FEATURE_COUNT + 7;

	/**
	 * The number of structural features of the '<em>Motor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_FEATURE_COUNT = DEVICE_COMPONENT_FEATURE_COUNT + 8;

	/**
	 * The number of operations of the '<em>Motor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOTOR_OPERATION_COUNT = DEVICE_COMPONENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link labtwo.metamodel.labtwo.impl.ConnectivityModuleImpl <em>Connectivity Module</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see labtwo.metamodel.labtwo.impl.ConnectivityModuleImpl
	 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getConnectivityModule()
	 * @generated
	 */
	int CONNECTIVITY_MODULE = 4;

	/**
	 * The feature id for the '<em><b>Serial Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIVITY_MODULE__SERIAL_NUMBER = DEVICE_COMPONENT__SERIAL_NUMBER;

	/**
	 * The feature id for the '<em><b>Manufacturer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIVITY_MODULE__MANUFACTURER = DEVICE_COMPONENT__MANUFACTURER;

	/**
	 * The feature id for the '<em><b>Includes</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIVITY_MODULE__INCLUDES = DEVICE_COMPONENT__INCLUDES;

	/**
	 * The feature id for the '<em><b>Can Have</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIVITY_MODULE__CAN_HAVE = DEVICE_COMPONENT__CAN_HAVE;

	/**
	 * The feature id for the '<em><b>Protocol</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIVITY_MODULE__PROTOCOL = DEVICE_COMPONENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Bandwidth</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIVITY_MODULE__BANDWIDTH = DEVICE_COMPONENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Range</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIVITY_MODULE__RANGE = DEVICE_COMPONENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Integrated With</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIVITY_MODULE__INTEGRATED_WITH = DEVICE_COMPONENT_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Connects</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIVITY_MODULE__CONNECTS = DEVICE_COMPONENT_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Connectivity Module</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIVITY_MODULE_FEATURE_COUNT = DEVICE_COMPONENT_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Connectivity Module</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIVITY_MODULE_OPERATION_COUNT = DEVICE_COMPONENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link labtwo.metamodel.labtwo.impl.MicrocontrollerImpl <em>Microcontroller</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see labtwo.metamodel.labtwo.impl.MicrocontrollerImpl
	 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getMicrocontroller()
	 * @generated
	 */
	int MICROCONTROLLER = 5;

	/**
	 * The feature id for the '<em><b>Serial Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROCONTROLLER__SERIAL_NUMBER = DEVICE_COMPONENT__SERIAL_NUMBER;

	/**
	 * The feature id for the '<em><b>Manufacturer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROCONTROLLER__MANUFACTURER = DEVICE_COMPONENT__MANUFACTURER;

	/**
	 * The feature id for the '<em><b>Includes</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROCONTROLLER__INCLUDES = DEVICE_COMPONENT__INCLUDES;

	/**
	 * The feature id for the '<em><b>Can Have</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROCONTROLLER__CAN_HAVE = DEVICE_COMPONENT__CAN_HAVE;

	/**
	 * The feature id for the '<em><b>Cores</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROCONTROLLER__CORES = DEVICE_COMPONENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Clock Speed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROCONTROLLER__CLOCK_SPEED = DEVICE_COMPONENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Archeticture</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROCONTROLLER__ARCHETICTURE = DEVICE_COMPONENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>GPI Os</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROCONTROLLER__GPI_OS = DEVICE_COMPONENT_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Battery</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROCONTROLLER__BATTERY = DEVICE_COMPONENT_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Controlled By</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROCONTROLLER__CONTROLLED_BY = DEVICE_COMPONENT_FEATURE_COUNT + 5;

	/**
	 * The number of structural features of the '<em>Microcontroller</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROCONTROLLER_FEATURE_COUNT = DEVICE_COMPONENT_FEATURE_COUNT + 6;

	/**
	 * The number of operations of the '<em>Microcontroller</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MICROCONTROLLER_OPERATION_COUNT = DEVICE_COMPONENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link labtwo.metamodel.labtwo.impl.SensorImpl <em>Sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see labtwo.metamodel.labtwo.impl.SensorImpl
	 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getSensor()
	 * @generated
	 */
	int SENSOR = 6;

	/**
	 * The feature id for the '<em><b>Serial Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__SERIAL_NUMBER = DEVICE_COMPONENT__SERIAL_NUMBER;

	/**
	 * The feature id for the '<em><b>Manufacturer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__MANUFACTURER = DEVICE_COMPONENT__MANUFACTURER;

	/**
	 * The feature id for the '<em><b>Includes</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__INCLUDES = DEVICE_COMPONENT__INCLUDES;

	/**
	 * The feature id for the '<em><b>Can Have</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__CAN_HAVE = DEVICE_COMPONENT__CAN_HAVE;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__TYPE = DEVICE_COMPONENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Range</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__RANGE = DEVICE_COMPONENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Sampling Rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__SAMPLING_RATE = DEVICE_COMPONENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Output Signal</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__OUTPUT_SIGNAL = DEVICE_COMPONENT_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Impacts</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR__IMPACTS = DEVICE_COMPONENT_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_FEATURE_COUNT = DEVICE_COMPONENT_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SENSOR_OPERATION_COUNT = DEVICE_COMPONENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link labtwo.metamodel.labtwo.impl.MemoryImpl <em>Memory</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see labtwo.metamodel.labtwo.impl.MemoryImpl
	 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getMemory()
	 * @generated
	 */
	int MEMORY = 7;

	/**
	 * The feature id for the '<em><b>Serial Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMORY__SERIAL_NUMBER = DEVICE_COMPONENT__SERIAL_NUMBER;

	/**
	 * The feature id for the '<em><b>Manufacturer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMORY__MANUFACTURER = DEVICE_COMPONENT__MANUFACTURER;

	/**
	 * The feature id for the '<em><b>Includes</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMORY__INCLUDES = DEVICE_COMPONENT__INCLUDES;

	/**
	 * The feature id for the '<em><b>Can Have</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMORY__CAN_HAVE = DEVICE_COMPONENT__CAN_HAVE;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMORY__TYPE = DEVICE_COMPONENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Size</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMORY__SIZE = DEVICE_COMPONENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Speed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMORY__SPEED = DEVICE_COMPONENT_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Memory</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMORY_FEATURE_COUNT = DEVICE_COMPONENT_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Memory</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEMORY_OPERATION_COUNT = DEVICE_COMPONENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link labtwo.metamodel.labtwo.impl.BatteryImpl <em>Battery</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see labtwo.metamodel.labtwo.impl.BatteryImpl
	 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getBattery()
	 * @generated
	 */
	int BATTERY = 8;

	/**
	 * The feature id for the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BATTERY__CAPACITY = 0;

	/**
	 * The feature id for the '<em><b>Voltage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BATTERY__VOLTAGE = 1;

	/**
	 * The feature id for the '<em><b>Usage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BATTERY__USAGE = 2;

	/**
	 * The feature id for the '<em><b>Charge Cycles</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BATTERY__CHARGE_CYCLES = 3;

	/**
	 * The feature id for the '<em><b>Requires</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BATTERY__REQUIRES = 4;

	/**
	 * The feature id for the '<em><b>Battery Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BATTERY__BATTERY_NAME = 5;

	/**
	 * The feature id for the '<em><b>Manufacturer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BATTERY__MANUFACTURER = 6;

	/**
	 * The number of structural features of the '<em>Battery</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BATTERY_FEATURE_COUNT = 7;

	/**
	 * The number of operations of the '<em>Battery</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BATTERY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link labtwo.metamodel.labtwo.SensorType <em>Sensor Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see labtwo.metamodel.labtwo.SensorType
	 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getSensorType()
	 * @generated
	 */
	int SENSOR_TYPE = 9;

	/**
	 * The meta object id for the '{@link labtwo.metamodel.labtwo.ArchitectureType <em>Architecture Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see labtwo.metamodel.labtwo.ArchitectureType
	 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getArchitectureType()
	 * @generated
	 */
	int ARCHITECTURE_TYPE = 10;

	/**
	 * Returns the meta object for class '{@link labtwo.metamodel.labtwo.EmbeddedSystem <em>Embedded System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Embedded System</em>'.
	 * @see labtwo.metamodel.labtwo.EmbeddedSystem
	 * @generated
	 */
	EClass getEmbeddedSystem();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.EmbeddedSystem#getModelNumber <em>Model Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Model Number</em>'.
	 * @see labtwo.metamodel.labtwo.EmbeddedSystem#getModelNumber()
	 * @see #getEmbeddedSystem()
	 * @generated
	 */
	EAttribute getEmbeddedSystem_ModelNumber();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.EmbeddedSystem#getReleaseDate <em>Release Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Release Date</em>'.
	 * @see labtwo.metamodel.labtwo.EmbeddedSystem#getReleaseDate()
	 * @see #getEmbeddedSystem()
	 * @generated
	 */
	EAttribute getEmbeddedSystem_ReleaseDate();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.EmbeddedSystem#getFirmwareVersion <em>Firmware Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Firmware Version</em>'.
	 * @see labtwo.metamodel.labtwo.EmbeddedSystem#getFirmwareVersion()
	 * @see #getEmbeddedSystem()
	 * @generated
	 */
	EAttribute getEmbeddedSystem_FirmwareVersion();

	/**
	 * Returns the meta object for the containment reference list '{@link labtwo.metamodel.labtwo.EmbeddedSystem#getComponents <em>Components</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Components</em>'.
	 * @see labtwo.metamodel.labtwo.EmbeddedSystem#getComponents()
	 * @see #getEmbeddedSystem()
	 * @generated
	 */
	EReference getEmbeddedSystem_Components();

	/**
	 * Returns the meta object for the containment reference list '{@link labtwo.metamodel.labtwo.EmbeddedSystem#getImplementedWith <em>Implemented With</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Implemented With</em>'.
	 * @see labtwo.metamodel.labtwo.EmbeddedSystem#getImplementedWith()
	 * @see #getEmbeddedSystem()
	 * @generated
	 */
	EReference getEmbeddedSystem_ImplementedWith();

	/**
	 * Returns the meta object for class '{@link labtwo.metamodel.labtwo.DeviceComponent <em>Device Component</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Device Component</em>'.
	 * @see labtwo.metamodel.labtwo.DeviceComponent
	 * @generated
	 */
	EClass getDeviceComponent();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.DeviceComponent#getSerialNumber <em>Serial Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Serial Number</em>'.
	 * @see labtwo.metamodel.labtwo.DeviceComponent#getSerialNumber()
	 * @see #getDeviceComponent()
	 * @generated
	 */
	EAttribute getDeviceComponent_SerialNumber();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.DeviceComponent#getManufacturer <em>Manufacturer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Manufacturer</em>'.
	 * @see labtwo.metamodel.labtwo.DeviceComponent#getManufacturer()
	 * @see #getDeviceComponent()
	 * @generated
	 */
	EAttribute getDeviceComponent_Manufacturer();

	/**
	 * Returns the meta object for the reference '{@link labtwo.metamodel.labtwo.DeviceComponent#getIncludes <em>Includes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Includes</em>'.
	 * @see labtwo.metamodel.labtwo.DeviceComponent#getIncludes()
	 * @see #getDeviceComponent()
	 * @generated
	 */
	EReference getDeviceComponent_Includes();

	/**
	 * Returns the meta object for the reference list '{@link labtwo.metamodel.labtwo.DeviceComponent#getCanHave <em>Can Have</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Can Have</em>'.
	 * @see labtwo.metamodel.labtwo.DeviceComponent#getCanHave()
	 * @see #getDeviceComponent()
	 * @generated
	 */
	EReference getDeviceComponent_CanHave();

	/**
	 * Returns the meta object for class '{@link labtwo.metamodel.labtwo.Actuator <em>Actuator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Actuator</em>'.
	 * @see labtwo.metamodel.labtwo.Actuator
	 * @generated
	 */
	EClass getActuator();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Actuator#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see labtwo.metamodel.labtwo.Actuator#getType()
	 * @see #getActuator()
	 * @generated
	 */
	EAttribute getActuator_Type();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Actuator#getRange <em>Range</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Range</em>'.
	 * @see labtwo.metamodel.labtwo.Actuator#getRange()
	 * @see #getActuator()
	 * @generated
	 */
	EAttribute getActuator_Range();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Actuator#getInputSignal <em>Input Signal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Input Signal</em>'.
	 * @see labtwo.metamodel.labtwo.Actuator#getInputSignal()
	 * @see #getActuator()
	 * @generated
	 */
	EAttribute getActuator_InputSignal();

	/**
	 * Returns the meta object for the reference list '{@link labtwo.metamodel.labtwo.Actuator#getOperatesWith <em>Operates With</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Operates With</em>'.
	 * @see labtwo.metamodel.labtwo.Actuator#getOperatesWith()
	 * @see #getActuator()
	 * @generated
	 */
	EReference getActuator_OperatesWith();

	/**
	 * Returns the meta object for class '{@link labtwo.metamodel.labtwo.Motor <em>Motor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Motor</em>'.
	 * @see labtwo.metamodel.labtwo.Motor
	 * @generated
	 */
	EClass getMotor();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Motor#getPowerRating <em>Power Rating</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Power Rating</em>'.
	 * @see labtwo.metamodel.labtwo.Motor#getPowerRating()
	 * @see #getMotor()
	 * @generated
	 */
	EAttribute getMotor_PowerRating();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Motor#getSpeed <em>Speed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Speed</em>'.
	 * @see labtwo.metamodel.labtwo.Motor#getSpeed()
	 * @see #getMotor()
	 * @generated
	 */
	EAttribute getMotor_Speed();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Motor#getTorque <em>Torque</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Torque</em>'.
	 * @see labtwo.metamodel.labtwo.Motor#getTorque()
	 * @see #getMotor()
	 * @generated
	 */
	EAttribute getMotor_Torque();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Motor#getMotorType <em>Motor Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Motor Type</em>'.
	 * @see labtwo.metamodel.labtwo.Motor#getMotorType()
	 * @see #getMotor()
	 * @generated
	 */
	EAttribute getMotor_MotorType();

	/**
	 * Returns the meta object for the reference list '{@link labtwo.metamodel.labtwo.Motor#getGiveMeasurementsTo <em>Give Measurements To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Give Measurements To</em>'.
	 * @see labtwo.metamodel.labtwo.Motor#getGiveMeasurementsTo()
	 * @see #getMotor()
	 * @generated
	 */
	EReference getMotor_GiveMeasurementsTo();

	/**
	 * Returns the meta object for the reference '{@link labtwo.metamodel.labtwo.Motor#getControls <em>Controls</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Controls</em>'.
	 * @see labtwo.metamodel.labtwo.Motor#getControls()
	 * @see #getMotor()
	 * @generated
	 */
	EReference getMotor_Controls();

	/**
	 * Returns the meta object for the reference list '{@link labtwo.metamodel.labtwo.Motor#getIncludedIn <em>Included In</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Included In</em>'.
	 * @see labtwo.metamodel.labtwo.Motor#getIncludedIn()
	 * @see #getMotor()
	 * @generated
	 */
	EReference getMotor_IncludedIn();

	/**
	 * Returns the meta object for the reference '{@link labtwo.metamodel.labtwo.Motor#getCommand <em>Command</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Command</em>'.
	 * @see labtwo.metamodel.labtwo.Motor#getCommand()
	 * @see #getMotor()
	 * @generated
	 */
	EReference getMotor_Command();

	/**
	 * Returns the meta object for class '{@link labtwo.metamodel.labtwo.ConnectivityModule <em>Connectivity Module</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Connectivity Module</em>'.
	 * @see labtwo.metamodel.labtwo.ConnectivityModule
	 * @generated
	 */
	EClass getConnectivityModule();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.ConnectivityModule#getProtocol <em>Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Protocol</em>'.
	 * @see labtwo.metamodel.labtwo.ConnectivityModule#getProtocol()
	 * @see #getConnectivityModule()
	 * @generated
	 */
	EAttribute getConnectivityModule_Protocol();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.ConnectivityModule#getBandwidth <em>Bandwidth</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bandwidth</em>'.
	 * @see labtwo.metamodel.labtwo.ConnectivityModule#getBandwidth()
	 * @see #getConnectivityModule()
	 * @generated
	 */
	EAttribute getConnectivityModule_Bandwidth();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.ConnectivityModule#getRange <em>Range</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Range</em>'.
	 * @see labtwo.metamodel.labtwo.ConnectivityModule#getRange()
	 * @see #getConnectivityModule()
	 * @generated
	 */
	EAttribute getConnectivityModule_Range();

	/**
	 * Returns the meta object for the reference '{@link labtwo.metamodel.labtwo.ConnectivityModule#getIntegratedWith <em>Integrated With</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Integrated With</em>'.
	 * @see labtwo.metamodel.labtwo.ConnectivityModule#getIntegratedWith()
	 * @see #getConnectivityModule()
	 * @generated
	 */
	EReference getConnectivityModule_IntegratedWith();

	/**
	 * Returns the meta object for the reference list '{@link labtwo.metamodel.labtwo.ConnectivityModule#getConnects <em>Connects</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Connects</em>'.
	 * @see labtwo.metamodel.labtwo.ConnectivityModule#getConnects()
	 * @see #getConnectivityModule()
	 * @generated
	 */
	EReference getConnectivityModule_Connects();

	/**
	 * Returns the meta object for class '{@link labtwo.metamodel.labtwo.Microcontroller <em>Microcontroller</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Microcontroller</em>'.
	 * @see labtwo.metamodel.labtwo.Microcontroller
	 * @generated
	 */
	EClass getMicrocontroller();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Microcontroller#getCores <em>Cores</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cores</em>'.
	 * @see labtwo.metamodel.labtwo.Microcontroller#getCores()
	 * @see #getMicrocontroller()
	 * @generated
	 */
	EAttribute getMicrocontroller_Cores();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Microcontroller#getClockSpeed <em>Clock Speed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Clock Speed</em>'.
	 * @see labtwo.metamodel.labtwo.Microcontroller#getClockSpeed()
	 * @see #getMicrocontroller()
	 * @generated
	 */
	EAttribute getMicrocontroller_ClockSpeed();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Microcontroller#getArcheticture <em>Archeticture</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Archeticture</em>'.
	 * @see labtwo.metamodel.labtwo.Microcontroller#getArcheticture()
	 * @see #getMicrocontroller()
	 * @generated
	 */
	EAttribute getMicrocontroller_Archeticture();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Microcontroller#getGPIOs <em>GPI Os</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>GPI Os</em>'.
	 * @see labtwo.metamodel.labtwo.Microcontroller#getGPIOs()
	 * @see #getMicrocontroller()
	 * @generated
	 */
	EAttribute getMicrocontroller_GPIOs();

	/**
	 * Returns the meta object for the reference list '{@link labtwo.metamodel.labtwo.Microcontroller#getBattery <em>Battery</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Battery</em>'.
	 * @see labtwo.metamodel.labtwo.Microcontroller#getBattery()
	 * @see #getMicrocontroller()
	 * @generated
	 */
	EReference getMicrocontroller_Battery();

	/**
	 * Returns the meta object for the reference list '{@link labtwo.metamodel.labtwo.Microcontroller#getControlledBy <em>Controlled By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Controlled By</em>'.
	 * @see labtwo.metamodel.labtwo.Microcontroller#getControlledBy()
	 * @see #getMicrocontroller()
	 * @generated
	 */
	EReference getMicrocontroller_ControlledBy();

	/**
	 * Returns the meta object for class '{@link labtwo.metamodel.labtwo.Sensor <em>Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sensor</em>'.
	 * @see labtwo.metamodel.labtwo.Sensor
	 * @generated
	 */
	EClass getSensor();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Sensor#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see labtwo.metamodel.labtwo.Sensor#getType()
	 * @see #getSensor()
	 * @generated
	 */
	EAttribute getSensor_Type();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Sensor#getRange <em>Range</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Range</em>'.
	 * @see labtwo.metamodel.labtwo.Sensor#getRange()
	 * @see #getSensor()
	 * @generated
	 */
	EAttribute getSensor_Range();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Sensor#getSamplingRate <em>Sampling Rate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sampling Rate</em>'.
	 * @see labtwo.metamodel.labtwo.Sensor#getSamplingRate()
	 * @see #getSensor()
	 * @generated
	 */
	EAttribute getSensor_SamplingRate();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Sensor#getOutputSignal <em>Output Signal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Output Signal</em>'.
	 * @see labtwo.metamodel.labtwo.Sensor#getOutputSignal()
	 * @see #getSensor()
	 * @generated
	 */
	EAttribute getSensor_OutputSignal();

	/**
	 * Returns the meta object for the reference list '{@link labtwo.metamodel.labtwo.Sensor#getImpacts <em>Impacts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Impacts</em>'.
	 * @see labtwo.metamodel.labtwo.Sensor#getImpacts()
	 * @see #getSensor()
	 * @generated
	 */
	EReference getSensor_Impacts();

	/**
	 * Returns the meta object for class '{@link labtwo.metamodel.labtwo.Memory <em>Memory</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Memory</em>'.
	 * @see labtwo.metamodel.labtwo.Memory
	 * @generated
	 */
	EClass getMemory();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Memory#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see labtwo.metamodel.labtwo.Memory#getType()
	 * @see #getMemory()
	 * @generated
	 */
	EAttribute getMemory_Type();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Memory#getSize <em>Size</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Size</em>'.
	 * @see labtwo.metamodel.labtwo.Memory#getSize()
	 * @see #getMemory()
	 * @generated
	 */
	EAttribute getMemory_Size();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Memory#getSpeed <em>Speed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Speed</em>'.
	 * @see labtwo.metamodel.labtwo.Memory#getSpeed()
	 * @see #getMemory()
	 * @generated
	 */
	EAttribute getMemory_Speed();

	/**
	 * Returns the meta object for class '{@link labtwo.metamodel.labtwo.Battery <em>Battery</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Battery</em>'.
	 * @see labtwo.metamodel.labtwo.Battery
	 * @generated
	 */
	EClass getBattery();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Battery#getCapacity <em>Capacity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capacity</em>'.
	 * @see labtwo.metamodel.labtwo.Battery#getCapacity()
	 * @see #getBattery()
	 * @generated
	 */
	EAttribute getBattery_Capacity();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Battery#getVoltage <em>Voltage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Voltage</em>'.
	 * @see labtwo.metamodel.labtwo.Battery#getVoltage()
	 * @see #getBattery()
	 * @generated
	 */
	EAttribute getBattery_Voltage();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Battery#getUsage <em>Usage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Usage</em>'.
	 * @see labtwo.metamodel.labtwo.Battery#getUsage()
	 * @see #getBattery()
	 * @generated
	 */
	EAttribute getBattery_Usage();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Battery#getChargeCycles <em>Charge Cycles</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Charge Cycles</em>'.
	 * @see labtwo.metamodel.labtwo.Battery#getChargeCycles()
	 * @see #getBattery()
	 * @generated
	 */
	EAttribute getBattery_ChargeCycles();

	/**
	 * Returns the meta object for the reference list '{@link labtwo.metamodel.labtwo.Battery#getRequires <em>Requires</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Requires</em>'.
	 * @see labtwo.metamodel.labtwo.Battery#getRequires()
	 * @see #getBattery()
	 * @generated
	 */
	EReference getBattery_Requires();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Battery#getBatteryName <em>Battery Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Battery Name</em>'.
	 * @see labtwo.metamodel.labtwo.Battery#getBatteryName()
	 * @see #getBattery()
	 * @generated
	 */
	EAttribute getBattery_BatteryName();

	/**
	 * Returns the meta object for the attribute '{@link labtwo.metamodel.labtwo.Battery#getManufacturer <em>Manufacturer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Manufacturer</em>'.
	 * @see labtwo.metamodel.labtwo.Battery#getManufacturer()
	 * @see #getBattery()
	 * @generated
	 */
	EAttribute getBattery_Manufacturer();

	/**
	 * Returns the meta object for enum '{@link labtwo.metamodel.labtwo.SensorType <em>Sensor Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Sensor Type</em>'.
	 * @see labtwo.metamodel.labtwo.SensorType
	 * @generated
	 */
	EEnum getSensorType();

	/**
	 * Returns the meta object for enum '{@link labtwo.metamodel.labtwo.ArchitectureType <em>Architecture Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Architecture Type</em>'.
	 * @see labtwo.metamodel.labtwo.ArchitectureType
	 * @generated
	 */
	EEnum getArchitectureType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	LabtwoFactory getLabtwoFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link labtwo.metamodel.labtwo.impl.EmbeddedSystemImpl <em>Embedded System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see labtwo.metamodel.labtwo.impl.EmbeddedSystemImpl
		 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getEmbeddedSystem()
		 * @generated
		 */
		EClass EMBEDDED_SYSTEM = eINSTANCE.getEmbeddedSystem();

		/**
		 * The meta object literal for the '<em><b>Model Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EMBEDDED_SYSTEM__MODEL_NUMBER = eINSTANCE.getEmbeddedSystem_ModelNumber();

		/**
		 * The meta object literal for the '<em><b>Release Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EMBEDDED_SYSTEM__RELEASE_DATE = eINSTANCE.getEmbeddedSystem_ReleaseDate();

		/**
		 * The meta object literal for the '<em><b>Firmware Version</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EMBEDDED_SYSTEM__FIRMWARE_VERSION = eINSTANCE.getEmbeddedSystem_FirmwareVersion();

		/**
		 * The meta object literal for the '<em><b>Components</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EMBEDDED_SYSTEM__COMPONENTS = eINSTANCE.getEmbeddedSystem_Components();

		/**
		 * The meta object literal for the '<em><b>Implemented With</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EMBEDDED_SYSTEM__IMPLEMENTED_WITH = eINSTANCE.getEmbeddedSystem_ImplementedWith();

		/**
		 * The meta object literal for the '{@link labtwo.metamodel.labtwo.impl.DeviceComponentImpl <em>Device Component</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see labtwo.metamodel.labtwo.impl.DeviceComponentImpl
		 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getDeviceComponent()
		 * @generated
		 */
		EClass DEVICE_COMPONENT = eINSTANCE.getDeviceComponent();

		/**
		 * The meta object literal for the '<em><b>Serial Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEVICE_COMPONENT__SERIAL_NUMBER = eINSTANCE.getDeviceComponent_SerialNumber();

		/**
		 * The meta object literal for the '<em><b>Manufacturer</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEVICE_COMPONENT__MANUFACTURER = eINSTANCE.getDeviceComponent_Manufacturer();

		/**
		 * The meta object literal for the '<em><b>Includes</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEVICE_COMPONENT__INCLUDES = eINSTANCE.getDeviceComponent_Includes();

		/**
		 * The meta object literal for the '<em><b>Can Have</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEVICE_COMPONENT__CAN_HAVE = eINSTANCE.getDeviceComponent_CanHave();

		/**
		 * The meta object literal for the '{@link labtwo.metamodel.labtwo.impl.ActuatorImpl <em>Actuator</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see labtwo.metamodel.labtwo.impl.ActuatorImpl
		 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getActuator()
		 * @generated
		 */
		EClass ACTUATOR = eINSTANCE.getActuator();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTUATOR__TYPE = eINSTANCE.getActuator_Type();

		/**
		 * The meta object literal for the '<em><b>Range</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTUATOR__RANGE = eINSTANCE.getActuator_Range();

		/**
		 * The meta object literal for the '<em><b>Input Signal</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTUATOR__INPUT_SIGNAL = eINSTANCE.getActuator_InputSignal();

		/**
		 * The meta object literal for the '<em><b>Operates With</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTUATOR__OPERATES_WITH = eINSTANCE.getActuator_OperatesWith();

		/**
		 * The meta object literal for the '{@link labtwo.metamodel.labtwo.impl.MotorImpl <em>Motor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see labtwo.metamodel.labtwo.impl.MotorImpl
		 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getMotor()
		 * @generated
		 */
		EClass MOTOR = eINSTANCE.getMotor();

		/**
		 * The meta object literal for the '<em><b>Power Rating</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOTOR__POWER_RATING = eINSTANCE.getMotor_PowerRating();

		/**
		 * The meta object literal for the '<em><b>Speed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOTOR__SPEED = eINSTANCE.getMotor_Speed();

		/**
		 * The meta object literal for the '<em><b>Torque</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOTOR__TORQUE = eINSTANCE.getMotor_Torque();

		/**
		 * The meta object literal for the '<em><b>Motor Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOTOR__MOTOR_TYPE = eINSTANCE.getMotor_MotorType();

		/**
		 * The meta object literal for the '<em><b>Give Measurements To</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOTOR__GIVE_MEASUREMENTS_TO = eINSTANCE.getMotor_GiveMeasurementsTo();

		/**
		 * The meta object literal for the '<em><b>Controls</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOTOR__CONTROLS = eINSTANCE.getMotor_Controls();

		/**
		 * The meta object literal for the '<em><b>Included In</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOTOR__INCLUDED_IN = eINSTANCE.getMotor_IncludedIn();

		/**
		 * The meta object literal for the '<em><b>Command</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOTOR__COMMAND = eINSTANCE.getMotor_Command();

		/**
		 * The meta object literal for the '{@link labtwo.metamodel.labtwo.impl.ConnectivityModuleImpl <em>Connectivity Module</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see labtwo.metamodel.labtwo.impl.ConnectivityModuleImpl
		 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getConnectivityModule()
		 * @generated
		 */
		EClass CONNECTIVITY_MODULE = eINSTANCE.getConnectivityModule();

		/**
		 * The meta object literal for the '<em><b>Protocol</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONNECTIVITY_MODULE__PROTOCOL = eINSTANCE.getConnectivityModule_Protocol();

		/**
		 * The meta object literal for the '<em><b>Bandwidth</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONNECTIVITY_MODULE__BANDWIDTH = eINSTANCE.getConnectivityModule_Bandwidth();

		/**
		 * The meta object literal for the '<em><b>Range</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONNECTIVITY_MODULE__RANGE = eINSTANCE.getConnectivityModule_Range();

		/**
		 * The meta object literal for the '<em><b>Integrated With</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTIVITY_MODULE__INTEGRATED_WITH = eINSTANCE.getConnectivityModule_IntegratedWith();

		/**
		 * The meta object literal for the '<em><b>Connects</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTIVITY_MODULE__CONNECTS = eINSTANCE.getConnectivityModule_Connects();

		/**
		 * The meta object literal for the '{@link labtwo.metamodel.labtwo.impl.MicrocontrollerImpl <em>Microcontroller</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see labtwo.metamodel.labtwo.impl.MicrocontrollerImpl
		 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getMicrocontroller()
		 * @generated
		 */
		EClass MICROCONTROLLER = eINSTANCE.getMicrocontroller();

		/**
		 * The meta object literal for the '<em><b>Cores</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MICROCONTROLLER__CORES = eINSTANCE.getMicrocontroller_Cores();

		/**
		 * The meta object literal for the '<em><b>Clock Speed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MICROCONTROLLER__CLOCK_SPEED = eINSTANCE.getMicrocontroller_ClockSpeed();

		/**
		 * The meta object literal for the '<em><b>Archeticture</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MICROCONTROLLER__ARCHETICTURE = eINSTANCE.getMicrocontroller_Archeticture();

		/**
		 * The meta object literal for the '<em><b>GPI Os</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MICROCONTROLLER__GPI_OS = eINSTANCE.getMicrocontroller_GPIOs();

		/**
		 * The meta object literal for the '<em><b>Battery</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MICROCONTROLLER__BATTERY = eINSTANCE.getMicrocontroller_Battery();

		/**
		 * The meta object literal for the '<em><b>Controlled By</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MICROCONTROLLER__CONTROLLED_BY = eINSTANCE.getMicrocontroller_ControlledBy();

		/**
		 * The meta object literal for the '{@link labtwo.metamodel.labtwo.impl.SensorImpl <em>Sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see labtwo.metamodel.labtwo.impl.SensorImpl
		 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getSensor()
		 * @generated
		 */
		EClass SENSOR = eINSTANCE.getSensor();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENSOR__TYPE = eINSTANCE.getSensor_Type();

		/**
		 * The meta object literal for the '<em><b>Range</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENSOR__RANGE = eINSTANCE.getSensor_Range();

		/**
		 * The meta object literal for the '<em><b>Sampling Rate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENSOR__SAMPLING_RATE = eINSTANCE.getSensor_SamplingRate();

		/**
		 * The meta object literal for the '<em><b>Output Signal</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SENSOR__OUTPUT_SIGNAL = eINSTANCE.getSensor_OutputSignal();

		/**
		 * The meta object literal for the '<em><b>Impacts</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SENSOR__IMPACTS = eINSTANCE.getSensor_Impacts();

		/**
		 * The meta object literal for the '{@link labtwo.metamodel.labtwo.impl.MemoryImpl <em>Memory</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see labtwo.metamodel.labtwo.impl.MemoryImpl
		 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getMemory()
		 * @generated
		 */
		EClass MEMORY = eINSTANCE.getMemory();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEMORY__TYPE = eINSTANCE.getMemory_Type();

		/**
		 * The meta object literal for the '<em><b>Size</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEMORY__SIZE = eINSTANCE.getMemory_Size();

		/**
		 * The meta object literal for the '<em><b>Speed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEMORY__SPEED = eINSTANCE.getMemory_Speed();

		/**
		 * The meta object literal for the '{@link labtwo.metamodel.labtwo.impl.BatteryImpl <em>Battery</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see labtwo.metamodel.labtwo.impl.BatteryImpl
		 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getBattery()
		 * @generated
		 */
		EClass BATTERY = eINSTANCE.getBattery();

		/**
		 * The meta object literal for the '<em><b>Capacity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BATTERY__CAPACITY = eINSTANCE.getBattery_Capacity();

		/**
		 * The meta object literal for the '<em><b>Voltage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BATTERY__VOLTAGE = eINSTANCE.getBattery_Voltage();

		/**
		 * The meta object literal for the '<em><b>Usage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BATTERY__USAGE = eINSTANCE.getBattery_Usage();

		/**
		 * The meta object literal for the '<em><b>Charge Cycles</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BATTERY__CHARGE_CYCLES = eINSTANCE.getBattery_ChargeCycles();

		/**
		 * The meta object literal for the '<em><b>Requires</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BATTERY__REQUIRES = eINSTANCE.getBattery_Requires();

		/**
		 * The meta object literal for the '<em><b>Battery Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BATTERY__BATTERY_NAME = eINSTANCE.getBattery_BatteryName();

		/**
		 * The meta object literal for the '<em><b>Manufacturer</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BATTERY__MANUFACTURER = eINSTANCE.getBattery_Manufacturer();

		/**
		 * The meta object literal for the '{@link labtwo.metamodel.labtwo.SensorType <em>Sensor Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see labtwo.metamodel.labtwo.SensorType
		 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getSensorType()
		 * @generated
		 */
		EEnum SENSOR_TYPE = eINSTANCE.getSensorType();

		/**
		 * The meta object literal for the '{@link labtwo.metamodel.labtwo.ArchitectureType <em>Architecture Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see labtwo.metamodel.labtwo.ArchitectureType
		 * @see labtwo.metamodel.labtwo.impl.LabtwoPackageImpl#getArchitectureType()
		 * @generated
		 */
		EEnum ARCHITECTURE_TYPE = eINSTANCE.getArchitectureType();

	}

} //LabtwoPackage
