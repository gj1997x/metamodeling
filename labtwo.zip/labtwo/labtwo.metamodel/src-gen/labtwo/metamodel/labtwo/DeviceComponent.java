/**
 */
package labtwo.metamodel.labtwo;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Device Component</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link labtwo.metamodel.labtwo.DeviceComponent#getSerialNumber <em>Serial Number</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.DeviceComponent#getManufacturer <em>Manufacturer</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.DeviceComponent#getIncludes <em>Includes</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.DeviceComponent#getCanHave <em>Can Have</em>}</li>
 * </ul>
 *
 * @see labtwo.metamodel.labtwo.LabtwoPackage#getDeviceComponent()
 * @model abstract="true"
 * @generated
 */
public interface DeviceComponent extends EObject {
	/**
	 * Returns the value of the '<em><b>Serial Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Serial Number</em>' attribute.
	 * @see #setSerialNumber(String)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getDeviceComponent_SerialNumber()
	 * @model
	 * @generated
	 */
	String getSerialNumber();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.DeviceComponent#getSerialNumber <em>Serial Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Serial Number</em>' attribute.
	 * @see #getSerialNumber()
	 * @generated
	 */
	void setSerialNumber(String value);

	/**
	 * Returns the value of the '<em><b>Manufacturer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Manufacturer</em>' attribute.
	 * @see #setManufacturer(String)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getDeviceComponent_Manufacturer()
	 * @model
	 * @generated
	 */
	String getManufacturer();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.DeviceComponent#getManufacturer <em>Manufacturer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Manufacturer</em>' attribute.
	 * @see #getManufacturer()
	 * @generated
	 */
	void setManufacturer(String value);

	/**
	 * Returns the value of the '<em><b>Includes</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Includes</em>' reference.
	 * @see #setIncludes(Memory)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getDeviceComponent_Includes()
	 * @model derived="true"
	 * @generated
	 */
	Memory getIncludes();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.DeviceComponent#getIncludes <em>Includes</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Includes</em>' reference.
	 * @see #getIncludes()
	 * @generated
	 */
	void setIncludes(Memory value);

	/**
	 * Returns the value of the '<em><b>Can Have</b></em>' reference list.
	 * The list contents are of type {@link labtwo.metamodel.labtwo.Sensor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Can Have</em>' reference list.
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getDeviceComponent_CanHave()
	 * @model derived="true"
	 * @generated
	 */
	EList<Sensor> getCanHave();

} // DeviceComponent
