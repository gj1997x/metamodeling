/**
 */
package labtwo.metamodel.labtwo;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Motor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link labtwo.metamodel.labtwo.Motor#getPowerRating <em>Power Rating</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Motor#getSpeed <em>Speed</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Motor#getTorque <em>Torque</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Motor#getMotorType <em>Motor Type</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Motor#getGiveMeasurementsTo <em>Give Measurements To</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Motor#getControls <em>Controls</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Motor#getIncludedIn <em>Included In</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Motor#getCommand <em>Command</em>}</li>
 * </ul>
 *
 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMotor()
 * @model
 * @generated
 */
public interface Motor extends DeviceComponent {
	/**
	 * Returns the value of the '<em><b>Power Rating</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Power Rating</em>' attribute.
	 * @see #setPowerRating(float)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMotor_PowerRating()
	 * @model
	 * @generated
	 */
	float getPowerRating();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Motor#getPowerRating <em>Power Rating</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Power Rating</em>' attribute.
	 * @see #getPowerRating()
	 * @generated
	 */
	void setPowerRating(float value);

	/**
	 * Returns the value of the '<em><b>Speed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Speed</em>' attribute.
	 * @see #setSpeed(float)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMotor_Speed()
	 * @model
	 * @generated
	 */
	float getSpeed();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Motor#getSpeed <em>Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Speed</em>' attribute.
	 * @see #getSpeed()
	 * @generated
	 */
	void setSpeed(float value);

	/**
	 * Returns the value of the '<em><b>Torque</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Torque</em>' attribute.
	 * @see #setTorque(float)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMotor_Torque()
	 * @model
	 * @generated
	 */
	float getTorque();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Motor#getTorque <em>Torque</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Torque</em>' attribute.
	 * @see #getTorque()
	 * @generated
	 */
	void setTorque(float value);

	/**
	 * Returns the value of the '<em><b>Motor Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Motor Type</em>' attribute.
	 * @see #setMotorType(String)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMotor_MotorType()
	 * @model
	 * @generated
	 */
	String getMotorType();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Motor#getMotorType <em>Motor Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Motor Type</em>' attribute.
	 * @see #getMotorType()
	 * @generated
	 */
	void setMotorType(String value);

	/**
	 * Returns the value of the '<em><b>Give Measurements To</b></em>' reference list.
	 * The list contents are of type {@link labtwo.metamodel.labtwo.Sensor}.
	 * It is bidirectional and its opposite is '{@link labtwo.metamodel.labtwo.Sensor#getImpacts <em>Impacts</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Give Measurements To</em>' reference list.
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMotor_GiveMeasurementsTo()
	 * @see labtwo.metamodel.labtwo.Sensor#getImpacts
	 * @model opposite="impacts"
	 * @generated
	 */
	EList<Sensor> getGiveMeasurementsTo();

	/**
	 * Returns the value of the '<em><b>Controls</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link labtwo.metamodel.labtwo.Microcontroller#getControlledBy <em>Controlled By</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Controls</em>' reference.
	 * @see #setControls(Microcontroller)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMotor_Controls()
	 * @see labtwo.metamodel.labtwo.Microcontroller#getControlledBy
	 * @model opposite="controlledBy"
	 * @generated
	 */
	Microcontroller getControls();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Motor#getControls <em>Controls</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Controls</em>' reference.
	 * @see #getControls()
	 * @generated
	 */
	void setControls(Microcontroller value);

	/**
	 * Returns the value of the '<em><b>Included In</b></em>' reference list.
	 * The list contents are of type {@link labtwo.metamodel.labtwo.Battery}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Included In</em>' reference list.
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMotor_IncludedIn()
	 * @model
	 * @generated
	 */
	EList<Battery> getIncludedIn();

	/**
	 * Returns the value of the '<em><b>Command</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Command</em>' reference.
	 * @see #setCommand(Actuator)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getMotor_Command()
	 * @model
	 * @generated
	 */
	Actuator getCommand();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Motor#getCommand <em>Command</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Command</em>' reference.
	 * @see #getCommand()
	 * @generated
	 */
	void setCommand(Actuator value);

} // Motor
