/**
 */
package labtwo.metamodel.labtwo;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connectivity Module</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link labtwo.metamodel.labtwo.ConnectivityModule#getProtocol <em>Protocol</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.ConnectivityModule#getBandwidth <em>Bandwidth</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.ConnectivityModule#getRange <em>Range</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.ConnectivityModule#getIntegratedWith <em>Integrated With</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.ConnectivityModule#getConnects <em>Connects</em>}</li>
 * </ul>
 *
 * @see labtwo.metamodel.labtwo.LabtwoPackage#getConnectivityModule()
 * @model
 * @generated
 */
public interface ConnectivityModule extends DeviceComponent {
	/**
	 * Returns the value of the '<em><b>Protocol</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Protocol</em>' attribute.
	 * @see #setProtocol(String)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getConnectivityModule_Protocol()
	 * @model
	 * @generated
	 */
	String getProtocol();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.ConnectivityModule#getProtocol <em>Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Protocol</em>' attribute.
	 * @see #getProtocol()
	 * @generated
	 */
	void setProtocol(String value);

	/**
	 * Returns the value of the '<em><b>Bandwidth</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bandwidth</em>' attribute.
	 * @see #setBandwidth(float)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getConnectivityModule_Bandwidth()
	 * @model
	 * @generated
	 */
	float getBandwidth();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.ConnectivityModule#getBandwidth <em>Bandwidth</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bandwidth</em>' attribute.
	 * @see #getBandwidth()
	 * @generated
	 */
	void setBandwidth(float value);

	/**
	 * Returns the value of the '<em><b>Range</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Range</em>' attribute.
	 * @see #setRange(float)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getConnectivityModule_Range()
	 * @model
	 * @generated
	 */
	float getRange();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.ConnectivityModule#getRange <em>Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Range</em>' attribute.
	 * @see #getRange()
	 * @generated
	 */
	void setRange(float value);

	/**
	 * Returns the value of the '<em><b>Integrated With</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Integrated With</em>' reference.
	 * @see #setIntegratedWith(Battery)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getConnectivityModule_IntegratedWith()
	 * @model
	 * @generated
	 */
	Battery getIntegratedWith();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.ConnectivityModule#getIntegratedWith <em>Integrated With</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Integrated With</em>' reference.
	 * @see #getIntegratedWith()
	 * @generated
	 */
	void setIntegratedWith(Battery value);

	/**
	 * Returns the value of the '<em><b>Connects</b></em>' reference list.
	 * The list contents are of type {@link labtwo.metamodel.labtwo.Microcontroller}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connects</em>' reference list.
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getConnectivityModule_Connects()
	 * @model
	 * @generated
	 */
	EList<Microcontroller> getConnects();

} // ConnectivityModule
