/**
 */
package labtwo.metamodel.labtwo;

import java.util.Date;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Embedded System</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link labtwo.metamodel.labtwo.EmbeddedSystem#getModelNumber <em>Model Number</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.EmbeddedSystem#getReleaseDate <em>Release Date</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.EmbeddedSystem#getFirmwareVersion <em>Firmware Version</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.EmbeddedSystem#getComponents <em>Components</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.EmbeddedSystem#getImplementedWith <em>Implemented With</em>}</li>
 * </ul>
 *
 * @see labtwo.metamodel.labtwo.LabtwoPackage#getEmbeddedSystem()
 * @model
 * @generated
 */
public interface EmbeddedSystem extends EObject {
	/**
	 * Returns the value of the '<em><b>Model Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Model Number</em>' attribute.
	 * @see #setModelNumber(String)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getEmbeddedSystem_ModelNumber()
	 * @model
	 * @generated
	 */
	String getModelNumber();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.EmbeddedSystem#getModelNumber <em>Model Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Model Number</em>' attribute.
	 * @see #getModelNumber()
	 * @generated
	 */
	void setModelNumber(String value);

	/**
	 * Returns the value of the '<em><b>Release Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Release Date</em>' attribute.
	 * @see #setReleaseDate(Date)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getEmbeddedSystem_ReleaseDate()
	 * @model
	 * @generated
	 */
	Date getReleaseDate();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.EmbeddedSystem#getReleaseDate <em>Release Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Release Date</em>' attribute.
	 * @see #getReleaseDate()
	 * @generated
	 */
	void setReleaseDate(Date value);

	/**
	 * Returns the value of the '<em><b>Firmware Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Firmware Version</em>' attribute.
	 * @see #setFirmwareVersion(String)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getEmbeddedSystem_FirmwareVersion()
	 * @model
	 * @generated
	 */
	String getFirmwareVersion();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.EmbeddedSystem#getFirmwareVersion <em>Firmware Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Firmware Version</em>' attribute.
	 * @see #getFirmwareVersion()
	 * @generated
	 */
	void setFirmwareVersion(String value);

	/**
	 * Returns the value of the '<em><b>Components</b></em>' containment reference list.
	 * The list contents are of type {@link labtwo.metamodel.labtwo.DeviceComponent}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Components</em>' containment reference list.
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getEmbeddedSystem_Components()
	 * @model containment="true"
	 * @generated
	 */
	EList<DeviceComponent> getComponents();

	/**
	 * Returns the value of the '<em><b>Implemented With</b></em>' containment reference list.
	 * The list contents are of type {@link labtwo.metamodel.labtwo.Battery}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Implemented With</em>' containment reference list.
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getEmbeddedSystem_ImplementedWith()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Battery> getImplementedWith();

} // EmbeddedSystem
