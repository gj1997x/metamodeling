/**
 */
package labtwo.metamodel.labtwo;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Battery</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link labtwo.metamodel.labtwo.Battery#getCapacity <em>Capacity</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Battery#getVoltage <em>Voltage</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Battery#getUsage <em>Usage</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Battery#getChargeCycles <em>Charge Cycles</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Battery#getRequires <em>Requires</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Battery#getBatteryName <em>Battery Name</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Battery#getManufacturer <em>Manufacturer</em>}</li>
 * </ul>
 *
 * @see labtwo.metamodel.labtwo.LabtwoPackage#getBattery()
 * @model
 * @generated
 */
public interface Battery extends EObject {
	/**
	 * Returns the value of the '<em><b>Capacity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capacity</em>' attribute.
	 * @see #setCapacity(float)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getBattery_Capacity()
	 * @model
	 * @generated
	 */
	float getCapacity();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Battery#getCapacity <em>Capacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Capacity</em>' attribute.
	 * @see #getCapacity()
	 * @generated
	 */
	void setCapacity(float value);

	/**
	 * Returns the value of the '<em><b>Voltage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Voltage</em>' attribute.
	 * @see #setVoltage(float)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getBattery_Voltage()
	 * @model
	 * @generated
	 */
	float getVoltage();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Battery#getVoltage <em>Voltage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Voltage</em>' attribute.
	 * @see #getVoltage()
	 * @generated
	 */
	void setVoltage(float value);

	/**
	 * Returns the value of the '<em><b>Usage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Usage</em>' attribute.
	 * @see #setUsage(String)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getBattery_Usage()
	 * @model
	 * @generated
	 */
	String getUsage();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Battery#getUsage <em>Usage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Usage</em>' attribute.
	 * @see #getUsage()
	 * @generated
	 */
	void setUsage(String value);

	/**
	 * Returns the value of the '<em><b>Charge Cycles</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Charge Cycles</em>' attribute.
	 * @see #setChargeCycles(int)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getBattery_ChargeCycles()
	 * @model
	 * @generated
	 */
	int getChargeCycles();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Battery#getChargeCycles <em>Charge Cycles</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Charge Cycles</em>' attribute.
	 * @see #getChargeCycles()
	 * @generated
	 */
	void setChargeCycles(int value);

	/**
	 * Returns the value of the '<em><b>Requires</b></em>' reference list.
	 * The list contents are of type {@link labtwo.metamodel.labtwo.Microcontroller}.
	 * It is bidirectional and its opposite is '{@link labtwo.metamodel.labtwo.Microcontroller#getBattery <em>Battery</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Requires</em>' reference list.
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getBattery_Requires()
	 * @see labtwo.metamodel.labtwo.Microcontroller#getBattery
	 * @model opposite="battery" required="true"
	 * @generated
	 */
	EList<Microcontroller> getRequires();

	/**
	 * Returns the value of the '<em><b>Battery Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Battery Name</em>' attribute.
	 * @see #setBatteryName(String)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getBattery_BatteryName()
	 * @model
	 * @generated
	 */
	String getBatteryName();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Battery#getBatteryName <em>Battery Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Battery Name</em>' attribute.
	 * @see #getBatteryName()
	 * @generated
	 */
	void setBatteryName(String value);

	/**
	 * Returns the value of the '<em><b>Manufacturer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Manufacturer</em>' attribute.
	 * @see #setManufacturer(String)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getBattery_Manufacturer()
	 * @model
	 * @generated
	 */
	String getManufacturer();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Battery#getManufacturer <em>Manufacturer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Manufacturer</em>' attribute.
	 * @see #getManufacturer()
	 * @generated
	 */
	void setManufacturer(String value);

} // Battery
