/**
 */
package labtwo.metamodel.labtwo.impl;

import labtwo.metamodel.labtwo.Actuator;
import labtwo.metamodel.labtwo.ArchitectureType;
import labtwo.metamodel.labtwo.Battery;
import labtwo.metamodel.labtwo.ConnectivityModule;
import labtwo.metamodel.labtwo.DeviceComponent;
import labtwo.metamodel.labtwo.EmbeddedSystem;
import labtwo.metamodel.labtwo.LabtwoFactory;
import labtwo.metamodel.labtwo.LabtwoPackage;
import labtwo.metamodel.labtwo.Memory;
import labtwo.metamodel.labtwo.Microcontroller;
import labtwo.metamodel.labtwo.Motor;
import labtwo.metamodel.labtwo.Sensor;
import labtwo.metamodel.labtwo.SensorType;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class LabtwoPackageImpl extends EPackageImpl implements LabtwoPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass embeddedSystemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass deviceComponentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass actuatorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass motorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass connectivityModuleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass microcontrollerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sensorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass memoryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass batteryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum sensorTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum architectureTypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private LabtwoPackageImpl() {
		super(eNS_URI, LabtwoFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link LabtwoPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static LabtwoPackage init() {
		if (isInited)
			return (LabtwoPackage) EPackage.Registry.INSTANCE.getEPackage(LabtwoPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredLabtwoPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		LabtwoPackageImpl theLabtwoPackage = registeredLabtwoPackage instanceof LabtwoPackageImpl
				? (LabtwoPackageImpl) registeredLabtwoPackage
				: new LabtwoPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theLabtwoPackage.createPackageContents();

		// Initialize created meta-data
		theLabtwoPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theLabtwoPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(LabtwoPackage.eNS_URI, theLabtwoPackage);
		return theLabtwoPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEmbeddedSystem() {
		return embeddedSystemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEmbeddedSystem_ModelNumber() {
		return (EAttribute) embeddedSystemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEmbeddedSystem_ReleaseDate() {
		return (EAttribute) embeddedSystemEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEmbeddedSystem_FirmwareVersion() {
		return (EAttribute) embeddedSystemEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEmbeddedSystem_Components() {
		return (EReference) embeddedSystemEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEmbeddedSystem_ImplementedWith() {
		return (EReference) embeddedSystemEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDeviceComponent() {
		return deviceComponentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDeviceComponent_SerialNumber() {
		return (EAttribute) deviceComponentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDeviceComponent_Manufacturer() {
		return (EAttribute) deviceComponentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDeviceComponent_Includes() {
		return (EReference) deviceComponentEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDeviceComponent_CanHave() {
		return (EReference) deviceComponentEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getActuator() {
		return actuatorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getActuator_Type() {
		return (EAttribute) actuatorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getActuator_Range() {
		return (EAttribute) actuatorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getActuator_InputSignal() {
		return (EAttribute) actuatorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getActuator_OperatesWith() {
		return (EReference) actuatorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMotor() {
		return motorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMotor_PowerRating() {
		return (EAttribute) motorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMotor_Speed() {
		return (EAttribute) motorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMotor_Torque() {
		return (EAttribute) motorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMotor_MotorType() {
		return (EAttribute) motorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMotor_GiveMeasurementsTo() {
		return (EReference) motorEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMotor_Controls() {
		return (EReference) motorEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMotor_IncludedIn() {
		return (EReference) motorEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMotor_Command() {
		return (EReference) motorEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConnectivityModule() {
		return connectivityModuleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConnectivityModule_Protocol() {
		return (EAttribute) connectivityModuleEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConnectivityModule_Bandwidth() {
		return (EAttribute) connectivityModuleEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConnectivityModule_Range() {
		return (EAttribute) connectivityModuleEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConnectivityModule_IntegratedWith() {
		return (EReference) connectivityModuleEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConnectivityModule_Connects() {
		return (EReference) connectivityModuleEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMicrocontroller() {
		return microcontrollerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMicrocontroller_Cores() {
		return (EAttribute) microcontrollerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMicrocontroller_ClockSpeed() {
		return (EAttribute) microcontrollerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMicrocontroller_Archeticture() {
		return (EAttribute) microcontrollerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMicrocontroller_GPIOs() {
		return (EAttribute) microcontrollerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMicrocontroller_Battery() {
		return (EReference) microcontrollerEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMicrocontroller_ControlledBy() {
		return (EReference) microcontrollerEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSensor() {
		return sensorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSensor_Type() {
		return (EAttribute) sensorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSensor_Range() {
		return (EAttribute) sensorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSensor_SamplingRate() {
		return (EAttribute) sensorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSensor_OutputSignal() {
		return (EAttribute) sensorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSensor_Impacts() {
		return (EReference) sensorEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMemory() {
		return memoryEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMemory_Type() {
		return (EAttribute) memoryEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMemory_Size() {
		return (EAttribute) memoryEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMemory_Speed() {
		return (EAttribute) memoryEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBattery() {
		return batteryEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBattery_Capacity() {
		return (EAttribute) batteryEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBattery_Voltage() {
		return (EAttribute) batteryEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBattery_Usage() {
		return (EAttribute) batteryEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBattery_ChargeCycles() {
		return (EAttribute) batteryEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBattery_Requires() {
		return (EReference) batteryEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBattery_BatteryName() {
		return (EAttribute) batteryEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBattery_Manufacturer() {
		return (EAttribute) batteryEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getSensorType() {
		return sensorTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getArchitectureType() {
		return architectureTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LabtwoFactory getLabtwoFactory() {
		return (LabtwoFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		embeddedSystemEClass = createEClass(EMBEDDED_SYSTEM);
		createEAttribute(embeddedSystemEClass, EMBEDDED_SYSTEM__MODEL_NUMBER);
		createEAttribute(embeddedSystemEClass, EMBEDDED_SYSTEM__RELEASE_DATE);
		createEAttribute(embeddedSystemEClass, EMBEDDED_SYSTEM__FIRMWARE_VERSION);
		createEReference(embeddedSystemEClass, EMBEDDED_SYSTEM__COMPONENTS);
		createEReference(embeddedSystemEClass, EMBEDDED_SYSTEM__IMPLEMENTED_WITH);

		deviceComponentEClass = createEClass(DEVICE_COMPONENT);
		createEAttribute(deviceComponentEClass, DEVICE_COMPONENT__SERIAL_NUMBER);
		createEAttribute(deviceComponentEClass, DEVICE_COMPONENT__MANUFACTURER);
		createEReference(deviceComponentEClass, DEVICE_COMPONENT__INCLUDES);
		createEReference(deviceComponentEClass, DEVICE_COMPONENT__CAN_HAVE);

		actuatorEClass = createEClass(ACTUATOR);
		createEAttribute(actuatorEClass, ACTUATOR__TYPE);
		createEAttribute(actuatorEClass, ACTUATOR__RANGE);
		createEAttribute(actuatorEClass, ACTUATOR__INPUT_SIGNAL);
		createEReference(actuatorEClass, ACTUATOR__OPERATES_WITH);

		motorEClass = createEClass(MOTOR);
		createEAttribute(motorEClass, MOTOR__POWER_RATING);
		createEAttribute(motorEClass, MOTOR__SPEED);
		createEAttribute(motorEClass, MOTOR__TORQUE);
		createEAttribute(motorEClass, MOTOR__MOTOR_TYPE);
		createEReference(motorEClass, MOTOR__GIVE_MEASUREMENTS_TO);
		createEReference(motorEClass, MOTOR__CONTROLS);
		createEReference(motorEClass, MOTOR__INCLUDED_IN);
		createEReference(motorEClass, MOTOR__COMMAND);

		connectivityModuleEClass = createEClass(CONNECTIVITY_MODULE);
		createEAttribute(connectivityModuleEClass, CONNECTIVITY_MODULE__PROTOCOL);
		createEAttribute(connectivityModuleEClass, CONNECTIVITY_MODULE__BANDWIDTH);
		createEAttribute(connectivityModuleEClass, CONNECTIVITY_MODULE__RANGE);
		createEReference(connectivityModuleEClass, CONNECTIVITY_MODULE__INTEGRATED_WITH);
		createEReference(connectivityModuleEClass, CONNECTIVITY_MODULE__CONNECTS);

		microcontrollerEClass = createEClass(MICROCONTROLLER);
		createEAttribute(microcontrollerEClass, MICROCONTROLLER__CORES);
		createEAttribute(microcontrollerEClass, MICROCONTROLLER__CLOCK_SPEED);
		createEAttribute(microcontrollerEClass, MICROCONTROLLER__ARCHETICTURE);
		createEAttribute(microcontrollerEClass, MICROCONTROLLER__GPI_OS);
		createEReference(microcontrollerEClass, MICROCONTROLLER__BATTERY);
		createEReference(microcontrollerEClass, MICROCONTROLLER__CONTROLLED_BY);

		sensorEClass = createEClass(SENSOR);
		createEAttribute(sensorEClass, SENSOR__TYPE);
		createEAttribute(sensorEClass, SENSOR__RANGE);
		createEAttribute(sensorEClass, SENSOR__SAMPLING_RATE);
		createEAttribute(sensorEClass, SENSOR__OUTPUT_SIGNAL);
		createEReference(sensorEClass, SENSOR__IMPACTS);

		memoryEClass = createEClass(MEMORY);
		createEAttribute(memoryEClass, MEMORY__TYPE);
		createEAttribute(memoryEClass, MEMORY__SIZE);
		createEAttribute(memoryEClass, MEMORY__SPEED);

		batteryEClass = createEClass(BATTERY);
		createEAttribute(batteryEClass, BATTERY__CAPACITY);
		createEAttribute(batteryEClass, BATTERY__VOLTAGE);
		createEAttribute(batteryEClass, BATTERY__USAGE);
		createEAttribute(batteryEClass, BATTERY__CHARGE_CYCLES);
		createEReference(batteryEClass, BATTERY__REQUIRES);
		createEAttribute(batteryEClass, BATTERY__BATTERY_NAME);
		createEAttribute(batteryEClass, BATTERY__MANUFACTURER);

		// Create enums
		sensorTypeEEnum = createEEnum(SENSOR_TYPE);
		architectureTypeEEnum = createEEnum(ARCHITECTURE_TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		actuatorEClass.getESuperTypes().add(this.getDeviceComponent());
		motorEClass.getESuperTypes().add(this.getDeviceComponent());
		connectivityModuleEClass.getESuperTypes().add(this.getDeviceComponent());
		microcontrollerEClass.getESuperTypes().add(this.getDeviceComponent());
		sensorEClass.getESuperTypes().add(this.getDeviceComponent());
		memoryEClass.getESuperTypes().add(this.getDeviceComponent());

		// Initialize classes, features, and operations; add parameters
		initEClass(embeddedSystemEClass, EmbeddedSystem.class, "EmbeddedSystem", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getEmbeddedSystem_ModelNumber(), ecorePackage.getEString(), "modelNumber", null, 0, 1,
				EmbeddedSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getEmbeddedSystem_ReleaseDate(), ecorePackage.getEDate(), "releaseDate", null, 0, 1,
				EmbeddedSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getEmbeddedSystem_FirmwareVersion(), ecorePackage.getEString(), "firmwareVersion", null, 0, 1,
				EmbeddedSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getEmbeddedSystem_Components(), this.getDeviceComponent(), null, "components", null, 0, -1,
				EmbeddedSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEmbeddedSystem_ImplementedWith(), this.getBattery(), null, "ImplementedWith", null, 1, -1,
				EmbeddedSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(deviceComponentEClass, DeviceComponent.class, "DeviceComponent", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDeviceComponent_SerialNumber(), ecorePackage.getEString(), "serialNumber", null, 0, 1,
				DeviceComponent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getDeviceComponent_Manufacturer(), ecorePackage.getEString(), "manufacturer", null, 0, 1,
				DeviceComponent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getDeviceComponent_Includes(), this.getMemory(), null, "includes", null, 0, 1,
				DeviceComponent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getDeviceComponent_CanHave(), this.getSensor(), null, "canHave", null, 0, -1,
				DeviceComponent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(actuatorEClass, Actuator.class, "Actuator", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getActuator_Type(), ecorePackage.getEString(), "type", null, 0, 1, Actuator.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getActuator_Range(), ecorePackage.getEFloat(), "range", null, 0, 1, Actuator.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getActuator_InputSignal(), ecorePackage.getEString(), "inputSignal", null, 0, 1, Actuator.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getActuator_OperatesWith(), this.getBattery(), null, "operatesWith", null, 0, -1, Actuator.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(motorEClass, Motor.class, "Motor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMotor_PowerRating(), ecorePackage.getEFloat(), "powerRating", null, 0, 1, Motor.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMotor_Speed(), ecorePackage.getEFloat(), "speed", null, 0, 1, Motor.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMotor_Torque(), ecorePackage.getEFloat(), "torque", null, 0, 1, Motor.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMotor_MotorType(), ecorePackage.getEString(), "motorType", null, 0, 1, Motor.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMotor_GiveMeasurementsTo(), this.getSensor(), this.getSensor_Impacts(), "giveMeasurementsTo",
				null, 0, -1, Motor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMotor_Controls(), this.getMicrocontroller(), this.getMicrocontroller_ControlledBy(),
				"controls", null, 0, 1, Motor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMotor_IncludedIn(), this.getBattery(), null, "includedIn", null, 0, -1, Motor.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMotor_Command(), this.getActuator(), null, "command", null, 0, 1, Motor.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(connectivityModuleEClass, ConnectivityModule.class, "ConnectivityModule", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getConnectivityModule_Protocol(), ecorePackage.getEString(), "protocol", null, 0, 1,
				ConnectivityModule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getConnectivityModule_Bandwidth(), ecorePackage.getEFloat(), "bandwidth", null, 0, 1,
				ConnectivityModule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getConnectivityModule_Range(), ecorePackage.getEFloat(), "range", null, 0, 1,
				ConnectivityModule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getConnectivityModule_IntegratedWith(), this.getBattery(), null, "integratedWith", null, 0, 1,
				ConnectivityModule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConnectivityModule_Connects(), this.getMicrocontroller(), null, "connects", null, 0, -1,
				ConnectivityModule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(microcontrollerEClass, Microcontroller.class, "Microcontroller", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMicrocontroller_Cores(), ecorePackage.getEInt(), "cores", null, 0, 1, Microcontroller.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMicrocontroller_ClockSpeed(), ecorePackage.getEFloat(), "clockSpeed", null, 0, 1,
				Microcontroller.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getMicrocontroller_Archeticture(), this.getArchitectureType(), "archeticture", null, 0, 1,
				Microcontroller.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getMicrocontroller_GPIOs(), ecorePackage.getEInt(), "GPIOs", null, 0, 1, Microcontroller.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMicrocontroller_Battery(), this.getBattery(), this.getBattery_Requires(), "battery", null, 1,
				-1, Microcontroller.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMicrocontroller_ControlledBy(), this.getMotor(), this.getMotor_Controls(), "controlledBy",
				null, 0, -1, Microcontroller.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(sensorEClass, Sensor.class, "Sensor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSensor_Type(), this.getSensorType(), "type", "PRESSURE", 0, 1, Sensor.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSensor_Range(), ecorePackage.getEInt(), "range", null, 0, 1, Sensor.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSensor_SamplingRate(), ecorePackage.getEFloat(), "samplingRate", null, 0, 1, Sensor.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSensor_OutputSignal(), ecorePackage.getEString(), "outputSignal", null, 0, 1, Sensor.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSensor_Impacts(), this.getMotor(), this.getMotor_GiveMeasurementsTo(), "impacts", null, 1, -1,
				Sensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(memoryEClass, Memory.class, "Memory", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMemory_Type(), ecorePackage.getEString(), "type", null, 0, 1, Memory.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMemory_Size(), ecorePackage.getEInt(), "size", null, 0, 1, Memory.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMemory_Speed(), ecorePackage.getEInt(), "speed", null, 0, 1, Memory.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(batteryEClass, Battery.class, "Battery", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getBattery_Capacity(), ecorePackage.getEFloat(), "capacity", null, 0, 1, Battery.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getBattery_Voltage(), ecorePackage.getEFloat(), "voltage", null, 0, 1, Battery.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getBattery_Usage(), ecorePackage.getEString(), "usage", null, 0, 1, Battery.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getBattery_ChargeCycles(), ecorePackage.getEInt(), "chargeCycles", null, 0, 1, Battery.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getBattery_Requires(), this.getMicrocontroller(), this.getMicrocontroller_Battery(), "requires",
				null, 1, -1, Battery.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getBattery_BatteryName(), ecorePackage.getEString(), "batteryName", null, 0, 1, Battery.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getBattery_Manufacturer(), ecorePackage.getEString(), "manufacturer", null, 0, 1, Battery.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(sensorTypeEEnum, SensorType.class, "SensorType");
		addEEnumLiteral(sensorTypeEEnum, SensorType.TEMPERATURE);
		addEEnumLiteral(sensorTypeEEnum, SensorType.PRESSURE);
		addEEnumLiteral(sensorTypeEEnum, SensorType.HUMIDITY);
		addEEnumLiteral(sensorTypeEEnum, SensorType.ACCELEROMETER);

		initEEnum(architectureTypeEEnum, ArchitectureType.class, "ArchitectureType");
		addEEnumLiteral(architectureTypeEEnum, ArchitectureType.ARM);
		addEEnumLiteral(architectureTypeEEnum, ArchitectureType.MIPS);
		addEEnumLiteral(architectureTypeEEnum, ArchitectureType.AVR);
		addEEnumLiteral(architectureTypeEEnum, ArchitectureType.X86);
		addEEnumLiteral(architectureTypeEEnum, ArchitectureType.SPARC);

		// Create resource
		createResource(eNS_URI);
	}

} //LabtwoPackageImpl
