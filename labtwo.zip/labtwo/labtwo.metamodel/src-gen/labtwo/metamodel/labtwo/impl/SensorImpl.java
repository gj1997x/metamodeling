/**
 */
package labtwo.metamodel.labtwo.impl;

import java.util.Collection;

import labtwo.metamodel.labtwo.LabtwoPackage;
import labtwo.metamodel.labtwo.Motor;
import labtwo.metamodel.labtwo.Sensor;
import labtwo.metamodel.labtwo.SensorType;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Sensor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link labtwo.metamodel.labtwo.impl.SensorImpl#getType <em>Type</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.SensorImpl#getRange <em>Range</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.SensorImpl#getSamplingRate <em>Sampling Rate</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.SensorImpl#getOutputSignal <em>Output Signal</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.SensorImpl#getImpacts <em>Impacts</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SensorImpl extends DeviceComponentImpl implements Sensor {
	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final SensorType TYPE_EDEFAULT = SensorType.PRESSURE;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected SensorType type = TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getRange() <em>Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRange()
	 * @generated
	 * @ordered
	 */
	protected static final int RANGE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getRange() <em>Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRange()
	 * @generated
	 * @ordered
	 */
	protected int range = RANGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getSamplingRate() <em>Sampling Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSamplingRate()
	 * @generated
	 * @ordered
	 */
	protected static final float SAMPLING_RATE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getSamplingRate() <em>Sampling Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSamplingRate()
	 * @generated
	 * @ordered
	 */
	protected float samplingRate = SAMPLING_RATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getOutputSignal() <em>Output Signal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutputSignal()
	 * @generated
	 * @ordered
	 */
	protected static final String OUTPUT_SIGNAL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOutputSignal() <em>Output Signal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutputSignal()
	 * @generated
	 * @ordered
	 */
	protected String outputSignal = OUTPUT_SIGNAL_EDEFAULT;

	/**
	 * The cached value of the '{@link #getImpacts() <em>Impacts</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImpacts()
	 * @generated
	 * @ordered
	 */
	protected EList<Motor> impacts;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SensorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LabtwoPackage.Literals.SENSOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SensorType getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(SensorType newType) {
		SensorType oldType = type;
		type = newType == null ? TYPE_EDEFAULT : newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.SENSOR__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getRange() {
		return range;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRange(int newRange) {
		int oldRange = range;
		range = newRange;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.SENSOR__RANGE, oldRange, range));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getSamplingRate() {
		return samplingRate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSamplingRate(float newSamplingRate) {
		float oldSamplingRate = samplingRate;
		samplingRate = newSamplingRate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.SENSOR__SAMPLING_RATE, oldSamplingRate,
					samplingRate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getOutputSignal() {
		return outputSignal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOutputSignal(String newOutputSignal) {
		String oldOutputSignal = outputSignal;
		outputSignal = newOutputSignal;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.SENSOR__OUTPUT_SIGNAL, oldOutputSignal,
					outputSignal));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Motor> getImpacts() {
		if (impacts == null) {
			impacts = new EObjectWithInverseResolvingEList.ManyInverse<Motor>(Motor.class, this,
					LabtwoPackage.SENSOR__IMPACTS, LabtwoPackage.MOTOR__GIVE_MEASUREMENTS_TO);
		}
		return impacts;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case LabtwoPackage.SENSOR__IMPACTS:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getImpacts()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case LabtwoPackage.SENSOR__IMPACTS:
			return ((InternalEList<?>) getImpacts()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case LabtwoPackage.SENSOR__TYPE:
			return getType();
		case LabtwoPackage.SENSOR__RANGE:
			return getRange();
		case LabtwoPackage.SENSOR__SAMPLING_RATE:
			return getSamplingRate();
		case LabtwoPackage.SENSOR__OUTPUT_SIGNAL:
			return getOutputSignal();
		case LabtwoPackage.SENSOR__IMPACTS:
			return getImpacts();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case LabtwoPackage.SENSOR__TYPE:
			setType((SensorType) newValue);
			return;
		case LabtwoPackage.SENSOR__RANGE:
			setRange((Integer) newValue);
			return;
		case LabtwoPackage.SENSOR__SAMPLING_RATE:
			setSamplingRate((Float) newValue);
			return;
		case LabtwoPackage.SENSOR__OUTPUT_SIGNAL:
			setOutputSignal((String) newValue);
			return;
		case LabtwoPackage.SENSOR__IMPACTS:
			getImpacts().clear();
			getImpacts().addAll((Collection<? extends Motor>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case LabtwoPackage.SENSOR__TYPE:
			setType(TYPE_EDEFAULT);
			return;
		case LabtwoPackage.SENSOR__RANGE:
			setRange(RANGE_EDEFAULT);
			return;
		case LabtwoPackage.SENSOR__SAMPLING_RATE:
			setSamplingRate(SAMPLING_RATE_EDEFAULT);
			return;
		case LabtwoPackage.SENSOR__OUTPUT_SIGNAL:
			setOutputSignal(OUTPUT_SIGNAL_EDEFAULT);
			return;
		case LabtwoPackage.SENSOR__IMPACTS:
			getImpacts().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case LabtwoPackage.SENSOR__TYPE:
			return type != TYPE_EDEFAULT;
		case LabtwoPackage.SENSOR__RANGE:
			return range != RANGE_EDEFAULT;
		case LabtwoPackage.SENSOR__SAMPLING_RATE:
			return samplingRate != SAMPLING_RATE_EDEFAULT;
		case LabtwoPackage.SENSOR__OUTPUT_SIGNAL:
			return OUTPUT_SIGNAL_EDEFAULT == null ? outputSignal != null : !OUTPUT_SIGNAL_EDEFAULT.equals(outputSignal);
		case LabtwoPackage.SENSOR__IMPACTS:
			return impacts != null && !impacts.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (type: ");
		result.append(type);
		result.append(", range: ");
		result.append(range);
		result.append(", samplingRate: ");
		result.append(samplingRate);
		result.append(", outputSignal: ");
		result.append(outputSignal);
		result.append(')');
		return result.toString();
	}

} //SensorImpl
