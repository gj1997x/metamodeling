/**
 */
package labtwo.metamodel.labtwo.impl;

import java.util.Collection;
import java.util.Date;

import labtwo.metamodel.labtwo.Battery;
import labtwo.metamodel.labtwo.DeviceComponent;
import labtwo.metamodel.labtwo.EmbeddedSystem;
import labtwo.metamodel.labtwo.LabtwoPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Embedded System</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link labtwo.metamodel.labtwo.impl.EmbeddedSystemImpl#getModelNumber <em>Model Number</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.EmbeddedSystemImpl#getReleaseDate <em>Release Date</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.EmbeddedSystemImpl#getFirmwareVersion <em>Firmware Version</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.EmbeddedSystemImpl#getComponents <em>Components</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.EmbeddedSystemImpl#getImplementedWith <em>Implemented With</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EmbeddedSystemImpl extends MinimalEObjectImpl.Container implements EmbeddedSystem {
	/**
	 * The default value of the '{@link #getModelNumber() <em>Model Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModelNumber()
	 * @generated
	 * @ordered
	 */
	protected static final String MODEL_NUMBER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getModelNumber() <em>Model Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModelNumber()
	 * @generated
	 * @ordered
	 */
	protected String modelNumber = MODEL_NUMBER_EDEFAULT;

	/**
	 * The default value of the '{@link #getReleaseDate() <em>Release Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReleaseDate()
	 * @generated
	 * @ordered
	 */
	protected static final Date RELEASE_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getReleaseDate() <em>Release Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReleaseDate()
	 * @generated
	 * @ordered
	 */
	protected Date releaseDate = RELEASE_DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getFirmwareVersion() <em>Firmware Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFirmwareVersion()
	 * @generated
	 * @ordered
	 */
	protected static final String FIRMWARE_VERSION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFirmwareVersion() <em>Firmware Version</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFirmwareVersion()
	 * @generated
	 * @ordered
	 */
	protected String firmwareVersion = FIRMWARE_VERSION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getComponents() <em>Components</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComponents()
	 * @generated
	 * @ordered
	 */
	protected EList<DeviceComponent> components;

	/**
	 * The cached value of the '{@link #getImplementedWith() <em>Implemented With</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImplementedWith()
	 * @generated
	 * @ordered
	 */
	protected EList<Battery> implementedWith;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EmbeddedSystemImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LabtwoPackage.Literals.EMBEDDED_SYSTEM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getModelNumber() {
		return modelNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setModelNumber(String newModelNumber) {
		String oldModelNumber = modelNumber;
		modelNumber = newModelNumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.EMBEDDED_SYSTEM__MODEL_NUMBER,
					oldModelNumber, modelNumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Date getReleaseDate() {
		return releaseDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setReleaseDate(Date newReleaseDate) {
		Date oldReleaseDate = releaseDate;
		releaseDate = newReleaseDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.EMBEDDED_SYSTEM__RELEASE_DATE,
					oldReleaseDate, releaseDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getFirmwareVersion() {
		return firmwareVersion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFirmwareVersion(String newFirmwareVersion) {
		String oldFirmwareVersion = firmwareVersion;
		firmwareVersion = newFirmwareVersion;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.EMBEDDED_SYSTEM__FIRMWARE_VERSION,
					oldFirmwareVersion, firmwareVersion));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DeviceComponent> getComponents() {
		if (components == null) {
			components = new EObjectContainmentEList<DeviceComponent>(DeviceComponent.class, this,
					LabtwoPackage.EMBEDDED_SYSTEM__COMPONENTS);
		}
		return components;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Battery> getImplementedWith() {
		if (implementedWith == null) {
			implementedWith = new EObjectContainmentEList<Battery>(Battery.class, this,
					LabtwoPackage.EMBEDDED_SYSTEM__IMPLEMENTED_WITH);
		}
		return implementedWith;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case LabtwoPackage.EMBEDDED_SYSTEM__COMPONENTS:
			return ((InternalEList<?>) getComponents()).basicRemove(otherEnd, msgs);
		case LabtwoPackage.EMBEDDED_SYSTEM__IMPLEMENTED_WITH:
			return ((InternalEList<?>) getImplementedWith()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case LabtwoPackage.EMBEDDED_SYSTEM__MODEL_NUMBER:
			return getModelNumber();
		case LabtwoPackage.EMBEDDED_SYSTEM__RELEASE_DATE:
			return getReleaseDate();
		case LabtwoPackage.EMBEDDED_SYSTEM__FIRMWARE_VERSION:
			return getFirmwareVersion();
		case LabtwoPackage.EMBEDDED_SYSTEM__COMPONENTS:
			return getComponents();
		case LabtwoPackage.EMBEDDED_SYSTEM__IMPLEMENTED_WITH:
			return getImplementedWith();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case LabtwoPackage.EMBEDDED_SYSTEM__MODEL_NUMBER:
			setModelNumber((String) newValue);
			return;
		case LabtwoPackage.EMBEDDED_SYSTEM__RELEASE_DATE:
			setReleaseDate((Date) newValue);
			return;
		case LabtwoPackage.EMBEDDED_SYSTEM__FIRMWARE_VERSION:
			setFirmwareVersion((String) newValue);
			return;
		case LabtwoPackage.EMBEDDED_SYSTEM__COMPONENTS:
			getComponents().clear();
			getComponents().addAll((Collection<? extends DeviceComponent>) newValue);
			return;
		case LabtwoPackage.EMBEDDED_SYSTEM__IMPLEMENTED_WITH:
			getImplementedWith().clear();
			getImplementedWith().addAll((Collection<? extends Battery>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case LabtwoPackage.EMBEDDED_SYSTEM__MODEL_NUMBER:
			setModelNumber(MODEL_NUMBER_EDEFAULT);
			return;
		case LabtwoPackage.EMBEDDED_SYSTEM__RELEASE_DATE:
			setReleaseDate(RELEASE_DATE_EDEFAULT);
			return;
		case LabtwoPackage.EMBEDDED_SYSTEM__FIRMWARE_VERSION:
			setFirmwareVersion(FIRMWARE_VERSION_EDEFAULT);
			return;
		case LabtwoPackage.EMBEDDED_SYSTEM__COMPONENTS:
			getComponents().clear();
			return;
		case LabtwoPackage.EMBEDDED_SYSTEM__IMPLEMENTED_WITH:
			getImplementedWith().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case LabtwoPackage.EMBEDDED_SYSTEM__MODEL_NUMBER:
			return MODEL_NUMBER_EDEFAULT == null ? modelNumber != null : !MODEL_NUMBER_EDEFAULT.equals(modelNumber);
		case LabtwoPackage.EMBEDDED_SYSTEM__RELEASE_DATE:
			return RELEASE_DATE_EDEFAULT == null ? releaseDate != null : !RELEASE_DATE_EDEFAULT.equals(releaseDate);
		case LabtwoPackage.EMBEDDED_SYSTEM__FIRMWARE_VERSION:
			return FIRMWARE_VERSION_EDEFAULT == null ? firmwareVersion != null
					: !FIRMWARE_VERSION_EDEFAULT.equals(firmwareVersion);
		case LabtwoPackage.EMBEDDED_SYSTEM__COMPONENTS:
			return components != null && !components.isEmpty();
		case LabtwoPackage.EMBEDDED_SYSTEM__IMPLEMENTED_WITH:
			return implementedWith != null && !implementedWith.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (modelNumber: ");
		result.append(modelNumber);
		result.append(", releaseDate: ");
		result.append(releaseDate);
		result.append(", firmwareVersion: ");
		result.append(firmwareVersion);
		result.append(')');
		return result.toString();
	}

} //EmbeddedSystemImpl
