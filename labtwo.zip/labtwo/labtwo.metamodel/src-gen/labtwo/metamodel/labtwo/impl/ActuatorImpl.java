/**
 */
package labtwo.metamodel.labtwo.impl;

import java.util.Collection;

import labtwo.metamodel.labtwo.Actuator;
import labtwo.metamodel.labtwo.Battery;
import labtwo.metamodel.labtwo.LabtwoPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Actuator</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link labtwo.metamodel.labtwo.impl.ActuatorImpl#getType <em>Type</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.ActuatorImpl#getRange <em>Range</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.ActuatorImpl#getInputSignal <em>Input Signal</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.ActuatorImpl#getOperatesWith <em>Operates With</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ActuatorImpl extends DeviceComponentImpl implements Actuator {
	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final String TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected String type = TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getRange() <em>Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRange()
	 * @generated
	 * @ordered
	 */
	protected static final float RANGE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getRange() <em>Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRange()
	 * @generated
	 * @ordered
	 */
	protected float range = RANGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getInputSignal() <em>Input Signal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInputSignal()
	 * @generated
	 * @ordered
	 */
	protected static final String INPUT_SIGNAL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInputSignal() <em>Input Signal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInputSignal()
	 * @generated
	 * @ordered
	 */
	protected String inputSignal = INPUT_SIGNAL_EDEFAULT;

	/**
	 * The cached value of the '{@link #getOperatesWith() <em>Operates With</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperatesWith()
	 * @generated
	 * @ordered
	 */
	protected EList<Battery> operatesWith;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ActuatorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LabtwoPackage.Literals.ACTUATOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(String newType) {
		String oldType = type;
		type = newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.ACTUATOR__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getRange() {
		return range;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRange(float newRange) {
		float oldRange = range;
		range = newRange;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.ACTUATOR__RANGE, oldRange, range));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getInputSignal() {
		return inputSignal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInputSignal(String newInputSignal) {
		String oldInputSignal = inputSignal;
		inputSignal = newInputSignal;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.ACTUATOR__INPUT_SIGNAL, oldInputSignal,
					inputSignal));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Battery> getOperatesWith() {
		if (operatesWith == null) {
			operatesWith = new EObjectResolvingEList<Battery>(Battery.class, this,
					LabtwoPackage.ACTUATOR__OPERATES_WITH);
		}
		return operatesWith;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case LabtwoPackage.ACTUATOR__TYPE:
			return getType();
		case LabtwoPackage.ACTUATOR__RANGE:
			return getRange();
		case LabtwoPackage.ACTUATOR__INPUT_SIGNAL:
			return getInputSignal();
		case LabtwoPackage.ACTUATOR__OPERATES_WITH:
			return getOperatesWith();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case LabtwoPackage.ACTUATOR__TYPE:
			setType((String) newValue);
			return;
		case LabtwoPackage.ACTUATOR__RANGE:
			setRange((Float) newValue);
			return;
		case LabtwoPackage.ACTUATOR__INPUT_SIGNAL:
			setInputSignal((String) newValue);
			return;
		case LabtwoPackage.ACTUATOR__OPERATES_WITH:
			getOperatesWith().clear();
			getOperatesWith().addAll((Collection<? extends Battery>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case LabtwoPackage.ACTUATOR__TYPE:
			setType(TYPE_EDEFAULT);
			return;
		case LabtwoPackage.ACTUATOR__RANGE:
			setRange(RANGE_EDEFAULT);
			return;
		case LabtwoPackage.ACTUATOR__INPUT_SIGNAL:
			setInputSignal(INPUT_SIGNAL_EDEFAULT);
			return;
		case LabtwoPackage.ACTUATOR__OPERATES_WITH:
			getOperatesWith().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case LabtwoPackage.ACTUATOR__TYPE:
			return TYPE_EDEFAULT == null ? type != null : !TYPE_EDEFAULT.equals(type);
		case LabtwoPackage.ACTUATOR__RANGE:
			return range != RANGE_EDEFAULT;
		case LabtwoPackage.ACTUATOR__INPUT_SIGNAL:
			return INPUT_SIGNAL_EDEFAULT == null ? inputSignal != null : !INPUT_SIGNAL_EDEFAULT.equals(inputSignal);
		case LabtwoPackage.ACTUATOR__OPERATES_WITH:
			return operatesWith != null && !operatesWith.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (type: ");
		result.append(type);
		result.append(", range: ");
		result.append(range);
		result.append(", inputSignal: ");
		result.append(inputSignal);
		result.append(')');
		return result.toString();
	}

} //ActuatorImpl
