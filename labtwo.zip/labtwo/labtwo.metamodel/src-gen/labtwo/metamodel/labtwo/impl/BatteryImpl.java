/**
 */
package labtwo.metamodel.labtwo.impl;

import java.util.Collection;

import labtwo.metamodel.labtwo.Battery;
import labtwo.metamodel.labtwo.LabtwoPackage;
import labtwo.metamodel.labtwo.Microcontroller;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Battery</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link labtwo.metamodel.labtwo.impl.BatteryImpl#getCapacity <em>Capacity</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.BatteryImpl#getVoltage <em>Voltage</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.BatteryImpl#getUsage <em>Usage</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.BatteryImpl#getChargeCycles <em>Charge Cycles</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.BatteryImpl#getRequires <em>Requires</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.BatteryImpl#getBatteryName <em>Battery Name</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.BatteryImpl#getManufacturer <em>Manufacturer</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BatteryImpl extends MinimalEObjectImpl.Container implements Battery {
	/**
	 * The default value of the '{@link #getCapacity() <em>Capacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapacity()
	 * @generated
	 * @ordered
	 */
	protected static final float CAPACITY_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getCapacity() <em>Capacity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapacity()
	 * @generated
	 * @ordered
	 */
	protected float capacity = CAPACITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getVoltage() <em>Voltage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVoltage()
	 * @generated
	 * @ordered
	 */
	protected static final float VOLTAGE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getVoltage() <em>Voltage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVoltage()
	 * @generated
	 * @ordered
	 */
	protected float voltage = VOLTAGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getUsage() <em>Usage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUsage()
	 * @generated
	 * @ordered
	 */
	protected static final String USAGE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUsage() <em>Usage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUsage()
	 * @generated
	 * @ordered
	 */
	protected String usage = USAGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getChargeCycles() <em>Charge Cycles</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChargeCycles()
	 * @generated
	 * @ordered
	 */
	protected static final int CHARGE_CYCLES_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getChargeCycles() <em>Charge Cycles</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChargeCycles()
	 * @generated
	 * @ordered
	 */
	protected int chargeCycles = CHARGE_CYCLES_EDEFAULT;

	/**
	 * The cached value of the '{@link #getRequires() <em>Requires</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRequires()
	 * @generated
	 * @ordered
	 */
	protected EList<Microcontroller> requires;

	/**
	 * The default value of the '{@link #getBatteryName() <em>Battery Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBatteryName()
	 * @generated
	 * @ordered
	 */
	protected static final String BATTERY_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getBatteryName() <em>Battery Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBatteryName()
	 * @generated
	 * @ordered
	 */
	protected String batteryName = BATTERY_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getManufacturer() <em>Manufacturer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getManufacturer()
	 * @generated
	 * @ordered
	 */
	protected static final String MANUFACTURER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getManufacturer() <em>Manufacturer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getManufacturer()
	 * @generated
	 * @ordered
	 */
	protected String manufacturer = MANUFACTURER_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BatteryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LabtwoPackage.Literals.BATTERY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getCapacity() {
		return capacity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCapacity(float newCapacity) {
		float oldCapacity = capacity;
		capacity = newCapacity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.BATTERY__CAPACITY, oldCapacity,
					capacity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getVoltage() {
		return voltage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVoltage(float newVoltage) {
		float oldVoltage = voltage;
		voltage = newVoltage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.BATTERY__VOLTAGE, oldVoltage, voltage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getUsage() {
		return usage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUsage(String newUsage) {
		String oldUsage = usage;
		usage = newUsage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.BATTERY__USAGE, oldUsage, usage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getChargeCycles() {
		return chargeCycles;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setChargeCycles(int newChargeCycles) {
		int oldChargeCycles = chargeCycles;
		chargeCycles = newChargeCycles;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.BATTERY__CHARGE_CYCLES, oldChargeCycles,
					chargeCycles));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Microcontroller> getRequires() {
		if (requires == null) {
			requires = new EObjectWithInverseResolvingEList.ManyInverse<Microcontroller>(Microcontroller.class, this,
					LabtwoPackage.BATTERY__REQUIRES, LabtwoPackage.MICROCONTROLLER__BATTERY);
		}
		return requires;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getBatteryName() {
		return batteryName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBatteryName(String newBatteryName) {
		String oldBatteryName = batteryName;
		batteryName = newBatteryName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.BATTERY__BATTERY_NAME, oldBatteryName,
					batteryName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getManufacturer() {
		return manufacturer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setManufacturer(String newManufacturer) {
		String oldManufacturer = manufacturer;
		manufacturer = newManufacturer;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.BATTERY__MANUFACTURER, oldManufacturer,
					manufacturer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case LabtwoPackage.BATTERY__REQUIRES:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getRequires()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case LabtwoPackage.BATTERY__REQUIRES:
			return ((InternalEList<?>) getRequires()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case LabtwoPackage.BATTERY__CAPACITY:
			return getCapacity();
		case LabtwoPackage.BATTERY__VOLTAGE:
			return getVoltage();
		case LabtwoPackage.BATTERY__USAGE:
			return getUsage();
		case LabtwoPackage.BATTERY__CHARGE_CYCLES:
			return getChargeCycles();
		case LabtwoPackage.BATTERY__REQUIRES:
			return getRequires();
		case LabtwoPackage.BATTERY__BATTERY_NAME:
			return getBatteryName();
		case LabtwoPackage.BATTERY__MANUFACTURER:
			return getManufacturer();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case LabtwoPackage.BATTERY__CAPACITY:
			setCapacity((Float) newValue);
			return;
		case LabtwoPackage.BATTERY__VOLTAGE:
			setVoltage((Float) newValue);
			return;
		case LabtwoPackage.BATTERY__USAGE:
			setUsage((String) newValue);
			return;
		case LabtwoPackage.BATTERY__CHARGE_CYCLES:
			setChargeCycles((Integer) newValue);
			return;
		case LabtwoPackage.BATTERY__REQUIRES:
			getRequires().clear();
			getRequires().addAll((Collection<? extends Microcontroller>) newValue);
			return;
		case LabtwoPackage.BATTERY__BATTERY_NAME:
			setBatteryName((String) newValue);
			return;
		case LabtwoPackage.BATTERY__MANUFACTURER:
			setManufacturer((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case LabtwoPackage.BATTERY__CAPACITY:
			setCapacity(CAPACITY_EDEFAULT);
			return;
		case LabtwoPackage.BATTERY__VOLTAGE:
			setVoltage(VOLTAGE_EDEFAULT);
			return;
		case LabtwoPackage.BATTERY__USAGE:
			setUsage(USAGE_EDEFAULT);
			return;
		case LabtwoPackage.BATTERY__CHARGE_CYCLES:
			setChargeCycles(CHARGE_CYCLES_EDEFAULT);
			return;
		case LabtwoPackage.BATTERY__REQUIRES:
			getRequires().clear();
			return;
		case LabtwoPackage.BATTERY__BATTERY_NAME:
			setBatteryName(BATTERY_NAME_EDEFAULT);
			return;
		case LabtwoPackage.BATTERY__MANUFACTURER:
			setManufacturer(MANUFACTURER_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case LabtwoPackage.BATTERY__CAPACITY:
			return capacity != CAPACITY_EDEFAULT;
		case LabtwoPackage.BATTERY__VOLTAGE:
			return voltage != VOLTAGE_EDEFAULT;
		case LabtwoPackage.BATTERY__USAGE:
			return USAGE_EDEFAULT == null ? usage != null : !USAGE_EDEFAULT.equals(usage);
		case LabtwoPackage.BATTERY__CHARGE_CYCLES:
			return chargeCycles != CHARGE_CYCLES_EDEFAULT;
		case LabtwoPackage.BATTERY__REQUIRES:
			return requires != null && !requires.isEmpty();
		case LabtwoPackage.BATTERY__BATTERY_NAME:
			return BATTERY_NAME_EDEFAULT == null ? batteryName != null : !BATTERY_NAME_EDEFAULT.equals(batteryName);
		case LabtwoPackage.BATTERY__MANUFACTURER:
			return MANUFACTURER_EDEFAULT == null ? manufacturer != null : !MANUFACTURER_EDEFAULT.equals(manufacturer);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (capacity: ");
		result.append(capacity);
		result.append(", voltage: ");
		result.append(voltage);
		result.append(", usage: ");
		result.append(usage);
		result.append(", chargeCycles: ");
		result.append(chargeCycles);
		result.append(", batteryName: ");
		result.append(batteryName);
		result.append(", manufacturer: ");
		result.append(manufacturer);
		result.append(')');
		return result.toString();
	}

} //BatteryImpl
