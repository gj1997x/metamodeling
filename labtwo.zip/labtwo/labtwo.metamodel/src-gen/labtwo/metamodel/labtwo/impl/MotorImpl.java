/**
 */
package labtwo.metamodel.labtwo.impl;

import java.util.Collection;

import labtwo.metamodel.labtwo.Actuator;
import labtwo.metamodel.labtwo.Battery;
import labtwo.metamodel.labtwo.LabtwoPackage;
import labtwo.metamodel.labtwo.Microcontroller;
import labtwo.metamodel.labtwo.Motor;
import labtwo.metamodel.labtwo.Sensor;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Motor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link labtwo.metamodel.labtwo.impl.MotorImpl#getPowerRating <em>Power Rating</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.MotorImpl#getSpeed <em>Speed</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.MotorImpl#getTorque <em>Torque</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.MotorImpl#getMotorType <em>Motor Type</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.MotorImpl#getGiveMeasurementsTo <em>Give Measurements To</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.MotorImpl#getControls <em>Controls</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.MotorImpl#getIncludedIn <em>Included In</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.MotorImpl#getCommand <em>Command</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MotorImpl extends DeviceComponentImpl implements Motor {
	/**
	 * The default value of the '{@link #getPowerRating() <em>Power Rating</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPowerRating()
	 * @generated
	 * @ordered
	 */
	protected static final float POWER_RATING_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getPowerRating() <em>Power Rating</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPowerRating()
	 * @generated
	 * @ordered
	 */
	protected float powerRating = POWER_RATING_EDEFAULT;

	/**
	 * The default value of the '{@link #getSpeed() <em>Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpeed()
	 * @generated
	 * @ordered
	 */
	protected static final float SPEED_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getSpeed() <em>Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpeed()
	 * @generated
	 * @ordered
	 */
	protected float speed = SPEED_EDEFAULT;

	/**
	 * The default value of the '{@link #getTorque() <em>Torque</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTorque()
	 * @generated
	 * @ordered
	 */
	protected static final float TORQUE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getTorque() <em>Torque</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTorque()
	 * @generated
	 * @ordered
	 */
	protected float torque = TORQUE_EDEFAULT;

	/**
	 * The default value of the '{@link #getMotorType() <em>Motor Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMotorType()
	 * @generated
	 * @ordered
	 */
	protected static final String MOTOR_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getMotorType() <em>Motor Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMotorType()
	 * @generated
	 * @ordered
	 */
	protected String motorType = MOTOR_TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getGiveMeasurementsTo() <em>Give Measurements To</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGiveMeasurementsTo()
	 * @generated
	 * @ordered
	 */
	protected EList<Sensor> giveMeasurementsTo;

	/**
	 * The cached value of the '{@link #getControls() <em>Controls</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getControls()
	 * @generated
	 * @ordered
	 */
	protected Microcontroller controls;

	/**
	 * The cached value of the '{@link #getIncludedIn() <em>Included In</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIncludedIn()
	 * @generated
	 * @ordered
	 */
	protected EList<Battery> includedIn;

	/**
	 * The cached value of the '{@link #getCommand() <em>Command</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCommand()
	 * @generated
	 * @ordered
	 */
	protected Actuator command;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MotorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LabtwoPackage.Literals.MOTOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getPowerRating() {
		return powerRating;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPowerRating(float newPowerRating) {
		float oldPowerRating = powerRating;
		powerRating = newPowerRating;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.MOTOR__POWER_RATING, oldPowerRating,
					powerRating));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getSpeed() {
		return speed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSpeed(float newSpeed) {
		float oldSpeed = speed;
		speed = newSpeed;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.MOTOR__SPEED, oldSpeed, speed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getTorque() {
		return torque;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTorque(float newTorque) {
		float oldTorque = torque;
		torque = newTorque;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.MOTOR__TORQUE, oldTorque, torque));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getMotorType() {
		return motorType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMotorType(String newMotorType) {
		String oldMotorType = motorType;
		motorType = newMotorType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.MOTOR__MOTOR_TYPE, oldMotorType,
					motorType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Sensor> getGiveMeasurementsTo() {
		if (giveMeasurementsTo == null) {
			giveMeasurementsTo = new EObjectWithInverseResolvingEList.ManyInverse<Sensor>(Sensor.class, this,
					LabtwoPackage.MOTOR__GIVE_MEASUREMENTS_TO, LabtwoPackage.SENSOR__IMPACTS);
		}
		return giveMeasurementsTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Microcontroller getControls() {
		if (controls != null && controls.eIsProxy()) {
			InternalEObject oldControls = (InternalEObject) controls;
			controls = (Microcontroller) eResolveProxy(oldControls);
			if (controls != oldControls) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, LabtwoPackage.MOTOR__CONTROLS,
							oldControls, controls));
			}
		}
		return controls;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Microcontroller basicGetControls() {
		return controls;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetControls(Microcontroller newControls, NotificationChain msgs) {
		Microcontroller oldControls = controls;
		controls = newControls;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					LabtwoPackage.MOTOR__CONTROLS, oldControls, newControls);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setControls(Microcontroller newControls) {
		if (newControls != controls) {
			NotificationChain msgs = null;
			if (controls != null)
				msgs = ((InternalEObject) controls).eInverseRemove(this, LabtwoPackage.MICROCONTROLLER__CONTROLLED_BY,
						Microcontroller.class, msgs);
			if (newControls != null)
				msgs = ((InternalEObject) newControls).eInverseAdd(this, LabtwoPackage.MICROCONTROLLER__CONTROLLED_BY,
						Microcontroller.class, msgs);
			msgs = basicSetControls(newControls, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.MOTOR__CONTROLS, newControls,
					newControls));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Battery> getIncludedIn() {
		if (includedIn == null) {
			includedIn = new EObjectResolvingEList<Battery>(Battery.class, this, LabtwoPackage.MOTOR__INCLUDED_IN);
		}
		return includedIn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Actuator getCommand() {
		if (command != null && command.eIsProxy()) {
			InternalEObject oldCommand = (InternalEObject) command;
			command = (Actuator) eResolveProxy(oldCommand);
			if (command != oldCommand) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, LabtwoPackage.MOTOR__COMMAND, oldCommand,
							command));
			}
		}
		return command;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Actuator basicGetCommand() {
		return command;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCommand(Actuator newCommand) {
		Actuator oldCommand = command;
		command = newCommand;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.MOTOR__COMMAND, oldCommand, command));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case LabtwoPackage.MOTOR__GIVE_MEASUREMENTS_TO:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getGiveMeasurementsTo()).basicAdd(otherEnd,
					msgs);
		case LabtwoPackage.MOTOR__CONTROLS:
			if (controls != null)
				msgs = ((InternalEObject) controls).eInverseRemove(this, LabtwoPackage.MICROCONTROLLER__CONTROLLED_BY,
						Microcontroller.class, msgs);
			return basicSetControls((Microcontroller) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case LabtwoPackage.MOTOR__GIVE_MEASUREMENTS_TO:
			return ((InternalEList<?>) getGiveMeasurementsTo()).basicRemove(otherEnd, msgs);
		case LabtwoPackage.MOTOR__CONTROLS:
			return basicSetControls(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case LabtwoPackage.MOTOR__POWER_RATING:
			return getPowerRating();
		case LabtwoPackage.MOTOR__SPEED:
			return getSpeed();
		case LabtwoPackage.MOTOR__TORQUE:
			return getTorque();
		case LabtwoPackage.MOTOR__MOTOR_TYPE:
			return getMotorType();
		case LabtwoPackage.MOTOR__GIVE_MEASUREMENTS_TO:
			return getGiveMeasurementsTo();
		case LabtwoPackage.MOTOR__CONTROLS:
			if (resolve)
				return getControls();
			return basicGetControls();
		case LabtwoPackage.MOTOR__INCLUDED_IN:
			return getIncludedIn();
		case LabtwoPackage.MOTOR__COMMAND:
			if (resolve)
				return getCommand();
			return basicGetCommand();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case LabtwoPackage.MOTOR__POWER_RATING:
			setPowerRating((Float) newValue);
			return;
		case LabtwoPackage.MOTOR__SPEED:
			setSpeed((Float) newValue);
			return;
		case LabtwoPackage.MOTOR__TORQUE:
			setTorque((Float) newValue);
			return;
		case LabtwoPackage.MOTOR__MOTOR_TYPE:
			setMotorType((String) newValue);
			return;
		case LabtwoPackage.MOTOR__GIVE_MEASUREMENTS_TO:
			getGiveMeasurementsTo().clear();
			getGiveMeasurementsTo().addAll((Collection<? extends Sensor>) newValue);
			return;
		case LabtwoPackage.MOTOR__CONTROLS:
			setControls((Microcontroller) newValue);
			return;
		case LabtwoPackage.MOTOR__INCLUDED_IN:
			getIncludedIn().clear();
			getIncludedIn().addAll((Collection<? extends Battery>) newValue);
			return;
		case LabtwoPackage.MOTOR__COMMAND:
			setCommand((Actuator) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case LabtwoPackage.MOTOR__POWER_RATING:
			setPowerRating(POWER_RATING_EDEFAULT);
			return;
		case LabtwoPackage.MOTOR__SPEED:
			setSpeed(SPEED_EDEFAULT);
			return;
		case LabtwoPackage.MOTOR__TORQUE:
			setTorque(TORQUE_EDEFAULT);
			return;
		case LabtwoPackage.MOTOR__MOTOR_TYPE:
			setMotorType(MOTOR_TYPE_EDEFAULT);
			return;
		case LabtwoPackage.MOTOR__GIVE_MEASUREMENTS_TO:
			getGiveMeasurementsTo().clear();
			return;
		case LabtwoPackage.MOTOR__CONTROLS:
			setControls((Microcontroller) null);
			return;
		case LabtwoPackage.MOTOR__INCLUDED_IN:
			getIncludedIn().clear();
			return;
		case LabtwoPackage.MOTOR__COMMAND:
			setCommand((Actuator) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case LabtwoPackage.MOTOR__POWER_RATING:
			return powerRating != POWER_RATING_EDEFAULT;
		case LabtwoPackage.MOTOR__SPEED:
			return speed != SPEED_EDEFAULT;
		case LabtwoPackage.MOTOR__TORQUE:
			return torque != TORQUE_EDEFAULT;
		case LabtwoPackage.MOTOR__MOTOR_TYPE:
			return MOTOR_TYPE_EDEFAULT == null ? motorType != null : !MOTOR_TYPE_EDEFAULT.equals(motorType);
		case LabtwoPackage.MOTOR__GIVE_MEASUREMENTS_TO:
			return giveMeasurementsTo != null && !giveMeasurementsTo.isEmpty();
		case LabtwoPackage.MOTOR__CONTROLS:
			return controls != null;
		case LabtwoPackage.MOTOR__INCLUDED_IN:
			return includedIn != null && !includedIn.isEmpty();
		case LabtwoPackage.MOTOR__COMMAND:
			return command != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (powerRating: ");
		result.append(powerRating);
		result.append(", speed: ");
		result.append(speed);
		result.append(", torque: ");
		result.append(torque);
		result.append(", motorType: ");
		result.append(motorType);
		result.append(')');
		return result.toString();
	}

} //MotorImpl
