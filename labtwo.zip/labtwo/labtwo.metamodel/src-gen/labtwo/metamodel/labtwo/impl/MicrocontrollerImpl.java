/**
 */
package labtwo.metamodel.labtwo.impl;

import java.util.Collection;

import labtwo.metamodel.labtwo.ArchitectureType;
import labtwo.metamodel.labtwo.Battery;
import labtwo.metamodel.labtwo.LabtwoPackage;
import labtwo.metamodel.labtwo.Microcontroller;
import labtwo.metamodel.labtwo.Motor;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Microcontroller</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link labtwo.metamodel.labtwo.impl.MicrocontrollerImpl#getCores <em>Cores</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.MicrocontrollerImpl#getClockSpeed <em>Clock Speed</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.MicrocontrollerImpl#getArcheticture <em>Archeticture</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.MicrocontrollerImpl#getGPIOs <em>GPI Os</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.MicrocontrollerImpl#getBattery <em>Battery</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.MicrocontrollerImpl#getControlledBy <em>Controlled By</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MicrocontrollerImpl extends DeviceComponentImpl implements Microcontroller {
	/**
	 * The default value of the '{@link #getCores() <em>Cores</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCores()
	 * @generated
	 * @ordered
	 */
	protected static final int CORES_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCores() <em>Cores</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCores()
	 * @generated
	 * @ordered
	 */
	protected int cores = CORES_EDEFAULT;

	/**
	 * The default value of the '{@link #getClockSpeed() <em>Clock Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClockSpeed()
	 * @generated
	 * @ordered
	 */
	protected static final float CLOCK_SPEED_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getClockSpeed() <em>Clock Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClockSpeed()
	 * @generated
	 * @ordered
	 */
	protected float clockSpeed = CLOCK_SPEED_EDEFAULT;

	/**
	 * The default value of the '{@link #getArcheticture() <em>Archeticture</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArcheticture()
	 * @generated
	 * @ordered
	 */
	protected static final ArchitectureType ARCHETICTURE_EDEFAULT = ArchitectureType.ARM;

	/**
	 * The cached value of the '{@link #getArcheticture() <em>Archeticture</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArcheticture()
	 * @generated
	 * @ordered
	 */
	protected ArchitectureType archeticture = ARCHETICTURE_EDEFAULT;

	/**
	 * The default value of the '{@link #getGPIOs() <em>GPI Os</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGPIOs()
	 * @generated
	 * @ordered
	 */
	protected static final int GPI_OS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getGPIOs() <em>GPI Os</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGPIOs()
	 * @generated
	 * @ordered
	 */
	protected int gpiOs = GPI_OS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getBattery() <em>Battery</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBattery()
	 * @generated
	 * @ordered
	 */
	protected EList<Battery> battery;

	/**
	 * The cached value of the '{@link #getControlledBy() <em>Controlled By</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getControlledBy()
	 * @generated
	 * @ordered
	 */
	protected EList<Motor> controlledBy;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MicrocontrollerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LabtwoPackage.Literals.MICROCONTROLLER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getCores() {
		return cores;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCores(int newCores) {
		int oldCores = cores;
		cores = newCores;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.MICROCONTROLLER__CORES, oldCores,
					cores));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getClockSpeed() {
		return clockSpeed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setClockSpeed(float newClockSpeed) {
		float oldClockSpeed = clockSpeed;
		clockSpeed = newClockSpeed;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.MICROCONTROLLER__CLOCK_SPEED,
					oldClockSpeed, clockSpeed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ArchitectureType getArcheticture() {
		return archeticture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setArcheticture(ArchitectureType newArcheticture) {
		ArchitectureType oldArcheticture = archeticture;
		archeticture = newArcheticture == null ? ARCHETICTURE_EDEFAULT : newArcheticture;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.MICROCONTROLLER__ARCHETICTURE,
					oldArcheticture, archeticture));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getGPIOs() {
		return gpiOs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGPIOs(int newGPIOs) {
		int oldGPIOs = gpiOs;
		gpiOs = newGPIOs;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.MICROCONTROLLER__GPI_OS, oldGPIOs,
					gpiOs));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Battery> getBattery() {
		if (battery == null) {
			battery = new EObjectWithInverseResolvingEList.ManyInverse<Battery>(Battery.class, this,
					LabtwoPackage.MICROCONTROLLER__BATTERY, LabtwoPackage.BATTERY__REQUIRES);
		}
		return battery;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Motor> getControlledBy() {
		if (controlledBy == null) {
			controlledBy = new EObjectWithInverseResolvingEList<Motor>(Motor.class, this,
					LabtwoPackage.MICROCONTROLLER__CONTROLLED_BY, LabtwoPackage.MOTOR__CONTROLS);
		}
		return controlledBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case LabtwoPackage.MICROCONTROLLER__BATTERY:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getBattery()).basicAdd(otherEnd, msgs);
		case LabtwoPackage.MICROCONTROLLER__CONTROLLED_BY:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getControlledBy()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case LabtwoPackage.MICROCONTROLLER__BATTERY:
			return ((InternalEList<?>) getBattery()).basicRemove(otherEnd, msgs);
		case LabtwoPackage.MICROCONTROLLER__CONTROLLED_BY:
			return ((InternalEList<?>) getControlledBy()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case LabtwoPackage.MICROCONTROLLER__CORES:
			return getCores();
		case LabtwoPackage.MICROCONTROLLER__CLOCK_SPEED:
			return getClockSpeed();
		case LabtwoPackage.MICROCONTROLLER__ARCHETICTURE:
			return getArcheticture();
		case LabtwoPackage.MICROCONTROLLER__GPI_OS:
			return getGPIOs();
		case LabtwoPackage.MICROCONTROLLER__BATTERY:
			return getBattery();
		case LabtwoPackage.MICROCONTROLLER__CONTROLLED_BY:
			return getControlledBy();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case LabtwoPackage.MICROCONTROLLER__CORES:
			setCores((Integer) newValue);
			return;
		case LabtwoPackage.MICROCONTROLLER__CLOCK_SPEED:
			setClockSpeed((Float) newValue);
			return;
		case LabtwoPackage.MICROCONTROLLER__ARCHETICTURE:
			setArcheticture((ArchitectureType) newValue);
			return;
		case LabtwoPackage.MICROCONTROLLER__GPI_OS:
			setGPIOs((Integer) newValue);
			return;
		case LabtwoPackage.MICROCONTROLLER__BATTERY:
			getBattery().clear();
			getBattery().addAll((Collection<? extends Battery>) newValue);
			return;
		case LabtwoPackage.MICROCONTROLLER__CONTROLLED_BY:
			getControlledBy().clear();
			getControlledBy().addAll((Collection<? extends Motor>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case LabtwoPackage.MICROCONTROLLER__CORES:
			setCores(CORES_EDEFAULT);
			return;
		case LabtwoPackage.MICROCONTROLLER__CLOCK_SPEED:
			setClockSpeed(CLOCK_SPEED_EDEFAULT);
			return;
		case LabtwoPackage.MICROCONTROLLER__ARCHETICTURE:
			setArcheticture(ARCHETICTURE_EDEFAULT);
			return;
		case LabtwoPackage.MICROCONTROLLER__GPI_OS:
			setGPIOs(GPI_OS_EDEFAULT);
			return;
		case LabtwoPackage.MICROCONTROLLER__BATTERY:
			getBattery().clear();
			return;
		case LabtwoPackage.MICROCONTROLLER__CONTROLLED_BY:
			getControlledBy().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case LabtwoPackage.MICROCONTROLLER__CORES:
			return cores != CORES_EDEFAULT;
		case LabtwoPackage.MICROCONTROLLER__CLOCK_SPEED:
			return clockSpeed != CLOCK_SPEED_EDEFAULT;
		case LabtwoPackage.MICROCONTROLLER__ARCHETICTURE:
			return archeticture != ARCHETICTURE_EDEFAULT;
		case LabtwoPackage.MICROCONTROLLER__GPI_OS:
			return gpiOs != GPI_OS_EDEFAULT;
		case LabtwoPackage.MICROCONTROLLER__BATTERY:
			return battery != null && !battery.isEmpty();
		case LabtwoPackage.MICROCONTROLLER__CONTROLLED_BY:
			return controlledBy != null && !controlledBy.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (cores: ");
		result.append(cores);
		result.append(", clockSpeed: ");
		result.append(clockSpeed);
		result.append(", archeticture: ");
		result.append(archeticture);
		result.append(", GPIOs: ");
		result.append(gpiOs);
		result.append(')');
		return result.toString();
	}

} //MicrocontrollerImpl
