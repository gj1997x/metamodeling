/**
 */
package labtwo.metamodel.labtwo.impl;

import java.util.Collection;
import labtwo.metamodel.labtwo.Battery;
import labtwo.metamodel.labtwo.ConnectivityModule;
import labtwo.metamodel.labtwo.LabtwoPackage;

import labtwo.metamodel.labtwo.Microcontroller;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Connectivity Module</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link labtwo.metamodel.labtwo.impl.ConnectivityModuleImpl#getProtocol <em>Protocol</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.ConnectivityModuleImpl#getBandwidth <em>Bandwidth</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.ConnectivityModuleImpl#getRange <em>Range</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.ConnectivityModuleImpl#getIntegratedWith <em>Integrated With</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.impl.ConnectivityModuleImpl#getConnects <em>Connects</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConnectivityModuleImpl extends DeviceComponentImpl implements ConnectivityModule {
	/**
	 * The default value of the '{@link #getProtocol() <em>Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProtocol()
	 * @generated
	 * @ordered
	 */
	protected static final String PROTOCOL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProtocol() <em>Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProtocol()
	 * @generated
	 * @ordered
	 */
	protected String protocol = PROTOCOL_EDEFAULT;

	/**
	 * The default value of the '{@link #getBandwidth() <em>Bandwidth</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBandwidth()
	 * @generated
	 * @ordered
	 */
	protected static final float BANDWIDTH_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getBandwidth() <em>Bandwidth</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBandwidth()
	 * @generated
	 * @ordered
	 */
	protected float bandwidth = BANDWIDTH_EDEFAULT;

	/**
	 * The default value of the '{@link #getRange() <em>Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRange()
	 * @generated
	 * @ordered
	 */
	protected static final float RANGE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getRange() <em>Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRange()
	 * @generated
	 * @ordered
	 */
	protected float range = RANGE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getIntegratedWith() <em>Integrated With</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIntegratedWith()
	 * @generated
	 * @ordered
	 */
	protected Battery integratedWith;

	/**
	 * The cached value of the '{@link #getConnects() <em>Connects</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnects()
	 * @generated
	 * @ordered
	 */
	protected EList<Microcontroller> connects;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConnectivityModuleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LabtwoPackage.Literals.CONNECTIVITY_MODULE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getProtocol() {
		return protocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProtocol(String newProtocol) {
		String oldProtocol = protocol;
		protocol = newProtocol;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.CONNECTIVITY_MODULE__PROTOCOL,
					oldProtocol, protocol));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getBandwidth() {
		return bandwidth;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBandwidth(float newBandwidth) {
		float oldBandwidth = bandwidth;
		bandwidth = newBandwidth;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.CONNECTIVITY_MODULE__BANDWIDTH,
					oldBandwidth, bandwidth));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getRange() {
		return range;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRange(float newRange) {
		float oldRange = range;
		range = newRange;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.CONNECTIVITY_MODULE__RANGE, oldRange,
					range));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Battery getIntegratedWith() {
		if (integratedWith != null && integratedWith.eIsProxy()) {
			InternalEObject oldIntegratedWith = (InternalEObject) integratedWith;
			integratedWith = (Battery) eResolveProxy(oldIntegratedWith);
			if (integratedWith != oldIntegratedWith) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							LabtwoPackage.CONNECTIVITY_MODULE__INTEGRATED_WITH, oldIntegratedWith, integratedWith));
			}
		}
		return integratedWith;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Battery basicGetIntegratedWith() {
		return integratedWith;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIntegratedWith(Battery newIntegratedWith) {
		Battery oldIntegratedWith = integratedWith;
		integratedWith = newIntegratedWith;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LabtwoPackage.CONNECTIVITY_MODULE__INTEGRATED_WITH,
					oldIntegratedWith, integratedWith));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Microcontroller> getConnects() {
		if (connects == null) {
			connects = new EObjectResolvingEList<Microcontroller>(Microcontroller.class, this,
					LabtwoPackage.CONNECTIVITY_MODULE__CONNECTS);
		}
		return connects;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case LabtwoPackage.CONNECTIVITY_MODULE__PROTOCOL:
			return getProtocol();
		case LabtwoPackage.CONNECTIVITY_MODULE__BANDWIDTH:
			return getBandwidth();
		case LabtwoPackage.CONNECTIVITY_MODULE__RANGE:
			return getRange();
		case LabtwoPackage.CONNECTIVITY_MODULE__INTEGRATED_WITH:
			if (resolve)
				return getIntegratedWith();
			return basicGetIntegratedWith();
		case LabtwoPackage.CONNECTIVITY_MODULE__CONNECTS:
			return getConnects();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case LabtwoPackage.CONNECTIVITY_MODULE__PROTOCOL:
			setProtocol((String) newValue);
			return;
		case LabtwoPackage.CONNECTIVITY_MODULE__BANDWIDTH:
			setBandwidth((Float) newValue);
			return;
		case LabtwoPackage.CONNECTIVITY_MODULE__RANGE:
			setRange((Float) newValue);
			return;
		case LabtwoPackage.CONNECTIVITY_MODULE__INTEGRATED_WITH:
			setIntegratedWith((Battery) newValue);
			return;
		case LabtwoPackage.CONNECTIVITY_MODULE__CONNECTS:
			getConnects().clear();
			getConnects().addAll((Collection<? extends Microcontroller>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case LabtwoPackage.CONNECTIVITY_MODULE__PROTOCOL:
			setProtocol(PROTOCOL_EDEFAULT);
			return;
		case LabtwoPackage.CONNECTIVITY_MODULE__BANDWIDTH:
			setBandwidth(BANDWIDTH_EDEFAULT);
			return;
		case LabtwoPackage.CONNECTIVITY_MODULE__RANGE:
			setRange(RANGE_EDEFAULT);
			return;
		case LabtwoPackage.CONNECTIVITY_MODULE__INTEGRATED_WITH:
			setIntegratedWith((Battery) null);
			return;
		case LabtwoPackage.CONNECTIVITY_MODULE__CONNECTS:
			getConnects().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case LabtwoPackage.CONNECTIVITY_MODULE__PROTOCOL:
			return PROTOCOL_EDEFAULT == null ? protocol != null : !PROTOCOL_EDEFAULT.equals(protocol);
		case LabtwoPackage.CONNECTIVITY_MODULE__BANDWIDTH:
			return bandwidth != BANDWIDTH_EDEFAULT;
		case LabtwoPackage.CONNECTIVITY_MODULE__RANGE:
			return range != RANGE_EDEFAULT;
		case LabtwoPackage.CONNECTIVITY_MODULE__INTEGRATED_WITH:
			return integratedWith != null;
		case LabtwoPackage.CONNECTIVITY_MODULE__CONNECTS:
			return connects != null && !connects.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (protocol: ");
		result.append(protocol);
		result.append(", bandwidth: ");
		result.append(bandwidth);
		result.append(", range: ");
		result.append(range);
		result.append(')');
		return result.toString();
	}

} //ConnectivityModuleImpl
