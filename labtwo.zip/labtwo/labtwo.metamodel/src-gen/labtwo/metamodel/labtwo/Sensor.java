/**
 */
package labtwo.metamodel.labtwo;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link labtwo.metamodel.labtwo.Sensor#getType <em>Type</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Sensor#getRange <em>Range</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Sensor#getSamplingRate <em>Sampling Rate</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Sensor#getOutputSignal <em>Output Signal</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Sensor#getImpacts <em>Impacts</em>}</li>
 * </ul>
 *
 * @see labtwo.metamodel.labtwo.LabtwoPackage#getSensor()
 * @model
 * @generated
 */
public interface Sensor extends DeviceComponent {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The default value is <code>"PRESSURE"</code>.
	 * The literals are from the enumeration {@link labtwo.metamodel.labtwo.SensorType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see labtwo.metamodel.labtwo.SensorType
	 * @see #setType(SensorType)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getSensor_Type()
	 * @model default="PRESSURE"
	 * @generated
	 */
	SensorType getType();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Sensor#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see labtwo.metamodel.labtwo.SensorType
	 * @see #getType()
	 * @generated
	 */
	void setType(SensorType value);

	/**
	 * Returns the value of the '<em><b>Range</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Range</em>' attribute.
	 * @see #setRange(int)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getSensor_Range()
	 * @model
	 * @generated
	 */
	int getRange();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Sensor#getRange <em>Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Range</em>' attribute.
	 * @see #getRange()
	 * @generated
	 */
	void setRange(int value);

	/**
	 * Returns the value of the '<em><b>Sampling Rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sampling Rate</em>' attribute.
	 * @see #setSamplingRate(float)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getSensor_SamplingRate()
	 * @model
	 * @generated
	 */
	float getSamplingRate();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Sensor#getSamplingRate <em>Sampling Rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sampling Rate</em>' attribute.
	 * @see #getSamplingRate()
	 * @generated
	 */
	void setSamplingRate(float value);

	/**
	 * Returns the value of the '<em><b>Output Signal</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Output Signal</em>' attribute.
	 * @see #setOutputSignal(String)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getSensor_OutputSignal()
	 * @model
	 * @generated
	 */
	String getOutputSignal();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Sensor#getOutputSignal <em>Output Signal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Output Signal</em>' attribute.
	 * @see #getOutputSignal()
	 * @generated
	 */
	void setOutputSignal(String value);

	/**
	 * Returns the value of the '<em><b>Impacts</b></em>' reference list.
	 * The list contents are of type {@link labtwo.metamodel.labtwo.Motor}.
	 * It is bidirectional and its opposite is '{@link labtwo.metamodel.labtwo.Motor#getGiveMeasurementsTo <em>Give Measurements To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Impacts</em>' reference list.
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getSensor_Impacts()
	 * @see labtwo.metamodel.labtwo.Motor#getGiveMeasurementsTo
	 * @model opposite="giveMeasurementsTo" required="true"
	 * @generated
	 */
	EList<Motor> getImpacts();

} // Sensor
