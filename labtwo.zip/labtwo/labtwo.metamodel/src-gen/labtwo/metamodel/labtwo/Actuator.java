/**
 */
package labtwo.metamodel.labtwo;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Actuator</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link labtwo.metamodel.labtwo.Actuator#getType <em>Type</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Actuator#getRange <em>Range</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Actuator#getInputSignal <em>Input Signal</em>}</li>
 *   <li>{@link labtwo.metamodel.labtwo.Actuator#getOperatesWith <em>Operates With</em>}</li>
 * </ul>
 *
 * @see labtwo.metamodel.labtwo.LabtwoPackage#getActuator()
 * @model
 * @generated
 */
public interface Actuator extends DeviceComponent {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getActuator_Type()
	 * @model
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Actuator#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Range</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Range</em>' attribute.
	 * @see #setRange(float)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getActuator_Range()
	 * @model
	 * @generated
	 */
	float getRange();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Actuator#getRange <em>Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Range</em>' attribute.
	 * @see #getRange()
	 * @generated
	 */
	void setRange(float value);

	/**
	 * Returns the value of the '<em><b>Input Signal</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Input Signal</em>' attribute.
	 * @see #setInputSignal(String)
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getActuator_InputSignal()
	 * @model
	 * @generated
	 */
	String getInputSignal();

	/**
	 * Sets the value of the '{@link labtwo.metamodel.labtwo.Actuator#getInputSignal <em>Input Signal</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Input Signal</em>' attribute.
	 * @see #getInputSignal()
	 * @generated
	 */
	void setInputSignal(String value);

	/**
	 * Returns the value of the '<em><b>Operates With</b></em>' reference list.
	 * The list contents are of type {@link labtwo.metamodel.labtwo.Battery}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operates With</em>' reference list.
	 * @see labtwo.metamodel.labtwo.LabtwoPackage#getActuator_OperatesWith()
	 * @model
	 * @generated
	 */
	EList<Battery> getOperatesWith();

} // Actuator
