package labtwo.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import labtwo.services.DslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'EmbeddedSystem'", "'{'", "'modelNumber'", "'releaseDate'", "'firmwareVersion'", "'components'", "','", "'}'", "'ImplementedWith'", "'EDate'", "'Battery'", "'capacity'", "'voltage'", "'usage'", "'chargeCycles'", "'batteryName'", "'manufacturer'", "'requires'", "'('", "')'", "'Actuator'", "'serialNumber'", "'type'", "'range'", "'inputSignal'", "'operatesWith'", "'Motor'", "'powerRating'", "'speed'", "'torque'", "'motorType'", "'giveMeasurementsTo'", "'controls'", "'includedIn'", "'command'", "'ConnectivityModule'", "'protocol'", "'bandwidth'", "'integratedWith'", "'connects'", "'Microcontroller'", "'cores'", "'clockSpeed'", "'archeticture'", "'GPIOs'", "'battery'", "'controlledBy'", "'Sensor'", "'samplingRate'", "'outputSignal'", "'impacts'", "'Memory'", "'size'", "'-'", "'.'", "'E'", "'e'", "'ARM'", "'MIPS'", "'AVR'", "'x86'", "'SPARC'", "'TEMPERATURE'", "'PRESSURE'", "'HUMIDITY'", "'ACCELEROMETER'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__59=59;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=5;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__67=67;
    public static final int T__24=24;
    public static final int T__68=68;
    public static final int T__25=25;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__20=20;
    public static final int T__64=64;
    public static final int T__21=21;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int T__73=73;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__74=74;
    public static final int T__31=31;
    public static final int T__75=75;
    public static final int T__32=32;
    public static final int T__76=76;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalDsl.g"; }



     	private DslGrammarAccess grammarAccess;

        public InternalDslParser(TokenStream input, DslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "EmbeddedSystem";
       	}

       	@Override
       	protected DslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleEmbeddedSystem"
    // InternalDsl.g:65:1: entryRuleEmbeddedSystem returns [EObject current=null] : iv_ruleEmbeddedSystem= ruleEmbeddedSystem EOF ;
    public final EObject entryRuleEmbeddedSystem() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEmbeddedSystem = null;


        try {
            // InternalDsl.g:65:55: (iv_ruleEmbeddedSystem= ruleEmbeddedSystem EOF )
            // InternalDsl.g:66:2: iv_ruleEmbeddedSystem= ruleEmbeddedSystem EOF
            {
             newCompositeNode(grammarAccess.getEmbeddedSystemRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEmbeddedSystem=ruleEmbeddedSystem();

            state._fsp--;

             current =iv_ruleEmbeddedSystem; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEmbeddedSystem"


    // $ANTLR start "ruleEmbeddedSystem"
    // InternalDsl.g:72:1: ruleEmbeddedSystem returns [EObject current=null] : (otherlv_0= 'EmbeddedSystem' otherlv_1= '{' (otherlv_2= 'modelNumber' ( (lv_modelNumber_3_0= ruleEString ) ) )? (otherlv_4= 'releaseDate' ( (lv_releaseDate_5_0= ruleEDate ) ) )? (otherlv_6= 'firmwareVersion' ( (lv_firmwareVersion_7_0= ruleEString ) ) )? (otherlv_8= 'components' otherlv_9= '{' ( (lv_components_10_0= ruleDeviceComponent ) ) (otherlv_11= ',' ( (lv_components_12_0= ruleDeviceComponent ) ) )* otherlv_13= '}' )? otherlv_14= 'ImplementedWith' otherlv_15= '{' ( (lv_ImplementedWith_16_0= ruleBattery ) ) (otherlv_17= ',' ( (lv_ImplementedWith_18_0= ruleBattery ) ) )* otherlv_19= '}' otherlv_20= '}' ) ;
    public final EObject ruleEmbeddedSystem() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        Token otherlv_14=null;
        Token otherlv_15=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        Token otherlv_20=null;
        AntlrDatatypeRuleToken lv_modelNumber_3_0 = null;

        AntlrDatatypeRuleToken lv_releaseDate_5_0 = null;

        AntlrDatatypeRuleToken lv_firmwareVersion_7_0 = null;

        EObject lv_components_10_0 = null;

        EObject lv_components_12_0 = null;

        EObject lv_ImplementedWith_16_0 = null;

        EObject lv_ImplementedWith_18_0 = null;



        	enterRule();

        try {
            // InternalDsl.g:78:2: ( (otherlv_0= 'EmbeddedSystem' otherlv_1= '{' (otherlv_2= 'modelNumber' ( (lv_modelNumber_3_0= ruleEString ) ) )? (otherlv_4= 'releaseDate' ( (lv_releaseDate_5_0= ruleEDate ) ) )? (otherlv_6= 'firmwareVersion' ( (lv_firmwareVersion_7_0= ruleEString ) ) )? (otherlv_8= 'components' otherlv_9= '{' ( (lv_components_10_0= ruleDeviceComponent ) ) (otherlv_11= ',' ( (lv_components_12_0= ruleDeviceComponent ) ) )* otherlv_13= '}' )? otherlv_14= 'ImplementedWith' otherlv_15= '{' ( (lv_ImplementedWith_16_0= ruleBattery ) ) (otherlv_17= ',' ( (lv_ImplementedWith_18_0= ruleBattery ) ) )* otherlv_19= '}' otherlv_20= '}' ) )
            // InternalDsl.g:79:2: (otherlv_0= 'EmbeddedSystem' otherlv_1= '{' (otherlv_2= 'modelNumber' ( (lv_modelNumber_3_0= ruleEString ) ) )? (otherlv_4= 'releaseDate' ( (lv_releaseDate_5_0= ruleEDate ) ) )? (otherlv_6= 'firmwareVersion' ( (lv_firmwareVersion_7_0= ruleEString ) ) )? (otherlv_8= 'components' otherlv_9= '{' ( (lv_components_10_0= ruleDeviceComponent ) ) (otherlv_11= ',' ( (lv_components_12_0= ruleDeviceComponent ) ) )* otherlv_13= '}' )? otherlv_14= 'ImplementedWith' otherlv_15= '{' ( (lv_ImplementedWith_16_0= ruleBattery ) ) (otherlv_17= ',' ( (lv_ImplementedWith_18_0= ruleBattery ) ) )* otherlv_19= '}' otherlv_20= '}' )
            {
            // InternalDsl.g:79:2: (otherlv_0= 'EmbeddedSystem' otherlv_1= '{' (otherlv_2= 'modelNumber' ( (lv_modelNumber_3_0= ruleEString ) ) )? (otherlv_4= 'releaseDate' ( (lv_releaseDate_5_0= ruleEDate ) ) )? (otherlv_6= 'firmwareVersion' ( (lv_firmwareVersion_7_0= ruleEString ) ) )? (otherlv_8= 'components' otherlv_9= '{' ( (lv_components_10_0= ruleDeviceComponent ) ) (otherlv_11= ',' ( (lv_components_12_0= ruleDeviceComponent ) ) )* otherlv_13= '}' )? otherlv_14= 'ImplementedWith' otherlv_15= '{' ( (lv_ImplementedWith_16_0= ruleBattery ) ) (otherlv_17= ',' ( (lv_ImplementedWith_18_0= ruleBattery ) ) )* otherlv_19= '}' otherlv_20= '}' )
            // InternalDsl.g:80:3: otherlv_0= 'EmbeddedSystem' otherlv_1= '{' (otherlv_2= 'modelNumber' ( (lv_modelNumber_3_0= ruleEString ) ) )? (otherlv_4= 'releaseDate' ( (lv_releaseDate_5_0= ruleEDate ) ) )? (otherlv_6= 'firmwareVersion' ( (lv_firmwareVersion_7_0= ruleEString ) ) )? (otherlv_8= 'components' otherlv_9= '{' ( (lv_components_10_0= ruleDeviceComponent ) ) (otherlv_11= ',' ( (lv_components_12_0= ruleDeviceComponent ) ) )* otherlv_13= '}' )? otherlv_14= 'ImplementedWith' otherlv_15= '{' ( (lv_ImplementedWith_16_0= ruleBattery ) ) (otherlv_17= ',' ( (lv_ImplementedWith_18_0= ruleBattery ) ) )* otherlv_19= '}' otherlv_20= '}'
            {
            otherlv_0=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getEmbeddedSystemAccess().getEmbeddedSystemKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getEmbeddedSystemAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalDsl.g:88:3: (otherlv_2= 'modelNumber' ( (lv_modelNumber_3_0= ruleEString ) ) )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==13) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalDsl.g:89:4: otherlv_2= 'modelNumber' ( (lv_modelNumber_3_0= ruleEString ) )
                    {
                    otherlv_2=(Token)match(input,13,FOLLOW_5); 

                    				newLeafNode(otherlv_2, grammarAccess.getEmbeddedSystemAccess().getModelNumberKeyword_2_0());
                    			
                    // InternalDsl.g:93:4: ( (lv_modelNumber_3_0= ruleEString ) )
                    // InternalDsl.g:94:5: (lv_modelNumber_3_0= ruleEString )
                    {
                    // InternalDsl.g:94:5: (lv_modelNumber_3_0= ruleEString )
                    // InternalDsl.g:95:6: lv_modelNumber_3_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getEmbeddedSystemAccess().getModelNumberEStringParserRuleCall_2_1_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_modelNumber_3_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getEmbeddedSystemRule());
                    						}
                    						set(
                    							current,
                    							"modelNumber",
                    							lv_modelNumber_3_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:113:3: (otherlv_4= 'releaseDate' ( (lv_releaseDate_5_0= ruleEDate ) ) )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==14) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalDsl.g:114:4: otherlv_4= 'releaseDate' ( (lv_releaseDate_5_0= ruleEDate ) )
                    {
                    otherlv_4=(Token)match(input,14,FOLLOW_7); 

                    				newLeafNode(otherlv_4, grammarAccess.getEmbeddedSystemAccess().getReleaseDateKeyword_3_0());
                    			
                    // InternalDsl.g:118:4: ( (lv_releaseDate_5_0= ruleEDate ) )
                    // InternalDsl.g:119:5: (lv_releaseDate_5_0= ruleEDate )
                    {
                    // InternalDsl.g:119:5: (lv_releaseDate_5_0= ruleEDate )
                    // InternalDsl.g:120:6: lv_releaseDate_5_0= ruleEDate
                    {

                    						newCompositeNode(grammarAccess.getEmbeddedSystemAccess().getReleaseDateEDateParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_8);
                    lv_releaseDate_5_0=ruleEDate();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getEmbeddedSystemRule());
                    						}
                    						set(
                    							current,
                    							"releaseDate",
                    							lv_releaseDate_5_0,
                    							"labtwo.Dsl.EDate");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:138:3: (otherlv_6= 'firmwareVersion' ( (lv_firmwareVersion_7_0= ruleEString ) ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==15) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalDsl.g:139:4: otherlv_6= 'firmwareVersion' ( (lv_firmwareVersion_7_0= ruleEString ) )
                    {
                    otherlv_6=(Token)match(input,15,FOLLOW_5); 

                    				newLeafNode(otherlv_6, grammarAccess.getEmbeddedSystemAccess().getFirmwareVersionKeyword_4_0());
                    			
                    // InternalDsl.g:143:4: ( (lv_firmwareVersion_7_0= ruleEString ) )
                    // InternalDsl.g:144:5: (lv_firmwareVersion_7_0= ruleEString )
                    {
                    // InternalDsl.g:144:5: (lv_firmwareVersion_7_0= ruleEString )
                    // InternalDsl.g:145:6: lv_firmwareVersion_7_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getEmbeddedSystemAccess().getFirmwareVersionEStringParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_9);
                    lv_firmwareVersion_7_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getEmbeddedSystemRule());
                    						}
                    						set(
                    							current,
                    							"firmwareVersion",
                    							lv_firmwareVersion_7_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:163:3: (otherlv_8= 'components' otherlv_9= '{' ( (lv_components_10_0= ruleDeviceComponent ) ) (otherlv_11= ',' ( (lv_components_12_0= ruleDeviceComponent ) ) )* otherlv_13= '}' )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==16) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalDsl.g:164:4: otherlv_8= 'components' otherlv_9= '{' ( (lv_components_10_0= ruleDeviceComponent ) ) (otherlv_11= ',' ( (lv_components_12_0= ruleDeviceComponent ) ) )* otherlv_13= '}'
                    {
                    otherlv_8=(Token)match(input,16,FOLLOW_3); 

                    				newLeafNode(otherlv_8, grammarAccess.getEmbeddedSystemAccess().getComponentsKeyword_5_0());
                    			
                    otherlv_9=(Token)match(input,12,FOLLOW_10); 

                    				newLeafNode(otherlv_9, grammarAccess.getEmbeddedSystemAccess().getLeftCurlyBracketKeyword_5_1());
                    			
                    // InternalDsl.g:172:4: ( (lv_components_10_0= ruleDeviceComponent ) )
                    // InternalDsl.g:173:5: (lv_components_10_0= ruleDeviceComponent )
                    {
                    // InternalDsl.g:173:5: (lv_components_10_0= ruleDeviceComponent )
                    // InternalDsl.g:174:6: lv_components_10_0= ruleDeviceComponent
                    {

                    						newCompositeNode(grammarAccess.getEmbeddedSystemAccess().getComponentsDeviceComponentParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_11);
                    lv_components_10_0=ruleDeviceComponent();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getEmbeddedSystemRule());
                    						}
                    						add(
                    							current,
                    							"components",
                    							lv_components_10_0,
                    							"labtwo.Dsl.DeviceComponent");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalDsl.g:191:4: (otherlv_11= ',' ( (lv_components_12_0= ruleDeviceComponent ) ) )*
                    loop4:
                    do {
                        int alt4=2;
                        int LA4_0 = input.LA(1);

                        if ( (LA4_0==17) ) {
                            alt4=1;
                        }


                        switch (alt4) {
                    	case 1 :
                    	    // InternalDsl.g:192:5: otherlv_11= ',' ( (lv_components_12_0= ruleDeviceComponent ) )
                    	    {
                    	    otherlv_11=(Token)match(input,17,FOLLOW_10); 

                    	    					newLeafNode(otherlv_11, grammarAccess.getEmbeddedSystemAccess().getCommaKeyword_5_3_0());
                    	    				
                    	    // InternalDsl.g:196:5: ( (lv_components_12_0= ruleDeviceComponent ) )
                    	    // InternalDsl.g:197:6: (lv_components_12_0= ruleDeviceComponent )
                    	    {
                    	    // InternalDsl.g:197:6: (lv_components_12_0= ruleDeviceComponent )
                    	    // InternalDsl.g:198:7: lv_components_12_0= ruleDeviceComponent
                    	    {

                    	    							newCompositeNode(grammarAccess.getEmbeddedSystemAccess().getComponentsDeviceComponentParserRuleCall_5_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_11);
                    	    lv_components_12_0=ruleDeviceComponent();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getEmbeddedSystemRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"components",
                    	    								lv_components_12_0,
                    	    								"labtwo.Dsl.DeviceComponent");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop4;
                        }
                    } while (true);

                    otherlv_13=(Token)match(input,18,FOLLOW_12); 

                    				newLeafNode(otherlv_13, grammarAccess.getEmbeddedSystemAccess().getRightCurlyBracketKeyword_5_4());
                    			

                    }
                    break;

            }

            otherlv_14=(Token)match(input,19,FOLLOW_3); 

            			newLeafNode(otherlv_14, grammarAccess.getEmbeddedSystemAccess().getImplementedWithKeyword_6());
            		
            otherlv_15=(Token)match(input,12,FOLLOW_13); 

            			newLeafNode(otherlv_15, grammarAccess.getEmbeddedSystemAccess().getLeftCurlyBracketKeyword_7());
            		
            // InternalDsl.g:229:3: ( (lv_ImplementedWith_16_0= ruleBattery ) )
            // InternalDsl.g:230:4: (lv_ImplementedWith_16_0= ruleBattery )
            {
            // InternalDsl.g:230:4: (lv_ImplementedWith_16_0= ruleBattery )
            // InternalDsl.g:231:5: lv_ImplementedWith_16_0= ruleBattery
            {

            					newCompositeNode(grammarAccess.getEmbeddedSystemAccess().getImplementedWithBatteryParserRuleCall_8_0());
            				
            pushFollow(FOLLOW_11);
            lv_ImplementedWith_16_0=ruleBattery();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getEmbeddedSystemRule());
            					}
            					add(
            						current,
            						"ImplementedWith",
            						lv_ImplementedWith_16_0,
            						"labtwo.Dsl.Battery");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalDsl.g:248:3: (otherlv_17= ',' ( (lv_ImplementedWith_18_0= ruleBattery ) ) )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==17) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalDsl.g:249:4: otherlv_17= ',' ( (lv_ImplementedWith_18_0= ruleBattery ) )
            	    {
            	    otherlv_17=(Token)match(input,17,FOLLOW_13); 

            	    				newLeafNode(otherlv_17, grammarAccess.getEmbeddedSystemAccess().getCommaKeyword_9_0());
            	    			
            	    // InternalDsl.g:253:4: ( (lv_ImplementedWith_18_0= ruleBattery ) )
            	    // InternalDsl.g:254:5: (lv_ImplementedWith_18_0= ruleBattery )
            	    {
            	    // InternalDsl.g:254:5: (lv_ImplementedWith_18_0= ruleBattery )
            	    // InternalDsl.g:255:6: lv_ImplementedWith_18_0= ruleBattery
            	    {

            	    						newCompositeNode(grammarAccess.getEmbeddedSystemAccess().getImplementedWithBatteryParserRuleCall_9_1_0());
            	    					
            	    pushFollow(FOLLOW_11);
            	    lv_ImplementedWith_18_0=ruleBattery();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getEmbeddedSystemRule());
            	    						}
            	    						add(
            	    							current,
            	    							"ImplementedWith",
            	    							lv_ImplementedWith_18_0,
            	    							"labtwo.Dsl.Battery");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            otherlv_19=(Token)match(input,18,FOLLOW_14); 

            			newLeafNode(otherlv_19, grammarAccess.getEmbeddedSystemAccess().getRightCurlyBracketKeyword_10());
            		
            otherlv_20=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_20, grammarAccess.getEmbeddedSystemAccess().getRightCurlyBracketKeyword_11());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEmbeddedSystem"


    // $ANTLR start "entryRuleDeviceComponent"
    // InternalDsl.g:285:1: entryRuleDeviceComponent returns [EObject current=null] : iv_ruleDeviceComponent= ruleDeviceComponent EOF ;
    public final EObject entryRuleDeviceComponent() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDeviceComponent = null;


        try {
            // InternalDsl.g:285:56: (iv_ruleDeviceComponent= ruleDeviceComponent EOF )
            // InternalDsl.g:286:2: iv_ruleDeviceComponent= ruleDeviceComponent EOF
            {
             newCompositeNode(grammarAccess.getDeviceComponentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDeviceComponent=ruleDeviceComponent();

            state._fsp--;

             current =iv_ruleDeviceComponent; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDeviceComponent"


    // $ANTLR start "ruleDeviceComponent"
    // InternalDsl.g:292:1: ruleDeviceComponent returns [EObject current=null] : (this_Actuator_0= ruleActuator | this_Motor_1= ruleMotor | this_ConnectivityModule_2= ruleConnectivityModule | this_Microcontroller_3= ruleMicrocontroller | this_Sensor_4= ruleSensor | this_Memory_5= ruleMemory ) ;
    public final EObject ruleDeviceComponent() throws RecognitionException {
        EObject current = null;

        EObject this_Actuator_0 = null;

        EObject this_Motor_1 = null;

        EObject this_ConnectivityModule_2 = null;

        EObject this_Microcontroller_3 = null;

        EObject this_Sensor_4 = null;

        EObject this_Memory_5 = null;



        	enterRule();

        try {
            // InternalDsl.g:298:2: ( (this_Actuator_0= ruleActuator | this_Motor_1= ruleMotor | this_ConnectivityModule_2= ruleConnectivityModule | this_Microcontroller_3= ruleMicrocontroller | this_Sensor_4= ruleSensor | this_Memory_5= ruleMemory ) )
            // InternalDsl.g:299:2: (this_Actuator_0= ruleActuator | this_Motor_1= ruleMotor | this_ConnectivityModule_2= ruleConnectivityModule | this_Microcontroller_3= ruleMicrocontroller | this_Sensor_4= ruleSensor | this_Memory_5= ruleMemory )
            {
            // InternalDsl.g:299:2: (this_Actuator_0= ruleActuator | this_Motor_1= ruleMotor | this_ConnectivityModule_2= ruleConnectivityModule | this_Microcontroller_3= ruleMicrocontroller | this_Sensor_4= ruleSensor | this_Memory_5= ruleMemory )
            int alt7=6;
            switch ( input.LA(1) ) {
            case 31:
                {
                alt7=1;
                }
                break;
            case 37:
                {
                alt7=2;
                }
                break;
            case 46:
                {
                alt7=3;
                }
                break;
            case 51:
                {
                alt7=4;
                }
                break;
            case 58:
                {
                alt7=5;
                }
                break;
            case 62:
                {
                alt7=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // InternalDsl.g:300:3: this_Actuator_0= ruleActuator
                    {

                    			newCompositeNode(grammarAccess.getDeviceComponentAccess().getActuatorParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Actuator_0=ruleActuator();

                    state._fsp--;


                    			current = this_Actuator_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalDsl.g:309:3: this_Motor_1= ruleMotor
                    {

                    			newCompositeNode(grammarAccess.getDeviceComponentAccess().getMotorParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Motor_1=ruleMotor();

                    state._fsp--;


                    			current = this_Motor_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalDsl.g:318:3: this_ConnectivityModule_2= ruleConnectivityModule
                    {

                    			newCompositeNode(grammarAccess.getDeviceComponentAccess().getConnectivityModuleParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_ConnectivityModule_2=ruleConnectivityModule();

                    state._fsp--;


                    			current = this_ConnectivityModule_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalDsl.g:327:3: this_Microcontroller_3= ruleMicrocontroller
                    {

                    			newCompositeNode(grammarAccess.getDeviceComponentAccess().getMicrocontrollerParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_Microcontroller_3=ruleMicrocontroller();

                    state._fsp--;


                    			current = this_Microcontroller_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalDsl.g:336:3: this_Sensor_4= ruleSensor
                    {

                    			newCompositeNode(grammarAccess.getDeviceComponentAccess().getSensorParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_Sensor_4=ruleSensor();

                    state._fsp--;


                    			current = this_Sensor_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalDsl.g:345:3: this_Memory_5= ruleMemory
                    {

                    			newCompositeNode(grammarAccess.getDeviceComponentAccess().getMemoryParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_Memory_5=ruleMemory();

                    state._fsp--;


                    			current = this_Memory_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDeviceComponent"


    // $ANTLR start "entryRuleEString"
    // InternalDsl.g:357:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalDsl.g:357:47: (iv_ruleEString= ruleEString EOF )
            // InternalDsl.g:358:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalDsl.g:364:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalDsl.g:370:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalDsl.g:371:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalDsl.g:371:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==RULE_STRING) ) {
                alt8=1;
            }
            else if ( (LA8_0==RULE_ID) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalDsl.g:372:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalDsl.g:380:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleEDate"
    // InternalDsl.g:391:1: entryRuleEDate returns [String current=null] : iv_ruleEDate= ruleEDate EOF ;
    public final String entryRuleEDate() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEDate = null;


        try {
            // InternalDsl.g:391:45: (iv_ruleEDate= ruleEDate EOF )
            // InternalDsl.g:392:2: iv_ruleEDate= ruleEDate EOF
            {
             newCompositeNode(grammarAccess.getEDateRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEDate=ruleEDate();

            state._fsp--;

             current =iv_ruleEDate.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEDate"


    // $ANTLR start "ruleEDate"
    // InternalDsl.g:398:1: ruleEDate returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= 'EDate' ;
    public final AntlrDatatypeRuleToken ruleEDate() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalDsl.g:404:2: (kw= 'EDate' )
            // InternalDsl.g:405:2: kw= 'EDate'
            {
            kw=(Token)match(input,20,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getEDateAccess().getEDateKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEDate"


    // $ANTLR start "entryRuleBattery"
    // InternalDsl.g:413:1: entryRuleBattery returns [EObject current=null] : iv_ruleBattery= ruleBattery EOF ;
    public final EObject entryRuleBattery() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBattery = null;


        try {
            // InternalDsl.g:413:48: (iv_ruleBattery= ruleBattery EOF )
            // InternalDsl.g:414:2: iv_ruleBattery= ruleBattery EOF
            {
             newCompositeNode(grammarAccess.getBatteryRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBattery=ruleBattery();

            state._fsp--;

             current =iv_ruleBattery; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBattery"


    // $ANTLR start "ruleBattery"
    // InternalDsl.g:420:1: ruleBattery returns [EObject current=null] : (otherlv_0= 'Battery' otherlv_1= '{' (otherlv_2= 'capacity' ( (lv_capacity_3_0= ruleEFloat ) ) )? (otherlv_4= 'voltage' ( (lv_voltage_5_0= ruleEFloat ) ) )? (otherlv_6= 'usage' ( (lv_usage_7_0= ruleEString ) ) )? (otherlv_8= 'chargeCycles' ( (lv_chargeCycles_9_0= ruleEInt ) ) )? (otherlv_10= 'batteryName' ( (lv_batteryName_11_0= ruleEString ) ) )? (otherlv_12= 'manufacturer' ( (lv_manufacturer_13_0= ruleEString ) ) )? otherlv_14= 'requires' otherlv_15= '(' ( ( ruleEString ) ) (otherlv_17= ',' ( ( ruleEString ) ) )* otherlv_19= ')' otherlv_20= '}' ) ;
    public final EObject ruleBattery() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_15=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        Token otherlv_20=null;
        AntlrDatatypeRuleToken lv_capacity_3_0 = null;

        AntlrDatatypeRuleToken lv_voltage_5_0 = null;

        AntlrDatatypeRuleToken lv_usage_7_0 = null;

        AntlrDatatypeRuleToken lv_chargeCycles_9_0 = null;

        AntlrDatatypeRuleToken lv_batteryName_11_0 = null;

        AntlrDatatypeRuleToken lv_manufacturer_13_0 = null;



        	enterRule();

        try {
            // InternalDsl.g:426:2: ( (otherlv_0= 'Battery' otherlv_1= '{' (otherlv_2= 'capacity' ( (lv_capacity_3_0= ruleEFloat ) ) )? (otherlv_4= 'voltage' ( (lv_voltage_5_0= ruleEFloat ) ) )? (otherlv_6= 'usage' ( (lv_usage_7_0= ruleEString ) ) )? (otherlv_8= 'chargeCycles' ( (lv_chargeCycles_9_0= ruleEInt ) ) )? (otherlv_10= 'batteryName' ( (lv_batteryName_11_0= ruleEString ) ) )? (otherlv_12= 'manufacturer' ( (lv_manufacturer_13_0= ruleEString ) ) )? otherlv_14= 'requires' otherlv_15= '(' ( ( ruleEString ) ) (otherlv_17= ',' ( ( ruleEString ) ) )* otherlv_19= ')' otherlv_20= '}' ) )
            // InternalDsl.g:427:2: (otherlv_0= 'Battery' otherlv_1= '{' (otherlv_2= 'capacity' ( (lv_capacity_3_0= ruleEFloat ) ) )? (otherlv_4= 'voltage' ( (lv_voltage_5_0= ruleEFloat ) ) )? (otherlv_6= 'usage' ( (lv_usage_7_0= ruleEString ) ) )? (otherlv_8= 'chargeCycles' ( (lv_chargeCycles_9_0= ruleEInt ) ) )? (otherlv_10= 'batteryName' ( (lv_batteryName_11_0= ruleEString ) ) )? (otherlv_12= 'manufacturer' ( (lv_manufacturer_13_0= ruleEString ) ) )? otherlv_14= 'requires' otherlv_15= '(' ( ( ruleEString ) ) (otherlv_17= ',' ( ( ruleEString ) ) )* otherlv_19= ')' otherlv_20= '}' )
            {
            // InternalDsl.g:427:2: (otherlv_0= 'Battery' otherlv_1= '{' (otherlv_2= 'capacity' ( (lv_capacity_3_0= ruleEFloat ) ) )? (otherlv_4= 'voltage' ( (lv_voltage_5_0= ruleEFloat ) ) )? (otherlv_6= 'usage' ( (lv_usage_7_0= ruleEString ) ) )? (otherlv_8= 'chargeCycles' ( (lv_chargeCycles_9_0= ruleEInt ) ) )? (otherlv_10= 'batteryName' ( (lv_batteryName_11_0= ruleEString ) ) )? (otherlv_12= 'manufacturer' ( (lv_manufacturer_13_0= ruleEString ) ) )? otherlv_14= 'requires' otherlv_15= '(' ( ( ruleEString ) ) (otherlv_17= ',' ( ( ruleEString ) ) )* otherlv_19= ')' otherlv_20= '}' )
            // InternalDsl.g:428:3: otherlv_0= 'Battery' otherlv_1= '{' (otherlv_2= 'capacity' ( (lv_capacity_3_0= ruleEFloat ) ) )? (otherlv_4= 'voltage' ( (lv_voltage_5_0= ruleEFloat ) ) )? (otherlv_6= 'usage' ( (lv_usage_7_0= ruleEString ) ) )? (otherlv_8= 'chargeCycles' ( (lv_chargeCycles_9_0= ruleEInt ) ) )? (otherlv_10= 'batteryName' ( (lv_batteryName_11_0= ruleEString ) ) )? (otherlv_12= 'manufacturer' ( (lv_manufacturer_13_0= ruleEString ) ) )? otherlv_14= 'requires' otherlv_15= '(' ( ( ruleEString ) ) (otherlv_17= ',' ( ( ruleEString ) ) )* otherlv_19= ')' otherlv_20= '}'
            {
            otherlv_0=(Token)match(input,21,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getBatteryAccess().getBatteryKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_15); 

            			newLeafNode(otherlv_1, grammarAccess.getBatteryAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalDsl.g:436:3: (otherlv_2= 'capacity' ( (lv_capacity_3_0= ruleEFloat ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==22) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalDsl.g:437:4: otherlv_2= 'capacity' ( (lv_capacity_3_0= ruleEFloat ) )
                    {
                    otherlv_2=(Token)match(input,22,FOLLOW_16); 

                    				newLeafNode(otherlv_2, grammarAccess.getBatteryAccess().getCapacityKeyword_2_0());
                    			
                    // InternalDsl.g:441:4: ( (lv_capacity_3_0= ruleEFloat ) )
                    // InternalDsl.g:442:5: (lv_capacity_3_0= ruleEFloat )
                    {
                    // InternalDsl.g:442:5: (lv_capacity_3_0= ruleEFloat )
                    // InternalDsl.g:443:6: lv_capacity_3_0= ruleEFloat
                    {

                    						newCompositeNode(grammarAccess.getBatteryAccess().getCapacityEFloatParserRuleCall_2_1_0());
                    					
                    pushFollow(FOLLOW_17);
                    lv_capacity_3_0=ruleEFloat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getBatteryRule());
                    						}
                    						set(
                    							current,
                    							"capacity",
                    							lv_capacity_3_0,
                    							"labtwo.Dsl.EFloat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:461:3: (otherlv_4= 'voltage' ( (lv_voltage_5_0= ruleEFloat ) ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==23) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalDsl.g:462:4: otherlv_4= 'voltage' ( (lv_voltage_5_0= ruleEFloat ) )
                    {
                    otherlv_4=(Token)match(input,23,FOLLOW_16); 

                    				newLeafNode(otherlv_4, grammarAccess.getBatteryAccess().getVoltageKeyword_3_0());
                    			
                    // InternalDsl.g:466:4: ( (lv_voltage_5_0= ruleEFloat ) )
                    // InternalDsl.g:467:5: (lv_voltage_5_0= ruleEFloat )
                    {
                    // InternalDsl.g:467:5: (lv_voltage_5_0= ruleEFloat )
                    // InternalDsl.g:468:6: lv_voltage_5_0= ruleEFloat
                    {

                    						newCompositeNode(grammarAccess.getBatteryAccess().getVoltageEFloatParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_18);
                    lv_voltage_5_0=ruleEFloat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getBatteryRule());
                    						}
                    						set(
                    							current,
                    							"voltage",
                    							lv_voltage_5_0,
                    							"labtwo.Dsl.EFloat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:486:3: (otherlv_6= 'usage' ( (lv_usage_7_0= ruleEString ) ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==24) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalDsl.g:487:4: otherlv_6= 'usage' ( (lv_usage_7_0= ruleEString ) )
                    {
                    otherlv_6=(Token)match(input,24,FOLLOW_5); 

                    				newLeafNode(otherlv_6, grammarAccess.getBatteryAccess().getUsageKeyword_4_0());
                    			
                    // InternalDsl.g:491:4: ( (lv_usage_7_0= ruleEString ) )
                    // InternalDsl.g:492:5: (lv_usage_7_0= ruleEString )
                    {
                    // InternalDsl.g:492:5: (lv_usage_7_0= ruleEString )
                    // InternalDsl.g:493:6: lv_usage_7_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getBatteryAccess().getUsageEStringParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_19);
                    lv_usage_7_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getBatteryRule());
                    						}
                    						set(
                    							current,
                    							"usage",
                    							lv_usage_7_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:511:3: (otherlv_8= 'chargeCycles' ( (lv_chargeCycles_9_0= ruleEInt ) ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==25) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalDsl.g:512:4: otherlv_8= 'chargeCycles' ( (lv_chargeCycles_9_0= ruleEInt ) )
                    {
                    otherlv_8=(Token)match(input,25,FOLLOW_20); 

                    				newLeafNode(otherlv_8, grammarAccess.getBatteryAccess().getChargeCyclesKeyword_5_0());
                    			
                    // InternalDsl.g:516:4: ( (lv_chargeCycles_9_0= ruleEInt ) )
                    // InternalDsl.g:517:5: (lv_chargeCycles_9_0= ruleEInt )
                    {
                    // InternalDsl.g:517:5: (lv_chargeCycles_9_0= ruleEInt )
                    // InternalDsl.g:518:6: lv_chargeCycles_9_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getBatteryAccess().getChargeCyclesEIntParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_21);
                    lv_chargeCycles_9_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getBatteryRule());
                    						}
                    						set(
                    							current,
                    							"chargeCycles",
                    							lv_chargeCycles_9_0,
                    							"labtwo.Dsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:536:3: (otherlv_10= 'batteryName' ( (lv_batteryName_11_0= ruleEString ) ) )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==26) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalDsl.g:537:4: otherlv_10= 'batteryName' ( (lv_batteryName_11_0= ruleEString ) )
                    {
                    otherlv_10=(Token)match(input,26,FOLLOW_5); 

                    				newLeafNode(otherlv_10, grammarAccess.getBatteryAccess().getBatteryNameKeyword_6_0());
                    			
                    // InternalDsl.g:541:4: ( (lv_batteryName_11_0= ruleEString ) )
                    // InternalDsl.g:542:5: (lv_batteryName_11_0= ruleEString )
                    {
                    // InternalDsl.g:542:5: (lv_batteryName_11_0= ruleEString )
                    // InternalDsl.g:543:6: lv_batteryName_11_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getBatteryAccess().getBatteryNameEStringParserRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_22);
                    lv_batteryName_11_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getBatteryRule());
                    						}
                    						set(
                    							current,
                    							"batteryName",
                    							lv_batteryName_11_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:561:3: (otherlv_12= 'manufacturer' ( (lv_manufacturer_13_0= ruleEString ) ) )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==27) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalDsl.g:562:4: otherlv_12= 'manufacturer' ( (lv_manufacturer_13_0= ruleEString ) )
                    {
                    otherlv_12=(Token)match(input,27,FOLLOW_5); 

                    				newLeafNode(otherlv_12, grammarAccess.getBatteryAccess().getManufacturerKeyword_7_0());
                    			
                    // InternalDsl.g:566:4: ( (lv_manufacturer_13_0= ruleEString ) )
                    // InternalDsl.g:567:5: (lv_manufacturer_13_0= ruleEString )
                    {
                    // InternalDsl.g:567:5: (lv_manufacturer_13_0= ruleEString )
                    // InternalDsl.g:568:6: lv_manufacturer_13_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getBatteryAccess().getManufacturerEStringParserRuleCall_7_1_0());
                    					
                    pushFollow(FOLLOW_23);
                    lv_manufacturer_13_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getBatteryRule());
                    						}
                    						set(
                    							current,
                    							"manufacturer",
                    							lv_manufacturer_13_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_14=(Token)match(input,28,FOLLOW_24); 

            			newLeafNode(otherlv_14, grammarAccess.getBatteryAccess().getRequiresKeyword_8());
            		
            otherlv_15=(Token)match(input,29,FOLLOW_5); 

            			newLeafNode(otherlv_15, grammarAccess.getBatteryAccess().getLeftParenthesisKeyword_9());
            		
            // InternalDsl.g:594:3: ( ( ruleEString ) )
            // InternalDsl.g:595:4: ( ruleEString )
            {
            // InternalDsl.g:595:4: ( ruleEString )
            // InternalDsl.g:596:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getBatteryRule());
            					}
            				

            					newCompositeNode(grammarAccess.getBatteryAccess().getRequiresMicrocontrollerCrossReference_10_0());
            				
            pushFollow(FOLLOW_25);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalDsl.g:610:3: (otherlv_17= ',' ( ( ruleEString ) ) )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==17) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalDsl.g:611:4: otherlv_17= ',' ( ( ruleEString ) )
            	    {
            	    otherlv_17=(Token)match(input,17,FOLLOW_5); 

            	    				newLeafNode(otherlv_17, grammarAccess.getBatteryAccess().getCommaKeyword_11_0());
            	    			
            	    // InternalDsl.g:615:4: ( ( ruleEString ) )
            	    // InternalDsl.g:616:5: ( ruleEString )
            	    {
            	    // InternalDsl.g:616:5: ( ruleEString )
            	    // InternalDsl.g:617:6: ruleEString
            	    {

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getBatteryRule());
            	    						}
            	    					

            	    						newCompositeNode(grammarAccess.getBatteryAccess().getRequiresMicrocontrollerCrossReference_11_1_0());
            	    					
            	    pushFollow(FOLLOW_25);
            	    ruleEString();

            	    state._fsp--;


            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

            otherlv_19=(Token)match(input,30,FOLLOW_14); 

            			newLeafNode(otherlv_19, grammarAccess.getBatteryAccess().getRightParenthesisKeyword_12());
            		
            otherlv_20=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_20, grammarAccess.getBatteryAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBattery"


    // $ANTLR start "entryRuleActuator"
    // InternalDsl.g:644:1: entryRuleActuator returns [EObject current=null] : iv_ruleActuator= ruleActuator EOF ;
    public final EObject entryRuleActuator() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleActuator = null;


        try {
            // InternalDsl.g:644:49: (iv_ruleActuator= ruleActuator EOF )
            // InternalDsl.g:645:2: iv_ruleActuator= ruleActuator EOF
            {
             newCompositeNode(grammarAccess.getActuatorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleActuator=ruleActuator();

            state._fsp--;

             current =iv_ruleActuator; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleActuator"


    // $ANTLR start "ruleActuator"
    // InternalDsl.g:651:1: ruleActuator returns [EObject current=null] : ( () otherlv_1= 'Actuator' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'range' ( (lv_range_10_0= ruleEFloat ) ) )? (otherlv_11= 'inputSignal' ( (lv_inputSignal_12_0= ruleEString ) ) )? (otherlv_13= 'operatesWith' otherlv_14= '(' ( ( ruleEString ) ) (otherlv_16= ',' ( ( ruleEString ) ) )* otherlv_18= ')' )? otherlv_19= '}' ) ;
    public final EObject ruleActuator() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        Token otherlv_14=null;
        Token otherlv_16=null;
        Token otherlv_18=null;
        Token otherlv_19=null;
        AntlrDatatypeRuleToken lv_serialNumber_4_0 = null;

        AntlrDatatypeRuleToken lv_manufacturer_6_0 = null;

        AntlrDatatypeRuleToken lv_type_8_0 = null;

        AntlrDatatypeRuleToken lv_range_10_0 = null;

        AntlrDatatypeRuleToken lv_inputSignal_12_0 = null;



        	enterRule();

        try {
            // InternalDsl.g:657:2: ( ( () otherlv_1= 'Actuator' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'range' ( (lv_range_10_0= ruleEFloat ) ) )? (otherlv_11= 'inputSignal' ( (lv_inputSignal_12_0= ruleEString ) ) )? (otherlv_13= 'operatesWith' otherlv_14= '(' ( ( ruleEString ) ) (otherlv_16= ',' ( ( ruleEString ) ) )* otherlv_18= ')' )? otherlv_19= '}' ) )
            // InternalDsl.g:658:2: ( () otherlv_1= 'Actuator' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'range' ( (lv_range_10_0= ruleEFloat ) ) )? (otherlv_11= 'inputSignal' ( (lv_inputSignal_12_0= ruleEString ) ) )? (otherlv_13= 'operatesWith' otherlv_14= '(' ( ( ruleEString ) ) (otherlv_16= ',' ( ( ruleEString ) ) )* otherlv_18= ')' )? otherlv_19= '}' )
            {
            // InternalDsl.g:658:2: ( () otherlv_1= 'Actuator' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'range' ( (lv_range_10_0= ruleEFloat ) ) )? (otherlv_11= 'inputSignal' ( (lv_inputSignal_12_0= ruleEString ) ) )? (otherlv_13= 'operatesWith' otherlv_14= '(' ( ( ruleEString ) ) (otherlv_16= ',' ( ( ruleEString ) ) )* otherlv_18= ')' )? otherlv_19= '}' )
            // InternalDsl.g:659:3: () otherlv_1= 'Actuator' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'range' ( (lv_range_10_0= ruleEFloat ) ) )? (otherlv_11= 'inputSignal' ( (lv_inputSignal_12_0= ruleEString ) ) )? (otherlv_13= 'operatesWith' otherlv_14= '(' ( ( ruleEString ) ) (otherlv_16= ',' ( ( ruleEString ) ) )* otherlv_18= ')' )? otherlv_19= '}'
            {
            // InternalDsl.g:659:3: ()
            // InternalDsl.g:660:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getActuatorAccess().getActuatorAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,31,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getActuatorAccess().getActuatorKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_26); 

            			newLeafNode(otherlv_2, grammarAccess.getActuatorAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalDsl.g:674:3: (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==32) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalDsl.g:675:4: otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,32,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getActuatorAccess().getSerialNumberKeyword_3_0());
                    			
                    // InternalDsl.g:679:4: ( (lv_serialNumber_4_0= ruleEString ) )
                    // InternalDsl.g:680:5: (lv_serialNumber_4_0= ruleEString )
                    {
                    // InternalDsl.g:680:5: (lv_serialNumber_4_0= ruleEString )
                    // InternalDsl.g:681:6: lv_serialNumber_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getActuatorAccess().getSerialNumberEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_27);
                    lv_serialNumber_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getActuatorRule());
                    						}
                    						set(
                    							current,
                    							"serialNumber",
                    							lv_serialNumber_4_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:699:3: (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==27) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalDsl.g:700:4: otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) )
                    {
                    otherlv_5=(Token)match(input,27,FOLLOW_5); 

                    				newLeafNode(otherlv_5, grammarAccess.getActuatorAccess().getManufacturerKeyword_4_0());
                    			
                    // InternalDsl.g:704:4: ( (lv_manufacturer_6_0= ruleEString ) )
                    // InternalDsl.g:705:5: (lv_manufacturer_6_0= ruleEString )
                    {
                    // InternalDsl.g:705:5: (lv_manufacturer_6_0= ruleEString )
                    // InternalDsl.g:706:6: lv_manufacturer_6_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getActuatorAccess().getManufacturerEStringParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_28);
                    lv_manufacturer_6_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getActuatorRule());
                    						}
                    						set(
                    							current,
                    							"manufacturer",
                    							lv_manufacturer_6_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:724:3: (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==33) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalDsl.g:725:4: otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) )
                    {
                    otherlv_7=(Token)match(input,33,FOLLOW_5); 

                    				newLeafNode(otherlv_7, grammarAccess.getActuatorAccess().getTypeKeyword_5_0());
                    			
                    // InternalDsl.g:729:4: ( (lv_type_8_0= ruleEString ) )
                    // InternalDsl.g:730:5: (lv_type_8_0= ruleEString )
                    {
                    // InternalDsl.g:730:5: (lv_type_8_0= ruleEString )
                    // InternalDsl.g:731:6: lv_type_8_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getActuatorAccess().getTypeEStringParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_29);
                    lv_type_8_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getActuatorRule());
                    						}
                    						set(
                    							current,
                    							"type",
                    							lv_type_8_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:749:3: (otherlv_9= 'range' ( (lv_range_10_0= ruleEFloat ) ) )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==34) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalDsl.g:750:4: otherlv_9= 'range' ( (lv_range_10_0= ruleEFloat ) )
                    {
                    otherlv_9=(Token)match(input,34,FOLLOW_16); 

                    				newLeafNode(otherlv_9, grammarAccess.getActuatorAccess().getRangeKeyword_6_0());
                    			
                    // InternalDsl.g:754:4: ( (lv_range_10_0= ruleEFloat ) )
                    // InternalDsl.g:755:5: (lv_range_10_0= ruleEFloat )
                    {
                    // InternalDsl.g:755:5: (lv_range_10_0= ruleEFloat )
                    // InternalDsl.g:756:6: lv_range_10_0= ruleEFloat
                    {

                    						newCompositeNode(grammarAccess.getActuatorAccess().getRangeEFloatParserRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_30);
                    lv_range_10_0=ruleEFloat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getActuatorRule());
                    						}
                    						set(
                    							current,
                    							"range",
                    							lv_range_10_0,
                    							"labtwo.Dsl.EFloat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:774:3: (otherlv_11= 'inputSignal' ( (lv_inputSignal_12_0= ruleEString ) ) )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==35) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalDsl.g:775:4: otherlv_11= 'inputSignal' ( (lv_inputSignal_12_0= ruleEString ) )
                    {
                    otherlv_11=(Token)match(input,35,FOLLOW_5); 

                    				newLeafNode(otherlv_11, grammarAccess.getActuatorAccess().getInputSignalKeyword_7_0());
                    			
                    // InternalDsl.g:779:4: ( (lv_inputSignal_12_0= ruleEString ) )
                    // InternalDsl.g:780:5: (lv_inputSignal_12_0= ruleEString )
                    {
                    // InternalDsl.g:780:5: (lv_inputSignal_12_0= ruleEString )
                    // InternalDsl.g:781:6: lv_inputSignal_12_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getActuatorAccess().getInputSignalEStringParserRuleCall_7_1_0());
                    					
                    pushFollow(FOLLOW_31);
                    lv_inputSignal_12_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getActuatorRule());
                    						}
                    						set(
                    							current,
                    							"inputSignal",
                    							lv_inputSignal_12_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:799:3: (otherlv_13= 'operatesWith' otherlv_14= '(' ( ( ruleEString ) ) (otherlv_16= ',' ( ( ruleEString ) ) )* otherlv_18= ')' )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==36) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalDsl.g:800:4: otherlv_13= 'operatesWith' otherlv_14= '(' ( ( ruleEString ) ) (otherlv_16= ',' ( ( ruleEString ) ) )* otherlv_18= ')'
                    {
                    otherlv_13=(Token)match(input,36,FOLLOW_24); 

                    				newLeafNode(otherlv_13, grammarAccess.getActuatorAccess().getOperatesWithKeyword_8_0());
                    			
                    otherlv_14=(Token)match(input,29,FOLLOW_5); 

                    				newLeafNode(otherlv_14, grammarAccess.getActuatorAccess().getLeftParenthesisKeyword_8_1());
                    			
                    // InternalDsl.g:808:4: ( ( ruleEString ) )
                    // InternalDsl.g:809:5: ( ruleEString )
                    {
                    // InternalDsl.g:809:5: ( ruleEString )
                    // InternalDsl.g:810:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getActuatorRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getActuatorAccess().getOperatesWithBatteryCrossReference_8_2_0());
                    					
                    pushFollow(FOLLOW_25);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalDsl.g:824:4: (otherlv_16= ',' ( ( ruleEString ) ) )*
                    loop21:
                    do {
                        int alt21=2;
                        int LA21_0 = input.LA(1);

                        if ( (LA21_0==17) ) {
                            alt21=1;
                        }


                        switch (alt21) {
                    	case 1 :
                    	    // InternalDsl.g:825:5: otherlv_16= ',' ( ( ruleEString ) )
                    	    {
                    	    otherlv_16=(Token)match(input,17,FOLLOW_5); 

                    	    					newLeafNode(otherlv_16, grammarAccess.getActuatorAccess().getCommaKeyword_8_3_0());
                    	    				
                    	    // InternalDsl.g:829:5: ( ( ruleEString ) )
                    	    // InternalDsl.g:830:6: ( ruleEString )
                    	    {
                    	    // InternalDsl.g:830:6: ( ruleEString )
                    	    // InternalDsl.g:831:7: ruleEString
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getActuatorRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getActuatorAccess().getOperatesWithBatteryCrossReference_8_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_25);
                    	    ruleEString();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop21;
                        }
                    } while (true);

                    otherlv_18=(Token)match(input,30,FOLLOW_14); 

                    				newLeafNode(otherlv_18, grammarAccess.getActuatorAccess().getRightParenthesisKeyword_8_4());
                    			

                    }
                    break;

            }

            otherlv_19=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_19, grammarAccess.getActuatorAccess().getRightCurlyBracketKeyword_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleActuator"


    // $ANTLR start "entryRuleMotor"
    // InternalDsl.g:859:1: entryRuleMotor returns [EObject current=null] : iv_ruleMotor= ruleMotor EOF ;
    public final EObject entryRuleMotor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMotor = null;


        try {
            // InternalDsl.g:859:46: (iv_ruleMotor= ruleMotor EOF )
            // InternalDsl.g:860:2: iv_ruleMotor= ruleMotor EOF
            {
             newCompositeNode(grammarAccess.getMotorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMotor=ruleMotor();

            state._fsp--;

             current =iv_ruleMotor; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMotor"


    // $ANTLR start "ruleMotor"
    // InternalDsl.g:866:1: ruleMotor returns [EObject current=null] : ( () otherlv_1= 'Motor' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'powerRating' ( (lv_powerRating_8_0= ruleEFloat ) ) )? (otherlv_9= 'speed' ( (lv_speed_10_0= ruleEFloat ) ) )? (otherlv_11= 'torque' ( (lv_torque_12_0= ruleEFloat ) ) )? (otherlv_13= 'motorType' ( (lv_motorType_14_0= ruleEString ) ) )? (otherlv_15= 'giveMeasurementsTo' otherlv_16= '(' ( ( ruleEString ) ) (otherlv_18= ',' ( ( ruleEString ) ) )* otherlv_20= ')' )? (otherlv_21= 'controls' ( ( ruleEString ) ) )? (otherlv_23= 'includedIn' otherlv_24= '(' ( ( ruleEString ) ) (otherlv_26= ',' ( ( ruleEString ) ) )* otherlv_28= ')' )? (otherlv_29= 'command' ( ( ruleEString ) ) )? otherlv_31= '}' ) ;
    public final EObject ruleMotor() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token otherlv_18=null;
        Token otherlv_20=null;
        Token otherlv_21=null;
        Token otherlv_23=null;
        Token otherlv_24=null;
        Token otherlv_26=null;
        Token otherlv_28=null;
        Token otherlv_29=null;
        Token otherlv_31=null;
        AntlrDatatypeRuleToken lv_serialNumber_4_0 = null;

        AntlrDatatypeRuleToken lv_manufacturer_6_0 = null;

        AntlrDatatypeRuleToken lv_powerRating_8_0 = null;

        AntlrDatatypeRuleToken lv_speed_10_0 = null;

        AntlrDatatypeRuleToken lv_torque_12_0 = null;

        AntlrDatatypeRuleToken lv_motorType_14_0 = null;



        	enterRule();

        try {
            // InternalDsl.g:872:2: ( ( () otherlv_1= 'Motor' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'powerRating' ( (lv_powerRating_8_0= ruleEFloat ) ) )? (otherlv_9= 'speed' ( (lv_speed_10_0= ruleEFloat ) ) )? (otherlv_11= 'torque' ( (lv_torque_12_0= ruleEFloat ) ) )? (otherlv_13= 'motorType' ( (lv_motorType_14_0= ruleEString ) ) )? (otherlv_15= 'giveMeasurementsTo' otherlv_16= '(' ( ( ruleEString ) ) (otherlv_18= ',' ( ( ruleEString ) ) )* otherlv_20= ')' )? (otherlv_21= 'controls' ( ( ruleEString ) ) )? (otherlv_23= 'includedIn' otherlv_24= '(' ( ( ruleEString ) ) (otherlv_26= ',' ( ( ruleEString ) ) )* otherlv_28= ')' )? (otherlv_29= 'command' ( ( ruleEString ) ) )? otherlv_31= '}' ) )
            // InternalDsl.g:873:2: ( () otherlv_1= 'Motor' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'powerRating' ( (lv_powerRating_8_0= ruleEFloat ) ) )? (otherlv_9= 'speed' ( (lv_speed_10_0= ruleEFloat ) ) )? (otherlv_11= 'torque' ( (lv_torque_12_0= ruleEFloat ) ) )? (otherlv_13= 'motorType' ( (lv_motorType_14_0= ruleEString ) ) )? (otherlv_15= 'giveMeasurementsTo' otherlv_16= '(' ( ( ruleEString ) ) (otherlv_18= ',' ( ( ruleEString ) ) )* otherlv_20= ')' )? (otherlv_21= 'controls' ( ( ruleEString ) ) )? (otherlv_23= 'includedIn' otherlv_24= '(' ( ( ruleEString ) ) (otherlv_26= ',' ( ( ruleEString ) ) )* otherlv_28= ')' )? (otherlv_29= 'command' ( ( ruleEString ) ) )? otherlv_31= '}' )
            {
            // InternalDsl.g:873:2: ( () otherlv_1= 'Motor' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'powerRating' ( (lv_powerRating_8_0= ruleEFloat ) ) )? (otherlv_9= 'speed' ( (lv_speed_10_0= ruleEFloat ) ) )? (otherlv_11= 'torque' ( (lv_torque_12_0= ruleEFloat ) ) )? (otherlv_13= 'motorType' ( (lv_motorType_14_0= ruleEString ) ) )? (otherlv_15= 'giveMeasurementsTo' otherlv_16= '(' ( ( ruleEString ) ) (otherlv_18= ',' ( ( ruleEString ) ) )* otherlv_20= ')' )? (otherlv_21= 'controls' ( ( ruleEString ) ) )? (otherlv_23= 'includedIn' otherlv_24= '(' ( ( ruleEString ) ) (otherlv_26= ',' ( ( ruleEString ) ) )* otherlv_28= ')' )? (otherlv_29= 'command' ( ( ruleEString ) ) )? otherlv_31= '}' )
            // InternalDsl.g:874:3: () otherlv_1= 'Motor' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'powerRating' ( (lv_powerRating_8_0= ruleEFloat ) ) )? (otherlv_9= 'speed' ( (lv_speed_10_0= ruleEFloat ) ) )? (otherlv_11= 'torque' ( (lv_torque_12_0= ruleEFloat ) ) )? (otherlv_13= 'motorType' ( (lv_motorType_14_0= ruleEString ) ) )? (otherlv_15= 'giveMeasurementsTo' otherlv_16= '(' ( ( ruleEString ) ) (otherlv_18= ',' ( ( ruleEString ) ) )* otherlv_20= ')' )? (otherlv_21= 'controls' ( ( ruleEString ) ) )? (otherlv_23= 'includedIn' otherlv_24= '(' ( ( ruleEString ) ) (otherlv_26= ',' ( ( ruleEString ) ) )* otherlv_28= ')' )? (otherlv_29= 'command' ( ( ruleEString ) ) )? otherlv_31= '}'
            {
            // InternalDsl.g:874:3: ()
            // InternalDsl.g:875:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getMotorAccess().getMotorAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,37,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getMotorAccess().getMotorKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_32); 

            			newLeafNode(otherlv_2, grammarAccess.getMotorAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalDsl.g:889:3: (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==32) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalDsl.g:890:4: otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,32,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getMotorAccess().getSerialNumberKeyword_3_0());
                    			
                    // InternalDsl.g:894:4: ( (lv_serialNumber_4_0= ruleEString ) )
                    // InternalDsl.g:895:5: (lv_serialNumber_4_0= ruleEString )
                    {
                    // InternalDsl.g:895:5: (lv_serialNumber_4_0= ruleEString )
                    // InternalDsl.g:896:6: lv_serialNumber_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getMotorAccess().getSerialNumberEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_33);
                    lv_serialNumber_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMotorRule());
                    						}
                    						set(
                    							current,
                    							"serialNumber",
                    							lv_serialNumber_4_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:914:3: (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==27) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalDsl.g:915:4: otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) )
                    {
                    otherlv_5=(Token)match(input,27,FOLLOW_5); 

                    				newLeafNode(otherlv_5, grammarAccess.getMotorAccess().getManufacturerKeyword_4_0());
                    			
                    // InternalDsl.g:919:4: ( (lv_manufacturer_6_0= ruleEString ) )
                    // InternalDsl.g:920:5: (lv_manufacturer_6_0= ruleEString )
                    {
                    // InternalDsl.g:920:5: (lv_manufacturer_6_0= ruleEString )
                    // InternalDsl.g:921:6: lv_manufacturer_6_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getMotorAccess().getManufacturerEStringParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_34);
                    lv_manufacturer_6_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMotorRule());
                    						}
                    						set(
                    							current,
                    							"manufacturer",
                    							lv_manufacturer_6_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:939:3: (otherlv_7= 'powerRating' ( (lv_powerRating_8_0= ruleEFloat ) ) )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==38) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalDsl.g:940:4: otherlv_7= 'powerRating' ( (lv_powerRating_8_0= ruleEFloat ) )
                    {
                    otherlv_7=(Token)match(input,38,FOLLOW_16); 

                    				newLeafNode(otherlv_7, grammarAccess.getMotorAccess().getPowerRatingKeyword_5_0());
                    			
                    // InternalDsl.g:944:4: ( (lv_powerRating_8_0= ruleEFloat ) )
                    // InternalDsl.g:945:5: (lv_powerRating_8_0= ruleEFloat )
                    {
                    // InternalDsl.g:945:5: (lv_powerRating_8_0= ruleEFloat )
                    // InternalDsl.g:946:6: lv_powerRating_8_0= ruleEFloat
                    {

                    						newCompositeNode(grammarAccess.getMotorAccess().getPowerRatingEFloatParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_35);
                    lv_powerRating_8_0=ruleEFloat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMotorRule());
                    						}
                    						set(
                    							current,
                    							"powerRating",
                    							lv_powerRating_8_0,
                    							"labtwo.Dsl.EFloat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:964:3: (otherlv_9= 'speed' ( (lv_speed_10_0= ruleEFloat ) ) )?
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==39) ) {
                alt26=1;
            }
            switch (alt26) {
                case 1 :
                    // InternalDsl.g:965:4: otherlv_9= 'speed' ( (lv_speed_10_0= ruleEFloat ) )
                    {
                    otherlv_9=(Token)match(input,39,FOLLOW_16); 

                    				newLeafNode(otherlv_9, grammarAccess.getMotorAccess().getSpeedKeyword_6_0());
                    			
                    // InternalDsl.g:969:4: ( (lv_speed_10_0= ruleEFloat ) )
                    // InternalDsl.g:970:5: (lv_speed_10_0= ruleEFloat )
                    {
                    // InternalDsl.g:970:5: (lv_speed_10_0= ruleEFloat )
                    // InternalDsl.g:971:6: lv_speed_10_0= ruleEFloat
                    {

                    						newCompositeNode(grammarAccess.getMotorAccess().getSpeedEFloatParserRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_36);
                    lv_speed_10_0=ruleEFloat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMotorRule());
                    						}
                    						set(
                    							current,
                    							"speed",
                    							lv_speed_10_0,
                    							"labtwo.Dsl.EFloat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:989:3: (otherlv_11= 'torque' ( (lv_torque_12_0= ruleEFloat ) ) )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==40) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalDsl.g:990:4: otherlv_11= 'torque' ( (lv_torque_12_0= ruleEFloat ) )
                    {
                    otherlv_11=(Token)match(input,40,FOLLOW_16); 

                    				newLeafNode(otherlv_11, grammarAccess.getMotorAccess().getTorqueKeyword_7_0());
                    			
                    // InternalDsl.g:994:4: ( (lv_torque_12_0= ruleEFloat ) )
                    // InternalDsl.g:995:5: (lv_torque_12_0= ruleEFloat )
                    {
                    // InternalDsl.g:995:5: (lv_torque_12_0= ruleEFloat )
                    // InternalDsl.g:996:6: lv_torque_12_0= ruleEFloat
                    {

                    						newCompositeNode(grammarAccess.getMotorAccess().getTorqueEFloatParserRuleCall_7_1_0());
                    					
                    pushFollow(FOLLOW_37);
                    lv_torque_12_0=ruleEFloat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMotorRule());
                    						}
                    						set(
                    							current,
                    							"torque",
                    							lv_torque_12_0,
                    							"labtwo.Dsl.EFloat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1014:3: (otherlv_13= 'motorType' ( (lv_motorType_14_0= ruleEString ) ) )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==41) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalDsl.g:1015:4: otherlv_13= 'motorType' ( (lv_motorType_14_0= ruleEString ) )
                    {
                    otherlv_13=(Token)match(input,41,FOLLOW_5); 

                    				newLeafNode(otherlv_13, grammarAccess.getMotorAccess().getMotorTypeKeyword_8_0());
                    			
                    // InternalDsl.g:1019:4: ( (lv_motorType_14_0= ruleEString ) )
                    // InternalDsl.g:1020:5: (lv_motorType_14_0= ruleEString )
                    {
                    // InternalDsl.g:1020:5: (lv_motorType_14_0= ruleEString )
                    // InternalDsl.g:1021:6: lv_motorType_14_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getMotorAccess().getMotorTypeEStringParserRuleCall_8_1_0());
                    					
                    pushFollow(FOLLOW_38);
                    lv_motorType_14_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMotorRule());
                    						}
                    						set(
                    							current,
                    							"motorType",
                    							lv_motorType_14_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1039:3: (otherlv_15= 'giveMeasurementsTo' otherlv_16= '(' ( ( ruleEString ) ) (otherlv_18= ',' ( ( ruleEString ) ) )* otherlv_20= ')' )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==42) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalDsl.g:1040:4: otherlv_15= 'giveMeasurementsTo' otherlv_16= '(' ( ( ruleEString ) ) (otherlv_18= ',' ( ( ruleEString ) ) )* otherlv_20= ')'
                    {
                    otherlv_15=(Token)match(input,42,FOLLOW_24); 

                    				newLeafNode(otherlv_15, grammarAccess.getMotorAccess().getGiveMeasurementsToKeyword_9_0());
                    			
                    otherlv_16=(Token)match(input,29,FOLLOW_5); 

                    				newLeafNode(otherlv_16, grammarAccess.getMotorAccess().getLeftParenthesisKeyword_9_1());
                    			
                    // InternalDsl.g:1048:4: ( ( ruleEString ) )
                    // InternalDsl.g:1049:5: ( ruleEString )
                    {
                    // InternalDsl.g:1049:5: ( ruleEString )
                    // InternalDsl.g:1050:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getMotorRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getMotorAccess().getGiveMeasurementsToSensorCrossReference_9_2_0());
                    					
                    pushFollow(FOLLOW_25);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalDsl.g:1064:4: (otherlv_18= ',' ( ( ruleEString ) ) )*
                    loop29:
                    do {
                        int alt29=2;
                        int LA29_0 = input.LA(1);

                        if ( (LA29_0==17) ) {
                            alt29=1;
                        }


                        switch (alt29) {
                    	case 1 :
                    	    // InternalDsl.g:1065:5: otherlv_18= ',' ( ( ruleEString ) )
                    	    {
                    	    otherlv_18=(Token)match(input,17,FOLLOW_5); 

                    	    					newLeafNode(otherlv_18, grammarAccess.getMotorAccess().getCommaKeyword_9_3_0());
                    	    				
                    	    // InternalDsl.g:1069:5: ( ( ruleEString ) )
                    	    // InternalDsl.g:1070:6: ( ruleEString )
                    	    {
                    	    // InternalDsl.g:1070:6: ( ruleEString )
                    	    // InternalDsl.g:1071:7: ruleEString
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getMotorRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getMotorAccess().getGiveMeasurementsToSensorCrossReference_9_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_25);
                    	    ruleEString();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop29;
                        }
                    } while (true);

                    otherlv_20=(Token)match(input,30,FOLLOW_39); 

                    				newLeafNode(otherlv_20, grammarAccess.getMotorAccess().getRightParenthesisKeyword_9_4());
                    			

                    }
                    break;

            }

            // InternalDsl.g:1091:3: (otherlv_21= 'controls' ( ( ruleEString ) ) )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==43) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalDsl.g:1092:4: otherlv_21= 'controls' ( ( ruleEString ) )
                    {
                    otherlv_21=(Token)match(input,43,FOLLOW_5); 

                    				newLeafNode(otherlv_21, grammarAccess.getMotorAccess().getControlsKeyword_10_0());
                    			
                    // InternalDsl.g:1096:4: ( ( ruleEString ) )
                    // InternalDsl.g:1097:5: ( ruleEString )
                    {
                    // InternalDsl.g:1097:5: ( ruleEString )
                    // InternalDsl.g:1098:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getMotorRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getMotorAccess().getControlsMicrocontrollerCrossReference_10_1_0());
                    					
                    pushFollow(FOLLOW_40);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1113:3: (otherlv_23= 'includedIn' otherlv_24= '(' ( ( ruleEString ) ) (otherlv_26= ',' ( ( ruleEString ) ) )* otherlv_28= ')' )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==44) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // InternalDsl.g:1114:4: otherlv_23= 'includedIn' otherlv_24= '(' ( ( ruleEString ) ) (otherlv_26= ',' ( ( ruleEString ) ) )* otherlv_28= ')'
                    {
                    otherlv_23=(Token)match(input,44,FOLLOW_24); 

                    				newLeafNode(otherlv_23, grammarAccess.getMotorAccess().getIncludedInKeyword_11_0());
                    			
                    otherlv_24=(Token)match(input,29,FOLLOW_5); 

                    				newLeafNode(otherlv_24, grammarAccess.getMotorAccess().getLeftParenthesisKeyword_11_1());
                    			
                    // InternalDsl.g:1122:4: ( ( ruleEString ) )
                    // InternalDsl.g:1123:5: ( ruleEString )
                    {
                    // InternalDsl.g:1123:5: ( ruleEString )
                    // InternalDsl.g:1124:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getMotorRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getMotorAccess().getIncludedInBatteryCrossReference_11_2_0());
                    					
                    pushFollow(FOLLOW_25);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalDsl.g:1138:4: (otherlv_26= ',' ( ( ruleEString ) ) )*
                    loop32:
                    do {
                        int alt32=2;
                        int LA32_0 = input.LA(1);

                        if ( (LA32_0==17) ) {
                            alt32=1;
                        }


                        switch (alt32) {
                    	case 1 :
                    	    // InternalDsl.g:1139:5: otherlv_26= ',' ( ( ruleEString ) )
                    	    {
                    	    otherlv_26=(Token)match(input,17,FOLLOW_5); 

                    	    					newLeafNode(otherlv_26, grammarAccess.getMotorAccess().getCommaKeyword_11_3_0());
                    	    				
                    	    // InternalDsl.g:1143:5: ( ( ruleEString ) )
                    	    // InternalDsl.g:1144:6: ( ruleEString )
                    	    {
                    	    // InternalDsl.g:1144:6: ( ruleEString )
                    	    // InternalDsl.g:1145:7: ruleEString
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getMotorRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getMotorAccess().getIncludedInBatteryCrossReference_11_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_25);
                    	    ruleEString();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop32;
                        }
                    } while (true);

                    otherlv_28=(Token)match(input,30,FOLLOW_41); 

                    				newLeafNode(otherlv_28, grammarAccess.getMotorAccess().getRightParenthesisKeyword_11_4());
                    			

                    }
                    break;

            }

            // InternalDsl.g:1165:3: (otherlv_29= 'command' ( ( ruleEString ) ) )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==45) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // InternalDsl.g:1166:4: otherlv_29= 'command' ( ( ruleEString ) )
                    {
                    otherlv_29=(Token)match(input,45,FOLLOW_5); 

                    				newLeafNode(otherlv_29, grammarAccess.getMotorAccess().getCommandKeyword_12_0());
                    			
                    // InternalDsl.g:1170:4: ( ( ruleEString ) )
                    // InternalDsl.g:1171:5: ( ruleEString )
                    {
                    // InternalDsl.g:1171:5: ( ruleEString )
                    // InternalDsl.g:1172:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getMotorRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getMotorAccess().getCommandActuatorCrossReference_12_1_0());
                    					
                    pushFollow(FOLLOW_14);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_31=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_31, grammarAccess.getMotorAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMotor"


    // $ANTLR start "entryRuleConnectivityModule"
    // InternalDsl.g:1195:1: entryRuleConnectivityModule returns [EObject current=null] : iv_ruleConnectivityModule= ruleConnectivityModule EOF ;
    public final EObject entryRuleConnectivityModule() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConnectivityModule = null;


        try {
            // InternalDsl.g:1195:59: (iv_ruleConnectivityModule= ruleConnectivityModule EOF )
            // InternalDsl.g:1196:2: iv_ruleConnectivityModule= ruleConnectivityModule EOF
            {
             newCompositeNode(grammarAccess.getConnectivityModuleRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConnectivityModule=ruleConnectivityModule();

            state._fsp--;

             current =iv_ruleConnectivityModule; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConnectivityModule"


    // $ANTLR start "ruleConnectivityModule"
    // InternalDsl.g:1202:1: ruleConnectivityModule returns [EObject current=null] : ( () otherlv_1= 'ConnectivityModule' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'protocol' ( (lv_protocol_8_0= ruleEString ) ) )? (otherlv_9= 'bandwidth' ( (lv_bandwidth_10_0= ruleEFloat ) ) )? (otherlv_11= 'range' ( (lv_range_12_0= ruleEFloat ) ) )? (otherlv_13= 'integratedWith' ( ( ruleEString ) ) )? (otherlv_15= 'connects' otherlv_16= '(' ( ( ruleEString ) ) (otherlv_18= ',' ( ( ruleEString ) ) )* otherlv_20= ')' )? otherlv_21= '}' ) ;
    public final EObject ruleConnectivityModule() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token otherlv_18=null;
        Token otherlv_20=null;
        Token otherlv_21=null;
        AntlrDatatypeRuleToken lv_serialNumber_4_0 = null;

        AntlrDatatypeRuleToken lv_manufacturer_6_0 = null;

        AntlrDatatypeRuleToken lv_protocol_8_0 = null;

        AntlrDatatypeRuleToken lv_bandwidth_10_0 = null;

        AntlrDatatypeRuleToken lv_range_12_0 = null;



        	enterRule();

        try {
            // InternalDsl.g:1208:2: ( ( () otherlv_1= 'ConnectivityModule' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'protocol' ( (lv_protocol_8_0= ruleEString ) ) )? (otherlv_9= 'bandwidth' ( (lv_bandwidth_10_0= ruleEFloat ) ) )? (otherlv_11= 'range' ( (lv_range_12_0= ruleEFloat ) ) )? (otherlv_13= 'integratedWith' ( ( ruleEString ) ) )? (otherlv_15= 'connects' otherlv_16= '(' ( ( ruleEString ) ) (otherlv_18= ',' ( ( ruleEString ) ) )* otherlv_20= ')' )? otherlv_21= '}' ) )
            // InternalDsl.g:1209:2: ( () otherlv_1= 'ConnectivityModule' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'protocol' ( (lv_protocol_8_0= ruleEString ) ) )? (otherlv_9= 'bandwidth' ( (lv_bandwidth_10_0= ruleEFloat ) ) )? (otherlv_11= 'range' ( (lv_range_12_0= ruleEFloat ) ) )? (otherlv_13= 'integratedWith' ( ( ruleEString ) ) )? (otherlv_15= 'connects' otherlv_16= '(' ( ( ruleEString ) ) (otherlv_18= ',' ( ( ruleEString ) ) )* otherlv_20= ')' )? otherlv_21= '}' )
            {
            // InternalDsl.g:1209:2: ( () otherlv_1= 'ConnectivityModule' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'protocol' ( (lv_protocol_8_0= ruleEString ) ) )? (otherlv_9= 'bandwidth' ( (lv_bandwidth_10_0= ruleEFloat ) ) )? (otherlv_11= 'range' ( (lv_range_12_0= ruleEFloat ) ) )? (otherlv_13= 'integratedWith' ( ( ruleEString ) ) )? (otherlv_15= 'connects' otherlv_16= '(' ( ( ruleEString ) ) (otherlv_18= ',' ( ( ruleEString ) ) )* otherlv_20= ')' )? otherlv_21= '}' )
            // InternalDsl.g:1210:3: () otherlv_1= 'ConnectivityModule' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'protocol' ( (lv_protocol_8_0= ruleEString ) ) )? (otherlv_9= 'bandwidth' ( (lv_bandwidth_10_0= ruleEFloat ) ) )? (otherlv_11= 'range' ( (lv_range_12_0= ruleEFloat ) ) )? (otherlv_13= 'integratedWith' ( ( ruleEString ) ) )? (otherlv_15= 'connects' otherlv_16= '(' ( ( ruleEString ) ) (otherlv_18= ',' ( ( ruleEString ) ) )* otherlv_20= ')' )? otherlv_21= '}'
            {
            // InternalDsl.g:1210:3: ()
            // InternalDsl.g:1211:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getConnectivityModuleAccess().getConnectivityModuleAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,46,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getConnectivityModuleAccess().getConnectivityModuleKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_42); 

            			newLeafNode(otherlv_2, grammarAccess.getConnectivityModuleAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalDsl.g:1225:3: (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==32) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalDsl.g:1226:4: otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,32,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getConnectivityModuleAccess().getSerialNumberKeyword_3_0());
                    			
                    // InternalDsl.g:1230:4: ( (lv_serialNumber_4_0= ruleEString ) )
                    // InternalDsl.g:1231:5: (lv_serialNumber_4_0= ruleEString )
                    {
                    // InternalDsl.g:1231:5: (lv_serialNumber_4_0= ruleEString )
                    // InternalDsl.g:1232:6: lv_serialNumber_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getConnectivityModuleAccess().getSerialNumberEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_43);
                    lv_serialNumber_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getConnectivityModuleRule());
                    						}
                    						set(
                    							current,
                    							"serialNumber",
                    							lv_serialNumber_4_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1250:3: (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )?
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==27) ) {
                alt36=1;
            }
            switch (alt36) {
                case 1 :
                    // InternalDsl.g:1251:4: otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) )
                    {
                    otherlv_5=(Token)match(input,27,FOLLOW_5); 

                    				newLeafNode(otherlv_5, grammarAccess.getConnectivityModuleAccess().getManufacturerKeyword_4_0());
                    			
                    // InternalDsl.g:1255:4: ( (lv_manufacturer_6_0= ruleEString ) )
                    // InternalDsl.g:1256:5: (lv_manufacturer_6_0= ruleEString )
                    {
                    // InternalDsl.g:1256:5: (lv_manufacturer_6_0= ruleEString )
                    // InternalDsl.g:1257:6: lv_manufacturer_6_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getConnectivityModuleAccess().getManufacturerEStringParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_44);
                    lv_manufacturer_6_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getConnectivityModuleRule());
                    						}
                    						set(
                    							current,
                    							"manufacturer",
                    							lv_manufacturer_6_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1275:3: (otherlv_7= 'protocol' ( (lv_protocol_8_0= ruleEString ) ) )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==47) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalDsl.g:1276:4: otherlv_7= 'protocol' ( (lv_protocol_8_0= ruleEString ) )
                    {
                    otherlv_7=(Token)match(input,47,FOLLOW_5); 

                    				newLeafNode(otherlv_7, grammarAccess.getConnectivityModuleAccess().getProtocolKeyword_5_0());
                    			
                    // InternalDsl.g:1280:4: ( (lv_protocol_8_0= ruleEString ) )
                    // InternalDsl.g:1281:5: (lv_protocol_8_0= ruleEString )
                    {
                    // InternalDsl.g:1281:5: (lv_protocol_8_0= ruleEString )
                    // InternalDsl.g:1282:6: lv_protocol_8_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getConnectivityModuleAccess().getProtocolEStringParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_45);
                    lv_protocol_8_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getConnectivityModuleRule());
                    						}
                    						set(
                    							current,
                    							"protocol",
                    							lv_protocol_8_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1300:3: (otherlv_9= 'bandwidth' ( (lv_bandwidth_10_0= ruleEFloat ) ) )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==48) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // InternalDsl.g:1301:4: otherlv_9= 'bandwidth' ( (lv_bandwidth_10_0= ruleEFloat ) )
                    {
                    otherlv_9=(Token)match(input,48,FOLLOW_16); 

                    				newLeafNode(otherlv_9, grammarAccess.getConnectivityModuleAccess().getBandwidthKeyword_6_0());
                    			
                    // InternalDsl.g:1305:4: ( (lv_bandwidth_10_0= ruleEFloat ) )
                    // InternalDsl.g:1306:5: (lv_bandwidth_10_0= ruleEFloat )
                    {
                    // InternalDsl.g:1306:5: (lv_bandwidth_10_0= ruleEFloat )
                    // InternalDsl.g:1307:6: lv_bandwidth_10_0= ruleEFloat
                    {

                    						newCompositeNode(grammarAccess.getConnectivityModuleAccess().getBandwidthEFloatParserRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_46);
                    lv_bandwidth_10_0=ruleEFloat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getConnectivityModuleRule());
                    						}
                    						set(
                    							current,
                    							"bandwidth",
                    							lv_bandwidth_10_0,
                    							"labtwo.Dsl.EFloat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1325:3: (otherlv_11= 'range' ( (lv_range_12_0= ruleEFloat ) ) )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==34) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalDsl.g:1326:4: otherlv_11= 'range' ( (lv_range_12_0= ruleEFloat ) )
                    {
                    otherlv_11=(Token)match(input,34,FOLLOW_16); 

                    				newLeafNode(otherlv_11, grammarAccess.getConnectivityModuleAccess().getRangeKeyword_7_0());
                    			
                    // InternalDsl.g:1330:4: ( (lv_range_12_0= ruleEFloat ) )
                    // InternalDsl.g:1331:5: (lv_range_12_0= ruleEFloat )
                    {
                    // InternalDsl.g:1331:5: (lv_range_12_0= ruleEFloat )
                    // InternalDsl.g:1332:6: lv_range_12_0= ruleEFloat
                    {

                    						newCompositeNode(grammarAccess.getConnectivityModuleAccess().getRangeEFloatParserRuleCall_7_1_0());
                    					
                    pushFollow(FOLLOW_47);
                    lv_range_12_0=ruleEFloat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getConnectivityModuleRule());
                    						}
                    						set(
                    							current,
                    							"range",
                    							lv_range_12_0,
                    							"labtwo.Dsl.EFloat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1350:3: (otherlv_13= 'integratedWith' ( ( ruleEString ) ) )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==49) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalDsl.g:1351:4: otherlv_13= 'integratedWith' ( ( ruleEString ) )
                    {
                    otherlv_13=(Token)match(input,49,FOLLOW_5); 

                    				newLeafNode(otherlv_13, grammarAccess.getConnectivityModuleAccess().getIntegratedWithKeyword_8_0());
                    			
                    // InternalDsl.g:1355:4: ( ( ruleEString ) )
                    // InternalDsl.g:1356:5: ( ruleEString )
                    {
                    // InternalDsl.g:1356:5: ( ruleEString )
                    // InternalDsl.g:1357:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getConnectivityModuleRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getConnectivityModuleAccess().getIntegratedWithBatteryCrossReference_8_1_0());
                    					
                    pushFollow(FOLLOW_48);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1372:3: (otherlv_15= 'connects' otherlv_16= '(' ( ( ruleEString ) ) (otherlv_18= ',' ( ( ruleEString ) ) )* otherlv_20= ')' )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==50) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalDsl.g:1373:4: otherlv_15= 'connects' otherlv_16= '(' ( ( ruleEString ) ) (otherlv_18= ',' ( ( ruleEString ) ) )* otherlv_20= ')'
                    {
                    otherlv_15=(Token)match(input,50,FOLLOW_24); 

                    				newLeafNode(otherlv_15, grammarAccess.getConnectivityModuleAccess().getConnectsKeyword_9_0());
                    			
                    otherlv_16=(Token)match(input,29,FOLLOW_5); 

                    				newLeafNode(otherlv_16, grammarAccess.getConnectivityModuleAccess().getLeftParenthesisKeyword_9_1());
                    			
                    // InternalDsl.g:1381:4: ( ( ruleEString ) )
                    // InternalDsl.g:1382:5: ( ruleEString )
                    {
                    // InternalDsl.g:1382:5: ( ruleEString )
                    // InternalDsl.g:1383:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getConnectivityModuleRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getConnectivityModuleAccess().getConnectsMicrocontrollerCrossReference_9_2_0());
                    					
                    pushFollow(FOLLOW_25);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalDsl.g:1397:4: (otherlv_18= ',' ( ( ruleEString ) ) )*
                    loop41:
                    do {
                        int alt41=2;
                        int LA41_0 = input.LA(1);

                        if ( (LA41_0==17) ) {
                            alt41=1;
                        }


                        switch (alt41) {
                    	case 1 :
                    	    // InternalDsl.g:1398:5: otherlv_18= ',' ( ( ruleEString ) )
                    	    {
                    	    otherlv_18=(Token)match(input,17,FOLLOW_5); 

                    	    					newLeafNode(otherlv_18, grammarAccess.getConnectivityModuleAccess().getCommaKeyword_9_3_0());
                    	    				
                    	    // InternalDsl.g:1402:5: ( ( ruleEString ) )
                    	    // InternalDsl.g:1403:6: ( ruleEString )
                    	    {
                    	    // InternalDsl.g:1403:6: ( ruleEString )
                    	    // InternalDsl.g:1404:7: ruleEString
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getConnectivityModuleRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getConnectivityModuleAccess().getConnectsMicrocontrollerCrossReference_9_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_25);
                    	    ruleEString();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop41;
                        }
                    } while (true);

                    otherlv_20=(Token)match(input,30,FOLLOW_14); 

                    				newLeafNode(otherlv_20, grammarAccess.getConnectivityModuleAccess().getRightParenthesisKeyword_9_4());
                    			

                    }
                    break;

            }

            otherlv_21=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_21, grammarAccess.getConnectivityModuleAccess().getRightCurlyBracketKeyword_10());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConnectivityModule"


    // $ANTLR start "entryRuleMicrocontroller"
    // InternalDsl.g:1432:1: entryRuleMicrocontroller returns [EObject current=null] : iv_ruleMicrocontroller= ruleMicrocontroller EOF ;
    public final EObject entryRuleMicrocontroller() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMicrocontroller = null;


        try {
            // InternalDsl.g:1432:56: (iv_ruleMicrocontroller= ruleMicrocontroller EOF )
            // InternalDsl.g:1433:2: iv_ruleMicrocontroller= ruleMicrocontroller EOF
            {
             newCompositeNode(grammarAccess.getMicrocontrollerRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMicrocontroller=ruleMicrocontroller();

            state._fsp--;

             current =iv_ruleMicrocontroller; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMicrocontroller"


    // $ANTLR start "ruleMicrocontroller"
    // InternalDsl.g:1439:1: ruleMicrocontroller returns [EObject current=null] : (otherlv_0= 'Microcontroller' otherlv_1= '{' (otherlv_2= 'serialNumber' ( (lv_serialNumber_3_0= ruleEString ) ) )? (otherlv_4= 'manufacturer' ( (lv_manufacturer_5_0= ruleEString ) ) )? (otherlv_6= 'cores' ( (lv_cores_7_0= ruleEInt ) ) )? (otherlv_8= 'clockSpeed' ( (lv_clockSpeed_9_0= ruleEFloat ) ) )? (otherlv_10= 'archeticture' ( (lv_archeticture_11_0= ruleArchitectureType ) ) )? (otherlv_12= 'GPIOs' ( (lv_GPIOs_13_0= ruleEInt ) ) )? otherlv_14= 'battery' otherlv_15= '(' ( ( ruleEString ) ) (otherlv_17= ',' ( ( ruleEString ) ) )* otherlv_19= ')' (otherlv_20= 'controlledBy' otherlv_21= '(' ( ( ruleEString ) ) (otherlv_23= ',' ( ( ruleEString ) ) )* otherlv_25= ')' )? otherlv_26= '}' ) ;
    public final EObject ruleMicrocontroller() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_15=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        Token otherlv_20=null;
        Token otherlv_21=null;
        Token otherlv_23=null;
        Token otherlv_25=null;
        Token otherlv_26=null;
        AntlrDatatypeRuleToken lv_serialNumber_3_0 = null;

        AntlrDatatypeRuleToken lv_manufacturer_5_0 = null;

        AntlrDatatypeRuleToken lv_cores_7_0 = null;

        AntlrDatatypeRuleToken lv_clockSpeed_9_0 = null;

        Enumerator lv_archeticture_11_0 = null;

        AntlrDatatypeRuleToken lv_GPIOs_13_0 = null;



        	enterRule();

        try {
            // InternalDsl.g:1445:2: ( (otherlv_0= 'Microcontroller' otherlv_1= '{' (otherlv_2= 'serialNumber' ( (lv_serialNumber_3_0= ruleEString ) ) )? (otherlv_4= 'manufacturer' ( (lv_manufacturer_5_0= ruleEString ) ) )? (otherlv_6= 'cores' ( (lv_cores_7_0= ruleEInt ) ) )? (otherlv_8= 'clockSpeed' ( (lv_clockSpeed_9_0= ruleEFloat ) ) )? (otherlv_10= 'archeticture' ( (lv_archeticture_11_0= ruleArchitectureType ) ) )? (otherlv_12= 'GPIOs' ( (lv_GPIOs_13_0= ruleEInt ) ) )? otherlv_14= 'battery' otherlv_15= '(' ( ( ruleEString ) ) (otherlv_17= ',' ( ( ruleEString ) ) )* otherlv_19= ')' (otherlv_20= 'controlledBy' otherlv_21= '(' ( ( ruleEString ) ) (otherlv_23= ',' ( ( ruleEString ) ) )* otherlv_25= ')' )? otherlv_26= '}' ) )
            // InternalDsl.g:1446:2: (otherlv_0= 'Microcontroller' otherlv_1= '{' (otherlv_2= 'serialNumber' ( (lv_serialNumber_3_0= ruleEString ) ) )? (otherlv_4= 'manufacturer' ( (lv_manufacturer_5_0= ruleEString ) ) )? (otherlv_6= 'cores' ( (lv_cores_7_0= ruleEInt ) ) )? (otherlv_8= 'clockSpeed' ( (lv_clockSpeed_9_0= ruleEFloat ) ) )? (otherlv_10= 'archeticture' ( (lv_archeticture_11_0= ruleArchitectureType ) ) )? (otherlv_12= 'GPIOs' ( (lv_GPIOs_13_0= ruleEInt ) ) )? otherlv_14= 'battery' otherlv_15= '(' ( ( ruleEString ) ) (otherlv_17= ',' ( ( ruleEString ) ) )* otherlv_19= ')' (otherlv_20= 'controlledBy' otherlv_21= '(' ( ( ruleEString ) ) (otherlv_23= ',' ( ( ruleEString ) ) )* otherlv_25= ')' )? otherlv_26= '}' )
            {
            // InternalDsl.g:1446:2: (otherlv_0= 'Microcontroller' otherlv_1= '{' (otherlv_2= 'serialNumber' ( (lv_serialNumber_3_0= ruleEString ) ) )? (otherlv_4= 'manufacturer' ( (lv_manufacturer_5_0= ruleEString ) ) )? (otherlv_6= 'cores' ( (lv_cores_7_0= ruleEInt ) ) )? (otherlv_8= 'clockSpeed' ( (lv_clockSpeed_9_0= ruleEFloat ) ) )? (otherlv_10= 'archeticture' ( (lv_archeticture_11_0= ruleArchitectureType ) ) )? (otherlv_12= 'GPIOs' ( (lv_GPIOs_13_0= ruleEInt ) ) )? otherlv_14= 'battery' otherlv_15= '(' ( ( ruleEString ) ) (otherlv_17= ',' ( ( ruleEString ) ) )* otherlv_19= ')' (otherlv_20= 'controlledBy' otherlv_21= '(' ( ( ruleEString ) ) (otherlv_23= ',' ( ( ruleEString ) ) )* otherlv_25= ')' )? otherlv_26= '}' )
            // InternalDsl.g:1447:3: otherlv_0= 'Microcontroller' otherlv_1= '{' (otherlv_2= 'serialNumber' ( (lv_serialNumber_3_0= ruleEString ) ) )? (otherlv_4= 'manufacturer' ( (lv_manufacturer_5_0= ruleEString ) ) )? (otherlv_6= 'cores' ( (lv_cores_7_0= ruleEInt ) ) )? (otherlv_8= 'clockSpeed' ( (lv_clockSpeed_9_0= ruleEFloat ) ) )? (otherlv_10= 'archeticture' ( (lv_archeticture_11_0= ruleArchitectureType ) ) )? (otherlv_12= 'GPIOs' ( (lv_GPIOs_13_0= ruleEInt ) ) )? otherlv_14= 'battery' otherlv_15= '(' ( ( ruleEString ) ) (otherlv_17= ',' ( ( ruleEString ) ) )* otherlv_19= ')' (otherlv_20= 'controlledBy' otherlv_21= '(' ( ( ruleEString ) ) (otherlv_23= ',' ( ( ruleEString ) ) )* otherlv_25= ')' )? otherlv_26= '}'
            {
            otherlv_0=(Token)match(input,51,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getMicrocontrollerAccess().getMicrocontrollerKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_49); 

            			newLeafNode(otherlv_1, grammarAccess.getMicrocontrollerAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalDsl.g:1455:3: (otherlv_2= 'serialNumber' ( (lv_serialNumber_3_0= ruleEString ) ) )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==32) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalDsl.g:1456:4: otherlv_2= 'serialNumber' ( (lv_serialNumber_3_0= ruleEString ) )
                    {
                    otherlv_2=(Token)match(input,32,FOLLOW_5); 

                    				newLeafNode(otherlv_2, grammarAccess.getMicrocontrollerAccess().getSerialNumberKeyword_2_0());
                    			
                    // InternalDsl.g:1460:4: ( (lv_serialNumber_3_0= ruleEString ) )
                    // InternalDsl.g:1461:5: (lv_serialNumber_3_0= ruleEString )
                    {
                    // InternalDsl.g:1461:5: (lv_serialNumber_3_0= ruleEString )
                    // InternalDsl.g:1462:6: lv_serialNumber_3_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getMicrocontrollerAccess().getSerialNumberEStringParserRuleCall_2_1_0());
                    					
                    pushFollow(FOLLOW_50);
                    lv_serialNumber_3_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMicrocontrollerRule());
                    						}
                    						set(
                    							current,
                    							"serialNumber",
                    							lv_serialNumber_3_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1480:3: (otherlv_4= 'manufacturer' ( (lv_manufacturer_5_0= ruleEString ) ) )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==27) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalDsl.g:1481:4: otherlv_4= 'manufacturer' ( (lv_manufacturer_5_0= ruleEString ) )
                    {
                    otherlv_4=(Token)match(input,27,FOLLOW_5); 

                    				newLeafNode(otherlv_4, grammarAccess.getMicrocontrollerAccess().getManufacturerKeyword_3_0());
                    			
                    // InternalDsl.g:1485:4: ( (lv_manufacturer_5_0= ruleEString ) )
                    // InternalDsl.g:1486:5: (lv_manufacturer_5_0= ruleEString )
                    {
                    // InternalDsl.g:1486:5: (lv_manufacturer_5_0= ruleEString )
                    // InternalDsl.g:1487:6: lv_manufacturer_5_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getMicrocontrollerAccess().getManufacturerEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_51);
                    lv_manufacturer_5_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMicrocontrollerRule());
                    						}
                    						set(
                    							current,
                    							"manufacturer",
                    							lv_manufacturer_5_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1505:3: (otherlv_6= 'cores' ( (lv_cores_7_0= ruleEInt ) ) )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==52) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalDsl.g:1506:4: otherlv_6= 'cores' ( (lv_cores_7_0= ruleEInt ) )
                    {
                    otherlv_6=(Token)match(input,52,FOLLOW_20); 

                    				newLeafNode(otherlv_6, grammarAccess.getMicrocontrollerAccess().getCoresKeyword_4_0());
                    			
                    // InternalDsl.g:1510:4: ( (lv_cores_7_0= ruleEInt ) )
                    // InternalDsl.g:1511:5: (lv_cores_7_0= ruleEInt )
                    {
                    // InternalDsl.g:1511:5: (lv_cores_7_0= ruleEInt )
                    // InternalDsl.g:1512:6: lv_cores_7_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getMicrocontrollerAccess().getCoresEIntParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_52);
                    lv_cores_7_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMicrocontrollerRule());
                    						}
                    						set(
                    							current,
                    							"cores",
                    							lv_cores_7_0,
                    							"labtwo.Dsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1530:3: (otherlv_8= 'clockSpeed' ( (lv_clockSpeed_9_0= ruleEFloat ) ) )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==53) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalDsl.g:1531:4: otherlv_8= 'clockSpeed' ( (lv_clockSpeed_9_0= ruleEFloat ) )
                    {
                    otherlv_8=(Token)match(input,53,FOLLOW_16); 

                    				newLeafNode(otherlv_8, grammarAccess.getMicrocontrollerAccess().getClockSpeedKeyword_5_0());
                    			
                    // InternalDsl.g:1535:4: ( (lv_clockSpeed_9_0= ruleEFloat ) )
                    // InternalDsl.g:1536:5: (lv_clockSpeed_9_0= ruleEFloat )
                    {
                    // InternalDsl.g:1536:5: (lv_clockSpeed_9_0= ruleEFloat )
                    // InternalDsl.g:1537:6: lv_clockSpeed_9_0= ruleEFloat
                    {

                    						newCompositeNode(grammarAccess.getMicrocontrollerAccess().getClockSpeedEFloatParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_53);
                    lv_clockSpeed_9_0=ruleEFloat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMicrocontrollerRule());
                    						}
                    						set(
                    							current,
                    							"clockSpeed",
                    							lv_clockSpeed_9_0,
                    							"labtwo.Dsl.EFloat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1555:3: (otherlv_10= 'archeticture' ( (lv_archeticture_11_0= ruleArchitectureType ) ) )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==54) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalDsl.g:1556:4: otherlv_10= 'archeticture' ( (lv_archeticture_11_0= ruleArchitectureType ) )
                    {
                    otherlv_10=(Token)match(input,54,FOLLOW_54); 

                    				newLeafNode(otherlv_10, grammarAccess.getMicrocontrollerAccess().getArchetictureKeyword_6_0());
                    			
                    // InternalDsl.g:1560:4: ( (lv_archeticture_11_0= ruleArchitectureType ) )
                    // InternalDsl.g:1561:5: (lv_archeticture_11_0= ruleArchitectureType )
                    {
                    // InternalDsl.g:1561:5: (lv_archeticture_11_0= ruleArchitectureType )
                    // InternalDsl.g:1562:6: lv_archeticture_11_0= ruleArchitectureType
                    {

                    						newCompositeNode(grammarAccess.getMicrocontrollerAccess().getArchetictureArchitectureTypeEnumRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_55);
                    lv_archeticture_11_0=ruleArchitectureType();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMicrocontrollerRule());
                    						}
                    						set(
                    							current,
                    							"archeticture",
                    							lv_archeticture_11_0,
                    							"labtwo.Dsl.ArchitectureType");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1580:3: (otherlv_12= 'GPIOs' ( (lv_GPIOs_13_0= ruleEInt ) ) )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( (LA48_0==55) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalDsl.g:1581:4: otherlv_12= 'GPIOs' ( (lv_GPIOs_13_0= ruleEInt ) )
                    {
                    otherlv_12=(Token)match(input,55,FOLLOW_20); 

                    				newLeafNode(otherlv_12, grammarAccess.getMicrocontrollerAccess().getGPIOsKeyword_7_0());
                    			
                    // InternalDsl.g:1585:4: ( (lv_GPIOs_13_0= ruleEInt ) )
                    // InternalDsl.g:1586:5: (lv_GPIOs_13_0= ruleEInt )
                    {
                    // InternalDsl.g:1586:5: (lv_GPIOs_13_0= ruleEInt )
                    // InternalDsl.g:1587:6: lv_GPIOs_13_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getMicrocontrollerAccess().getGPIOsEIntParserRuleCall_7_1_0());
                    					
                    pushFollow(FOLLOW_56);
                    lv_GPIOs_13_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMicrocontrollerRule());
                    						}
                    						set(
                    							current,
                    							"GPIOs",
                    							lv_GPIOs_13_0,
                    							"labtwo.Dsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_14=(Token)match(input,56,FOLLOW_24); 

            			newLeafNode(otherlv_14, grammarAccess.getMicrocontrollerAccess().getBatteryKeyword_8());
            		
            otherlv_15=(Token)match(input,29,FOLLOW_5); 

            			newLeafNode(otherlv_15, grammarAccess.getMicrocontrollerAccess().getLeftParenthesisKeyword_9());
            		
            // InternalDsl.g:1613:3: ( ( ruleEString ) )
            // InternalDsl.g:1614:4: ( ruleEString )
            {
            // InternalDsl.g:1614:4: ( ruleEString )
            // InternalDsl.g:1615:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMicrocontrollerRule());
            					}
            				

            					newCompositeNode(grammarAccess.getMicrocontrollerAccess().getBatteryBatteryCrossReference_10_0());
            				
            pushFollow(FOLLOW_25);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalDsl.g:1629:3: (otherlv_17= ',' ( ( ruleEString ) ) )*
            loop49:
            do {
                int alt49=2;
                int LA49_0 = input.LA(1);

                if ( (LA49_0==17) ) {
                    alt49=1;
                }


                switch (alt49) {
            	case 1 :
            	    // InternalDsl.g:1630:4: otherlv_17= ',' ( ( ruleEString ) )
            	    {
            	    otherlv_17=(Token)match(input,17,FOLLOW_5); 

            	    				newLeafNode(otherlv_17, grammarAccess.getMicrocontrollerAccess().getCommaKeyword_11_0());
            	    			
            	    // InternalDsl.g:1634:4: ( ( ruleEString ) )
            	    // InternalDsl.g:1635:5: ( ruleEString )
            	    {
            	    // InternalDsl.g:1635:5: ( ruleEString )
            	    // InternalDsl.g:1636:6: ruleEString
            	    {

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getMicrocontrollerRule());
            	    						}
            	    					

            	    						newCompositeNode(grammarAccess.getMicrocontrollerAccess().getBatteryBatteryCrossReference_11_1_0());
            	    					
            	    pushFollow(FOLLOW_25);
            	    ruleEString();

            	    state._fsp--;


            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop49;
                }
            } while (true);

            otherlv_19=(Token)match(input,30,FOLLOW_57); 

            			newLeafNode(otherlv_19, grammarAccess.getMicrocontrollerAccess().getRightParenthesisKeyword_12());
            		
            // InternalDsl.g:1655:3: (otherlv_20= 'controlledBy' otherlv_21= '(' ( ( ruleEString ) ) (otherlv_23= ',' ( ( ruleEString ) ) )* otherlv_25= ')' )?
            int alt51=2;
            int LA51_0 = input.LA(1);

            if ( (LA51_0==57) ) {
                alt51=1;
            }
            switch (alt51) {
                case 1 :
                    // InternalDsl.g:1656:4: otherlv_20= 'controlledBy' otherlv_21= '(' ( ( ruleEString ) ) (otherlv_23= ',' ( ( ruleEString ) ) )* otherlv_25= ')'
                    {
                    otherlv_20=(Token)match(input,57,FOLLOW_24); 

                    				newLeafNode(otherlv_20, grammarAccess.getMicrocontrollerAccess().getControlledByKeyword_13_0());
                    			
                    otherlv_21=(Token)match(input,29,FOLLOW_5); 

                    				newLeafNode(otherlv_21, grammarAccess.getMicrocontrollerAccess().getLeftParenthesisKeyword_13_1());
                    			
                    // InternalDsl.g:1664:4: ( ( ruleEString ) )
                    // InternalDsl.g:1665:5: ( ruleEString )
                    {
                    // InternalDsl.g:1665:5: ( ruleEString )
                    // InternalDsl.g:1666:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getMicrocontrollerRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getMicrocontrollerAccess().getControlledByMotorCrossReference_13_2_0());
                    					
                    pushFollow(FOLLOW_25);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalDsl.g:1680:4: (otherlv_23= ',' ( ( ruleEString ) ) )*
                    loop50:
                    do {
                        int alt50=2;
                        int LA50_0 = input.LA(1);

                        if ( (LA50_0==17) ) {
                            alt50=1;
                        }


                        switch (alt50) {
                    	case 1 :
                    	    // InternalDsl.g:1681:5: otherlv_23= ',' ( ( ruleEString ) )
                    	    {
                    	    otherlv_23=(Token)match(input,17,FOLLOW_5); 

                    	    					newLeafNode(otherlv_23, grammarAccess.getMicrocontrollerAccess().getCommaKeyword_13_3_0());
                    	    				
                    	    // InternalDsl.g:1685:5: ( ( ruleEString ) )
                    	    // InternalDsl.g:1686:6: ( ruleEString )
                    	    {
                    	    // InternalDsl.g:1686:6: ( ruleEString )
                    	    // InternalDsl.g:1687:7: ruleEString
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getMicrocontrollerRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getMicrocontrollerAccess().getControlledByMotorCrossReference_13_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_25);
                    	    ruleEString();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop50;
                        }
                    } while (true);

                    otherlv_25=(Token)match(input,30,FOLLOW_14); 

                    				newLeafNode(otherlv_25, grammarAccess.getMicrocontrollerAccess().getRightParenthesisKeyword_13_4());
                    			

                    }
                    break;

            }

            otherlv_26=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_26, grammarAccess.getMicrocontrollerAccess().getRightCurlyBracketKeyword_14());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMicrocontroller"


    // $ANTLR start "entryRuleSensor"
    // InternalDsl.g:1715:1: entryRuleSensor returns [EObject current=null] : iv_ruleSensor= ruleSensor EOF ;
    public final EObject entryRuleSensor() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSensor = null;


        try {
            // InternalDsl.g:1715:47: (iv_ruleSensor= ruleSensor EOF )
            // InternalDsl.g:1716:2: iv_ruleSensor= ruleSensor EOF
            {
             newCompositeNode(grammarAccess.getSensorRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSensor=ruleSensor();

            state._fsp--;

             current =iv_ruleSensor; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSensor"


    // $ANTLR start "ruleSensor"
    // InternalDsl.g:1722:1: ruleSensor returns [EObject current=null] : (otherlv_0= 'Sensor' otherlv_1= '{' (otherlv_2= 'serialNumber' ( (lv_serialNumber_3_0= ruleEString ) ) )? (otherlv_4= 'manufacturer' ( (lv_manufacturer_5_0= ruleEString ) ) )? (otherlv_6= 'type' ( (lv_type_7_0= ruleSensorType ) ) )? (otherlv_8= 'range' ( (lv_range_9_0= ruleEInt ) ) )? (otherlv_10= 'samplingRate' ( (lv_samplingRate_11_0= ruleEFloat ) ) )? (otherlv_12= 'outputSignal' ( (lv_outputSignal_13_0= ruleEString ) ) )? otherlv_14= 'impacts' otherlv_15= '(' ( ( ruleEString ) ) (otherlv_17= ',' ( ( ruleEString ) ) )* otherlv_19= ')' otherlv_20= '}' ) ;
    public final EObject ruleSensor() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_15=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        Token otherlv_20=null;
        AntlrDatatypeRuleToken lv_serialNumber_3_0 = null;

        AntlrDatatypeRuleToken lv_manufacturer_5_0 = null;

        Enumerator lv_type_7_0 = null;

        AntlrDatatypeRuleToken lv_range_9_0 = null;

        AntlrDatatypeRuleToken lv_samplingRate_11_0 = null;

        AntlrDatatypeRuleToken lv_outputSignal_13_0 = null;



        	enterRule();

        try {
            // InternalDsl.g:1728:2: ( (otherlv_0= 'Sensor' otherlv_1= '{' (otherlv_2= 'serialNumber' ( (lv_serialNumber_3_0= ruleEString ) ) )? (otherlv_4= 'manufacturer' ( (lv_manufacturer_5_0= ruleEString ) ) )? (otherlv_6= 'type' ( (lv_type_7_0= ruleSensorType ) ) )? (otherlv_8= 'range' ( (lv_range_9_0= ruleEInt ) ) )? (otherlv_10= 'samplingRate' ( (lv_samplingRate_11_0= ruleEFloat ) ) )? (otherlv_12= 'outputSignal' ( (lv_outputSignal_13_0= ruleEString ) ) )? otherlv_14= 'impacts' otherlv_15= '(' ( ( ruleEString ) ) (otherlv_17= ',' ( ( ruleEString ) ) )* otherlv_19= ')' otherlv_20= '}' ) )
            // InternalDsl.g:1729:2: (otherlv_0= 'Sensor' otherlv_1= '{' (otherlv_2= 'serialNumber' ( (lv_serialNumber_3_0= ruleEString ) ) )? (otherlv_4= 'manufacturer' ( (lv_manufacturer_5_0= ruleEString ) ) )? (otherlv_6= 'type' ( (lv_type_7_0= ruleSensorType ) ) )? (otherlv_8= 'range' ( (lv_range_9_0= ruleEInt ) ) )? (otherlv_10= 'samplingRate' ( (lv_samplingRate_11_0= ruleEFloat ) ) )? (otherlv_12= 'outputSignal' ( (lv_outputSignal_13_0= ruleEString ) ) )? otherlv_14= 'impacts' otherlv_15= '(' ( ( ruleEString ) ) (otherlv_17= ',' ( ( ruleEString ) ) )* otherlv_19= ')' otherlv_20= '}' )
            {
            // InternalDsl.g:1729:2: (otherlv_0= 'Sensor' otherlv_1= '{' (otherlv_2= 'serialNumber' ( (lv_serialNumber_3_0= ruleEString ) ) )? (otherlv_4= 'manufacturer' ( (lv_manufacturer_5_0= ruleEString ) ) )? (otherlv_6= 'type' ( (lv_type_7_0= ruleSensorType ) ) )? (otherlv_8= 'range' ( (lv_range_9_0= ruleEInt ) ) )? (otherlv_10= 'samplingRate' ( (lv_samplingRate_11_0= ruleEFloat ) ) )? (otherlv_12= 'outputSignal' ( (lv_outputSignal_13_0= ruleEString ) ) )? otherlv_14= 'impacts' otherlv_15= '(' ( ( ruleEString ) ) (otherlv_17= ',' ( ( ruleEString ) ) )* otherlv_19= ')' otherlv_20= '}' )
            // InternalDsl.g:1730:3: otherlv_0= 'Sensor' otherlv_1= '{' (otherlv_2= 'serialNumber' ( (lv_serialNumber_3_0= ruleEString ) ) )? (otherlv_4= 'manufacturer' ( (lv_manufacturer_5_0= ruleEString ) ) )? (otherlv_6= 'type' ( (lv_type_7_0= ruleSensorType ) ) )? (otherlv_8= 'range' ( (lv_range_9_0= ruleEInt ) ) )? (otherlv_10= 'samplingRate' ( (lv_samplingRate_11_0= ruleEFloat ) ) )? (otherlv_12= 'outputSignal' ( (lv_outputSignal_13_0= ruleEString ) ) )? otherlv_14= 'impacts' otherlv_15= '(' ( ( ruleEString ) ) (otherlv_17= ',' ( ( ruleEString ) ) )* otherlv_19= ')' otherlv_20= '}'
            {
            otherlv_0=(Token)match(input,58,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getSensorAccess().getSensorKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_58); 

            			newLeafNode(otherlv_1, grammarAccess.getSensorAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalDsl.g:1738:3: (otherlv_2= 'serialNumber' ( (lv_serialNumber_3_0= ruleEString ) ) )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==32) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalDsl.g:1739:4: otherlv_2= 'serialNumber' ( (lv_serialNumber_3_0= ruleEString ) )
                    {
                    otherlv_2=(Token)match(input,32,FOLLOW_5); 

                    				newLeafNode(otherlv_2, grammarAccess.getSensorAccess().getSerialNumberKeyword_2_0());
                    			
                    // InternalDsl.g:1743:4: ( (lv_serialNumber_3_0= ruleEString ) )
                    // InternalDsl.g:1744:5: (lv_serialNumber_3_0= ruleEString )
                    {
                    // InternalDsl.g:1744:5: (lv_serialNumber_3_0= ruleEString )
                    // InternalDsl.g:1745:6: lv_serialNumber_3_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getSensorAccess().getSerialNumberEStringParserRuleCall_2_1_0());
                    					
                    pushFollow(FOLLOW_59);
                    lv_serialNumber_3_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSensorRule());
                    						}
                    						set(
                    							current,
                    							"serialNumber",
                    							lv_serialNumber_3_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1763:3: (otherlv_4= 'manufacturer' ( (lv_manufacturer_5_0= ruleEString ) ) )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==27) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // InternalDsl.g:1764:4: otherlv_4= 'manufacturer' ( (lv_manufacturer_5_0= ruleEString ) )
                    {
                    otherlv_4=(Token)match(input,27,FOLLOW_5); 

                    				newLeafNode(otherlv_4, grammarAccess.getSensorAccess().getManufacturerKeyword_3_0());
                    			
                    // InternalDsl.g:1768:4: ( (lv_manufacturer_5_0= ruleEString ) )
                    // InternalDsl.g:1769:5: (lv_manufacturer_5_0= ruleEString )
                    {
                    // InternalDsl.g:1769:5: (lv_manufacturer_5_0= ruleEString )
                    // InternalDsl.g:1770:6: lv_manufacturer_5_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getSensorAccess().getManufacturerEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_60);
                    lv_manufacturer_5_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSensorRule());
                    						}
                    						set(
                    							current,
                    							"manufacturer",
                    							lv_manufacturer_5_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1788:3: (otherlv_6= 'type' ( (lv_type_7_0= ruleSensorType ) ) )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==33) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // InternalDsl.g:1789:4: otherlv_6= 'type' ( (lv_type_7_0= ruleSensorType ) )
                    {
                    otherlv_6=(Token)match(input,33,FOLLOW_61); 

                    				newLeafNode(otherlv_6, grammarAccess.getSensorAccess().getTypeKeyword_4_0());
                    			
                    // InternalDsl.g:1793:4: ( (lv_type_7_0= ruleSensorType ) )
                    // InternalDsl.g:1794:5: (lv_type_7_0= ruleSensorType )
                    {
                    // InternalDsl.g:1794:5: (lv_type_7_0= ruleSensorType )
                    // InternalDsl.g:1795:6: lv_type_7_0= ruleSensorType
                    {

                    						newCompositeNode(grammarAccess.getSensorAccess().getTypeSensorTypeEnumRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_62);
                    lv_type_7_0=ruleSensorType();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSensorRule());
                    						}
                    						set(
                    							current,
                    							"type",
                    							lv_type_7_0,
                    							"labtwo.Dsl.SensorType");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1813:3: (otherlv_8= 'range' ( (lv_range_9_0= ruleEInt ) ) )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==34) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // InternalDsl.g:1814:4: otherlv_8= 'range' ( (lv_range_9_0= ruleEInt ) )
                    {
                    otherlv_8=(Token)match(input,34,FOLLOW_20); 

                    				newLeafNode(otherlv_8, grammarAccess.getSensorAccess().getRangeKeyword_5_0());
                    			
                    // InternalDsl.g:1818:4: ( (lv_range_9_0= ruleEInt ) )
                    // InternalDsl.g:1819:5: (lv_range_9_0= ruleEInt )
                    {
                    // InternalDsl.g:1819:5: (lv_range_9_0= ruleEInt )
                    // InternalDsl.g:1820:6: lv_range_9_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getSensorAccess().getRangeEIntParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_63);
                    lv_range_9_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSensorRule());
                    						}
                    						set(
                    							current,
                    							"range",
                    							lv_range_9_0,
                    							"labtwo.Dsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1838:3: (otherlv_10= 'samplingRate' ( (lv_samplingRate_11_0= ruleEFloat ) ) )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==59) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // InternalDsl.g:1839:4: otherlv_10= 'samplingRate' ( (lv_samplingRate_11_0= ruleEFloat ) )
                    {
                    otherlv_10=(Token)match(input,59,FOLLOW_16); 

                    				newLeafNode(otherlv_10, grammarAccess.getSensorAccess().getSamplingRateKeyword_6_0());
                    			
                    // InternalDsl.g:1843:4: ( (lv_samplingRate_11_0= ruleEFloat ) )
                    // InternalDsl.g:1844:5: (lv_samplingRate_11_0= ruleEFloat )
                    {
                    // InternalDsl.g:1844:5: (lv_samplingRate_11_0= ruleEFloat )
                    // InternalDsl.g:1845:6: lv_samplingRate_11_0= ruleEFloat
                    {

                    						newCompositeNode(grammarAccess.getSensorAccess().getSamplingRateEFloatParserRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_64);
                    lv_samplingRate_11_0=ruleEFloat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSensorRule());
                    						}
                    						set(
                    							current,
                    							"samplingRate",
                    							lv_samplingRate_11_0,
                    							"labtwo.Dsl.EFloat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:1863:3: (otherlv_12= 'outputSignal' ( (lv_outputSignal_13_0= ruleEString ) ) )?
            int alt57=2;
            int LA57_0 = input.LA(1);

            if ( (LA57_0==60) ) {
                alt57=1;
            }
            switch (alt57) {
                case 1 :
                    // InternalDsl.g:1864:4: otherlv_12= 'outputSignal' ( (lv_outputSignal_13_0= ruleEString ) )
                    {
                    otherlv_12=(Token)match(input,60,FOLLOW_5); 

                    				newLeafNode(otherlv_12, grammarAccess.getSensorAccess().getOutputSignalKeyword_7_0());
                    			
                    // InternalDsl.g:1868:4: ( (lv_outputSignal_13_0= ruleEString ) )
                    // InternalDsl.g:1869:5: (lv_outputSignal_13_0= ruleEString )
                    {
                    // InternalDsl.g:1869:5: (lv_outputSignal_13_0= ruleEString )
                    // InternalDsl.g:1870:6: lv_outputSignal_13_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getSensorAccess().getOutputSignalEStringParserRuleCall_7_1_0());
                    					
                    pushFollow(FOLLOW_65);
                    lv_outputSignal_13_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSensorRule());
                    						}
                    						set(
                    							current,
                    							"outputSignal",
                    							lv_outputSignal_13_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_14=(Token)match(input,61,FOLLOW_24); 

            			newLeafNode(otherlv_14, grammarAccess.getSensorAccess().getImpactsKeyword_8());
            		
            otherlv_15=(Token)match(input,29,FOLLOW_5); 

            			newLeafNode(otherlv_15, grammarAccess.getSensorAccess().getLeftParenthesisKeyword_9());
            		
            // InternalDsl.g:1896:3: ( ( ruleEString ) )
            // InternalDsl.g:1897:4: ( ruleEString )
            {
            // InternalDsl.g:1897:4: ( ruleEString )
            // InternalDsl.g:1898:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSensorRule());
            					}
            				

            					newCompositeNode(grammarAccess.getSensorAccess().getImpactsMotorCrossReference_10_0());
            				
            pushFollow(FOLLOW_25);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalDsl.g:1912:3: (otherlv_17= ',' ( ( ruleEString ) ) )*
            loop58:
            do {
                int alt58=2;
                int LA58_0 = input.LA(1);

                if ( (LA58_0==17) ) {
                    alt58=1;
                }


                switch (alt58) {
            	case 1 :
            	    // InternalDsl.g:1913:4: otherlv_17= ',' ( ( ruleEString ) )
            	    {
            	    otherlv_17=(Token)match(input,17,FOLLOW_5); 

            	    				newLeafNode(otherlv_17, grammarAccess.getSensorAccess().getCommaKeyword_11_0());
            	    			
            	    // InternalDsl.g:1917:4: ( ( ruleEString ) )
            	    // InternalDsl.g:1918:5: ( ruleEString )
            	    {
            	    // InternalDsl.g:1918:5: ( ruleEString )
            	    // InternalDsl.g:1919:6: ruleEString
            	    {

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getSensorRule());
            	    						}
            	    					

            	    						newCompositeNode(grammarAccess.getSensorAccess().getImpactsMotorCrossReference_11_1_0());
            	    					
            	    pushFollow(FOLLOW_25);
            	    ruleEString();

            	    state._fsp--;


            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop58;
                }
            } while (true);

            otherlv_19=(Token)match(input,30,FOLLOW_14); 

            			newLeafNode(otherlv_19, grammarAccess.getSensorAccess().getRightParenthesisKeyword_12());
            		
            otherlv_20=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_20, grammarAccess.getSensorAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSensor"


    // $ANTLR start "entryRuleMemory"
    // InternalDsl.g:1946:1: entryRuleMemory returns [EObject current=null] : iv_ruleMemory= ruleMemory EOF ;
    public final EObject entryRuleMemory() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMemory = null;


        try {
            // InternalDsl.g:1946:47: (iv_ruleMemory= ruleMemory EOF )
            // InternalDsl.g:1947:2: iv_ruleMemory= ruleMemory EOF
            {
             newCompositeNode(grammarAccess.getMemoryRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMemory=ruleMemory();

            state._fsp--;

             current =iv_ruleMemory; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMemory"


    // $ANTLR start "ruleMemory"
    // InternalDsl.g:1953:1: ruleMemory returns [EObject current=null] : ( () otherlv_1= 'Memory' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'size' ( (lv_size_10_0= ruleEInt ) ) )? (otherlv_11= 'speed' ( (lv_speed_12_0= ruleEInt ) ) )? otherlv_13= '}' ) ;
    public final EObject ruleMemory() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        AntlrDatatypeRuleToken lv_serialNumber_4_0 = null;

        AntlrDatatypeRuleToken lv_manufacturer_6_0 = null;

        AntlrDatatypeRuleToken lv_type_8_0 = null;

        AntlrDatatypeRuleToken lv_size_10_0 = null;

        AntlrDatatypeRuleToken lv_speed_12_0 = null;



        	enterRule();

        try {
            // InternalDsl.g:1959:2: ( ( () otherlv_1= 'Memory' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'size' ( (lv_size_10_0= ruleEInt ) ) )? (otherlv_11= 'speed' ( (lv_speed_12_0= ruleEInt ) ) )? otherlv_13= '}' ) )
            // InternalDsl.g:1960:2: ( () otherlv_1= 'Memory' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'size' ( (lv_size_10_0= ruleEInt ) ) )? (otherlv_11= 'speed' ( (lv_speed_12_0= ruleEInt ) ) )? otherlv_13= '}' )
            {
            // InternalDsl.g:1960:2: ( () otherlv_1= 'Memory' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'size' ( (lv_size_10_0= ruleEInt ) ) )? (otherlv_11= 'speed' ( (lv_speed_12_0= ruleEInt ) ) )? otherlv_13= '}' )
            // InternalDsl.g:1961:3: () otherlv_1= 'Memory' otherlv_2= '{' (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )? (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'size' ( (lv_size_10_0= ruleEInt ) ) )? (otherlv_11= 'speed' ( (lv_speed_12_0= ruleEInt ) ) )? otherlv_13= '}'
            {
            // InternalDsl.g:1961:3: ()
            // InternalDsl.g:1962:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getMemoryAccess().getMemoryAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,62,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getMemoryAccess().getMemoryKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_66); 

            			newLeafNode(otherlv_2, grammarAccess.getMemoryAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalDsl.g:1976:3: (otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) ) )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==32) ) {
                alt59=1;
            }
            switch (alt59) {
                case 1 :
                    // InternalDsl.g:1977:4: otherlv_3= 'serialNumber' ( (lv_serialNumber_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,32,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getMemoryAccess().getSerialNumberKeyword_3_0());
                    			
                    // InternalDsl.g:1981:4: ( (lv_serialNumber_4_0= ruleEString ) )
                    // InternalDsl.g:1982:5: (lv_serialNumber_4_0= ruleEString )
                    {
                    // InternalDsl.g:1982:5: (lv_serialNumber_4_0= ruleEString )
                    // InternalDsl.g:1983:6: lv_serialNumber_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getMemoryAccess().getSerialNumberEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_67);
                    lv_serialNumber_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMemoryRule());
                    						}
                    						set(
                    							current,
                    							"serialNumber",
                    							lv_serialNumber_4_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:2001:3: (otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) ) )?
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==27) ) {
                alt60=1;
            }
            switch (alt60) {
                case 1 :
                    // InternalDsl.g:2002:4: otherlv_5= 'manufacturer' ( (lv_manufacturer_6_0= ruleEString ) )
                    {
                    otherlv_5=(Token)match(input,27,FOLLOW_5); 

                    				newLeafNode(otherlv_5, grammarAccess.getMemoryAccess().getManufacturerKeyword_4_0());
                    			
                    // InternalDsl.g:2006:4: ( (lv_manufacturer_6_0= ruleEString ) )
                    // InternalDsl.g:2007:5: (lv_manufacturer_6_0= ruleEString )
                    {
                    // InternalDsl.g:2007:5: (lv_manufacturer_6_0= ruleEString )
                    // InternalDsl.g:2008:6: lv_manufacturer_6_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getMemoryAccess().getManufacturerEStringParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_68);
                    lv_manufacturer_6_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMemoryRule());
                    						}
                    						set(
                    							current,
                    							"manufacturer",
                    							lv_manufacturer_6_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:2026:3: (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )?
            int alt61=2;
            int LA61_0 = input.LA(1);

            if ( (LA61_0==33) ) {
                alt61=1;
            }
            switch (alt61) {
                case 1 :
                    // InternalDsl.g:2027:4: otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) )
                    {
                    otherlv_7=(Token)match(input,33,FOLLOW_5); 

                    				newLeafNode(otherlv_7, grammarAccess.getMemoryAccess().getTypeKeyword_5_0());
                    			
                    // InternalDsl.g:2031:4: ( (lv_type_8_0= ruleEString ) )
                    // InternalDsl.g:2032:5: (lv_type_8_0= ruleEString )
                    {
                    // InternalDsl.g:2032:5: (lv_type_8_0= ruleEString )
                    // InternalDsl.g:2033:6: lv_type_8_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getMemoryAccess().getTypeEStringParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_69);
                    lv_type_8_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMemoryRule());
                    						}
                    						set(
                    							current,
                    							"type",
                    							lv_type_8_0,
                    							"labtwo.Dsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:2051:3: (otherlv_9= 'size' ( (lv_size_10_0= ruleEInt ) ) )?
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( (LA62_0==63) ) {
                alt62=1;
            }
            switch (alt62) {
                case 1 :
                    // InternalDsl.g:2052:4: otherlv_9= 'size' ( (lv_size_10_0= ruleEInt ) )
                    {
                    otherlv_9=(Token)match(input,63,FOLLOW_20); 

                    				newLeafNode(otherlv_9, grammarAccess.getMemoryAccess().getSizeKeyword_6_0());
                    			
                    // InternalDsl.g:2056:4: ( (lv_size_10_0= ruleEInt ) )
                    // InternalDsl.g:2057:5: (lv_size_10_0= ruleEInt )
                    {
                    // InternalDsl.g:2057:5: (lv_size_10_0= ruleEInt )
                    // InternalDsl.g:2058:6: lv_size_10_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getMemoryAccess().getSizeEIntParserRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_70);
                    lv_size_10_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMemoryRule());
                    						}
                    						set(
                    							current,
                    							"size",
                    							lv_size_10_0,
                    							"labtwo.Dsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalDsl.g:2076:3: (otherlv_11= 'speed' ( (lv_speed_12_0= ruleEInt ) ) )?
            int alt63=2;
            int LA63_0 = input.LA(1);

            if ( (LA63_0==39) ) {
                alt63=1;
            }
            switch (alt63) {
                case 1 :
                    // InternalDsl.g:2077:4: otherlv_11= 'speed' ( (lv_speed_12_0= ruleEInt ) )
                    {
                    otherlv_11=(Token)match(input,39,FOLLOW_20); 

                    				newLeafNode(otherlv_11, grammarAccess.getMemoryAccess().getSpeedKeyword_7_0());
                    			
                    // InternalDsl.g:2081:4: ( (lv_speed_12_0= ruleEInt ) )
                    // InternalDsl.g:2082:5: (lv_speed_12_0= ruleEInt )
                    {
                    // InternalDsl.g:2082:5: (lv_speed_12_0= ruleEInt )
                    // InternalDsl.g:2083:6: lv_speed_12_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getMemoryAccess().getSpeedEIntParserRuleCall_7_1_0());
                    					
                    pushFollow(FOLLOW_14);
                    lv_speed_12_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getMemoryRule());
                    						}
                    						set(
                    							current,
                    							"speed",
                    							lv_speed_12_0,
                    							"labtwo.Dsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_13=(Token)match(input,18,FOLLOW_2); 

            			newLeafNode(otherlv_13, grammarAccess.getMemoryAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMemory"


    // $ANTLR start "entryRuleEFloat"
    // InternalDsl.g:2109:1: entryRuleEFloat returns [String current=null] : iv_ruleEFloat= ruleEFloat EOF ;
    public final String entryRuleEFloat() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEFloat = null;


        try {
            // InternalDsl.g:2109:46: (iv_ruleEFloat= ruleEFloat EOF )
            // InternalDsl.g:2110:2: iv_ruleEFloat= ruleEFloat EOF
            {
             newCompositeNode(grammarAccess.getEFloatRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEFloat=ruleEFloat();

            state._fsp--;

             current =iv_ruleEFloat.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEFloat"


    // $ANTLR start "ruleEFloat"
    // InternalDsl.g:2116:1: ruleEFloat returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? ) ;
    public final AntlrDatatypeRuleToken ruleEFloat() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;
        Token this_INT_3=null;
        Token this_INT_7=null;


        	enterRule();

        try {
            // InternalDsl.g:2122:2: ( ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? ) )
            // InternalDsl.g:2123:2: ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? )
            {
            // InternalDsl.g:2123:2: ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? )
            // InternalDsl.g:2124:3: (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )?
            {
            // InternalDsl.g:2124:3: (kw= '-' )?
            int alt64=2;
            int LA64_0 = input.LA(1);

            if ( (LA64_0==64) ) {
                alt64=1;
            }
            switch (alt64) {
                case 1 :
                    // InternalDsl.g:2125:4: kw= '-'
                    {
                    kw=(Token)match(input,64,FOLLOW_71); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEFloatAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            // InternalDsl.g:2131:3: (this_INT_1= RULE_INT )?
            int alt65=2;
            int LA65_0 = input.LA(1);

            if ( (LA65_0==RULE_INT) ) {
                alt65=1;
            }
            switch (alt65) {
                case 1 :
                    // InternalDsl.g:2132:4: this_INT_1= RULE_INT
                    {
                    this_INT_1=(Token)match(input,RULE_INT,FOLLOW_72); 

                    				current.merge(this_INT_1);
                    			

                    				newLeafNode(this_INT_1, grammarAccess.getEFloatAccess().getINTTerminalRuleCall_1());
                    			

                    }
                    break;

            }

            kw=(Token)match(input,65,FOLLOW_73); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getEFloatAccess().getFullStopKeyword_2());
            		
            this_INT_3=(Token)match(input,RULE_INT,FOLLOW_74); 

            			current.merge(this_INT_3);
            		

            			newLeafNode(this_INT_3, grammarAccess.getEFloatAccess().getINTTerminalRuleCall_3());
            		
            // InternalDsl.g:2152:3: ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( ((LA68_0>=66 && LA68_0<=67)) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // InternalDsl.g:2153:4: (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT
                    {
                    // InternalDsl.g:2153:4: (kw= 'E' | kw= 'e' )
                    int alt66=2;
                    int LA66_0 = input.LA(1);

                    if ( (LA66_0==66) ) {
                        alt66=1;
                    }
                    else if ( (LA66_0==67) ) {
                        alt66=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 66, 0, input);

                        throw nvae;
                    }
                    switch (alt66) {
                        case 1 :
                            // InternalDsl.g:2154:5: kw= 'E'
                            {
                            kw=(Token)match(input,66,FOLLOW_20); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEFloatAccess().getEKeyword_4_0_0());
                            				

                            }
                            break;
                        case 2 :
                            // InternalDsl.g:2160:5: kw= 'e'
                            {
                            kw=(Token)match(input,67,FOLLOW_20); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEFloatAccess().getEKeyword_4_0_1());
                            				

                            }
                            break;

                    }

                    // InternalDsl.g:2166:4: (kw= '-' )?
                    int alt67=2;
                    int LA67_0 = input.LA(1);

                    if ( (LA67_0==64) ) {
                        alt67=1;
                    }
                    switch (alt67) {
                        case 1 :
                            // InternalDsl.g:2167:5: kw= '-'
                            {
                            kw=(Token)match(input,64,FOLLOW_73); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEFloatAccess().getHyphenMinusKeyword_4_1());
                            				

                            }
                            break;

                    }

                    this_INT_7=(Token)match(input,RULE_INT,FOLLOW_2); 

                    				current.merge(this_INT_7);
                    			

                    				newLeafNode(this_INT_7, grammarAccess.getEFloatAccess().getINTTerminalRuleCall_4_2());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEFloat"


    // $ANTLR start "entryRuleEInt"
    // InternalDsl.g:2185:1: entryRuleEInt returns [String current=null] : iv_ruleEInt= ruleEInt EOF ;
    public final String entryRuleEInt() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEInt = null;


        try {
            // InternalDsl.g:2185:44: (iv_ruleEInt= ruleEInt EOF )
            // InternalDsl.g:2186:2: iv_ruleEInt= ruleEInt EOF
            {
             newCompositeNode(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEInt=ruleEInt();

            state._fsp--;

             current =iv_ruleEInt.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalDsl.g:2192:1: ruleEInt returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? this_INT_1= RULE_INT ) ;
    public final AntlrDatatypeRuleToken ruleEInt() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;


        	enterRule();

        try {
            // InternalDsl.g:2198:2: ( ( (kw= '-' )? this_INT_1= RULE_INT ) )
            // InternalDsl.g:2199:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            {
            // InternalDsl.g:2199:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            // InternalDsl.g:2200:3: (kw= '-' )? this_INT_1= RULE_INT
            {
            // InternalDsl.g:2200:3: (kw= '-' )?
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==64) ) {
                alt69=1;
            }
            switch (alt69) {
                case 1 :
                    // InternalDsl.g:2201:4: kw= '-'
                    {
                    kw=(Token)match(input,64,FOLLOW_73); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEIntAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            this_INT_1=(Token)match(input,RULE_INT,FOLLOW_2); 

            			current.merge(this_INT_1);
            		

            			newLeafNode(this_INT_1, grammarAccess.getEIntAccess().getINTTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "ruleArchitectureType"
    // InternalDsl.g:2218:1: ruleArchitectureType returns [Enumerator current=null] : ( (enumLiteral_0= 'ARM' ) | (enumLiteral_1= 'MIPS' ) | (enumLiteral_2= 'AVR' ) | (enumLiteral_3= 'x86' ) | (enumLiteral_4= 'SPARC' ) ) ;
    public final Enumerator ruleArchitectureType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;


        	enterRule();

        try {
            // InternalDsl.g:2224:2: ( ( (enumLiteral_0= 'ARM' ) | (enumLiteral_1= 'MIPS' ) | (enumLiteral_2= 'AVR' ) | (enumLiteral_3= 'x86' ) | (enumLiteral_4= 'SPARC' ) ) )
            // InternalDsl.g:2225:2: ( (enumLiteral_0= 'ARM' ) | (enumLiteral_1= 'MIPS' ) | (enumLiteral_2= 'AVR' ) | (enumLiteral_3= 'x86' ) | (enumLiteral_4= 'SPARC' ) )
            {
            // InternalDsl.g:2225:2: ( (enumLiteral_0= 'ARM' ) | (enumLiteral_1= 'MIPS' ) | (enumLiteral_2= 'AVR' ) | (enumLiteral_3= 'x86' ) | (enumLiteral_4= 'SPARC' ) )
            int alt70=5;
            switch ( input.LA(1) ) {
            case 68:
                {
                alt70=1;
                }
                break;
            case 69:
                {
                alt70=2;
                }
                break;
            case 70:
                {
                alt70=3;
                }
                break;
            case 71:
                {
                alt70=4;
                }
                break;
            case 72:
                {
                alt70=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 70, 0, input);

                throw nvae;
            }

            switch (alt70) {
                case 1 :
                    // InternalDsl.g:2226:3: (enumLiteral_0= 'ARM' )
                    {
                    // InternalDsl.g:2226:3: (enumLiteral_0= 'ARM' )
                    // InternalDsl.g:2227:4: enumLiteral_0= 'ARM'
                    {
                    enumLiteral_0=(Token)match(input,68,FOLLOW_2); 

                    				current = grammarAccess.getArchitectureTypeAccess().getARMEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getArchitectureTypeAccess().getARMEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalDsl.g:2234:3: (enumLiteral_1= 'MIPS' )
                    {
                    // InternalDsl.g:2234:3: (enumLiteral_1= 'MIPS' )
                    // InternalDsl.g:2235:4: enumLiteral_1= 'MIPS'
                    {
                    enumLiteral_1=(Token)match(input,69,FOLLOW_2); 

                    				current = grammarAccess.getArchitectureTypeAccess().getMIPSEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getArchitectureTypeAccess().getMIPSEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalDsl.g:2242:3: (enumLiteral_2= 'AVR' )
                    {
                    // InternalDsl.g:2242:3: (enumLiteral_2= 'AVR' )
                    // InternalDsl.g:2243:4: enumLiteral_2= 'AVR'
                    {
                    enumLiteral_2=(Token)match(input,70,FOLLOW_2); 

                    				current = grammarAccess.getArchitectureTypeAccess().getAVREnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getArchitectureTypeAccess().getAVREnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalDsl.g:2250:3: (enumLiteral_3= 'x86' )
                    {
                    // InternalDsl.g:2250:3: (enumLiteral_3= 'x86' )
                    // InternalDsl.g:2251:4: enumLiteral_3= 'x86'
                    {
                    enumLiteral_3=(Token)match(input,71,FOLLOW_2); 

                    				current = grammarAccess.getArchitectureTypeAccess().getX86EnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getArchitectureTypeAccess().getX86EnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalDsl.g:2258:3: (enumLiteral_4= 'SPARC' )
                    {
                    // InternalDsl.g:2258:3: (enumLiteral_4= 'SPARC' )
                    // InternalDsl.g:2259:4: enumLiteral_4= 'SPARC'
                    {
                    enumLiteral_4=(Token)match(input,72,FOLLOW_2); 

                    				current = grammarAccess.getArchitectureTypeAccess().getSPARCEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getArchitectureTypeAccess().getSPARCEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArchitectureType"


    // $ANTLR start "ruleSensorType"
    // InternalDsl.g:2269:1: ruleSensorType returns [Enumerator current=null] : ( (enumLiteral_0= 'TEMPERATURE' ) | (enumLiteral_1= 'PRESSURE' ) | (enumLiteral_2= 'HUMIDITY' ) | (enumLiteral_3= 'ACCELEROMETER' ) ) ;
    public final Enumerator ruleSensorType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalDsl.g:2275:2: ( ( (enumLiteral_0= 'TEMPERATURE' ) | (enumLiteral_1= 'PRESSURE' ) | (enumLiteral_2= 'HUMIDITY' ) | (enumLiteral_3= 'ACCELEROMETER' ) ) )
            // InternalDsl.g:2276:2: ( (enumLiteral_0= 'TEMPERATURE' ) | (enumLiteral_1= 'PRESSURE' ) | (enumLiteral_2= 'HUMIDITY' ) | (enumLiteral_3= 'ACCELEROMETER' ) )
            {
            // InternalDsl.g:2276:2: ( (enumLiteral_0= 'TEMPERATURE' ) | (enumLiteral_1= 'PRESSURE' ) | (enumLiteral_2= 'HUMIDITY' ) | (enumLiteral_3= 'ACCELEROMETER' ) )
            int alt71=4;
            switch ( input.LA(1) ) {
            case 73:
                {
                alt71=1;
                }
                break;
            case 74:
                {
                alt71=2;
                }
                break;
            case 75:
                {
                alt71=3;
                }
                break;
            case 76:
                {
                alt71=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 71, 0, input);

                throw nvae;
            }

            switch (alt71) {
                case 1 :
                    // InternalDsl.g:2277:3: (enumLiteral_0= 'TEMPERATURE' )
                    {
                    // InternalDsl.g:2277:3: (enumLiteral_0= 'TEMPERATURE' )
                    // InternalDsl.g:2278:4: enumLiteral_0= 'TEMPERATURE'
                    {
                    enumLiteral_0=(Token)match(input,73,FOLLOW_2); 

                    				current = grammarAccess.getSensorTypeAccess().getTEMPERATUREEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getSensorTypeAccess().getTEMPERATUREEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalDsl.g:2285:3: (enumLiteral_1= 'PRESSURE' )
                    {
                    // InternalDsl.g:2285:3: (enumLiteral_1= 'PRESSURE' )
                    // InternalDsl.g:2286:4: enumLiteral_1= 'PRESSURE'
                    {
                    enumLiteral_1=(Token)match(input,74,FOLLOW_2); 

                    				current = grammarAccess.getSensorTypeAccess().getPRESSUREEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getSensorTypeAccess().getPRESSUREEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalDsl.g:2293:3: (enumLiteral_2= 'HUMIDITY' )
                    {
                    // InternalDsl.g:2293:3: (enumLiteral_2= 'HUMIDITY' )
                    // InternalDsl.g:2294:4: enumLiteral_2= 'HUMIDITY'
                    {
                    enumLiteral_2=(Token)match(input,75,FOLLOW_2); 

                    				current = grammarAccess.getSensorTypeAccess().getHUMIDITYEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getSensorTypeAccess().getHUMIDITYEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalDsl.g:2301:3: (enumLiteral_3= 'ACCELEROMETER' )
                    {
                    // InternalDsl.g:2301:3: (enumLiteral_3= 'ACCELEROMETER' )
                    // InternalDsl.g:2302:4: enumLiteral_3= 'ACCELEROMETER'
                    {
                    enumLiteral_3=(Token)match(input,76,FOLLOW_2); 

                    				current = grammarAccess.getSensorTypeAccess().getACCELEROMETEREnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getSensorTypeAccess().getACCELEROMETEREnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSensorType"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x000000000009E000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x000000000009C000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000098000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000090000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x4408402080000000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000060000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x000000001FC00000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000040L,0x0000000000000003L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x000000001F800000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x000000001F000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x000000001E000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000000040L,0x0000000000000001L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x000000001C000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000018000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000040020000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000001F08040000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000001E08040000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000001E00040000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000001C00040000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000001800040000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000001000040000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x00003FC108040000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x00003FC008040000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x00003FC000040000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x00003F8000040000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x00003F0000040000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x00003E0000040000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x00003C0000040000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000380000040000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000300000040000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000200000040000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0007800508040000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0007800408040000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0007800400040000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0007000400040000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0006000400040000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0006000000040000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0004000000040000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x01F0000108000000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x01F0000008000000L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x01F0000000000000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x01E0000000000000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x01C0000000000000L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0000000000000000L,0x00000000000001F0L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0180000000000000L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0100000000000000L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0200000000040000L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x3800000708000000L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x3800000608000000L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x3800000600000000L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001E00L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x3800000400000000L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x3800000000000000L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x3000000000000000L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x2000000000000000L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x8000008308040000L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x8000008208040000L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x8000008200040000L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x8000008000040000L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x0000008000040000L});
    public static final BitSet FOLLOW_71 = new BitSet(new long[]{0x0000000000000040L,0x0000000000000002L});
    public static final BitSet FOLLOW_72 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000002L});
    public static final BitSet FOLLOW_73 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_74 = new BitSet(new long[]{0x0000000000000002L,0x000000000000000CL});

}